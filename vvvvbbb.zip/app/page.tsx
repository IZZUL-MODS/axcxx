import Link from 'next/link';
import {
  Zap,
  Clapperboard,
  Smartphone,
  Camera,
  Scissors,
  Film,
  Play,
  Bot,
  Clock,
  shieldAlert,
  database,
  ShieldCheck,
} from 'lucide-react';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';

const features = [
  {
    icon: Bot,
    title: 'Deteksi Momen AI',
    desc: 'Gemini Vision menganalisis frame demi frame dan menemukan momen paling menarik — bukan asal memotong.',
  },
  {
    icon: Scissors,
    title: 'Potong Utuh Per Momen',
    desc: 'Setiap klip dipotong dari awal hingga akhir aksi, jadi momen penting tidak pernah terpotong setengah.',
  },
  {
    icon: Smartphone,
    title: 'Semua Platform',
    desc: 'TikTok, Instagram, YouTube, Facebook, Twitter/X, Pinterest, sampai CapCut — cukup tempel link-nya.',
  },
  {
    icon: Zap,
    title: 'Proses di Browser',
    desc: 'Pemotongan berjalan langsung di browser dengan FFmpeg. Cepat, tanpa antre, tanpa upload ke server.',
  },
  {
    icon: database,
    title: 'Tanpa Penyimpanan',
    desc: 'Video kamu tidak disimpan di mana pun. Semua diproses lokal lalu langsung bisa diunduh.',
  },
  {
    icon: Clock,
    title: 'Hemat Waktu',
    desc: 'Dari video panjang menjadi beberapa klip viral hanya dalam hitungan detik, siap diunggah.',
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <SiteHeader />

      {/* Hero Section */}
      <section className="relative pt-24 pb-20 px-4 border-b border-border overflow-hidden">
        {/* Animated gradient orbs */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-float-slow" />
          <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl animate-float-slower" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-3xl animate-pulse-glow" />
        </div>

        {/* Grid background dengan fade */}
        <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:48px_48px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,black,transparent)]" />

        {/* Floating particles */}
        <div className="absolute inset-0 -z-10 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <span
              key={i}
              className="absolute w-1 h-1 bg-primary/60 rounded-full animate-particle"
              style={{
                left: `${15 + i * 14}%`,
                top: `${20 + (i % 3) * 25}%`,
                animationDelay: `${i * 0.8}s`,
              }}
            />
          ))}
        </div>

        <div className="mx-auto max-w-4xl text-center">
          {/* Animated Video Editing Timeline */}
          <div className="mx-auto mb-8 w-full max-w-md animate-fade-in-up">
            <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-background/70 p-4 shadow-[0_18px_60px_-24px] shadow-primary/70 backdrop-blur-xl">
              {/* Top bar: REC indicator + tools */}
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-4 w-4 items-center justify-center">
                    <span className="absolute h-full w-full rounded-full border border-destructive/50 animate-ping" />
                    <span className="h-2 w-2 rounded-full bg-destructive animate-[rec-blink_1.2s_ease-in-out_infinite]" />
                  </span>
                  <span className="text-[10px] font-bold tracking-[0.25em] text-destructive uppercase">
                    REC
                  </span>
                  <Camera className="h-4 w-4 text-muted-foreground animate-[shutter_4s_ease-in-out_infinite]" />
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Scissors className="h-4 w-4 animate-[clip-pop_2.4s_ease-in-out_infinite]" />
                  <Film className="h-4 w-4" />
                  <span className="rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 text-[10px] font-bold tracking-widest text-primary">
                    AI CUT
                  </span>
                </div>
              </div>

              {/* Timeline track with clip segments */}
              <div className="relative h-12 overflow-hidden rounded-lg border border-white/10 bg-white/[0.03]">
                <div className="absolute inset-0 flex items-center gap-1 px-2">
                  {[40, 70, 55, 90, 45, 80, 60, 95, 50, 75, 65, 85, 42, 68, 58].map((h, i) => (
                    <span
                      key={i}
                      className="flex-1 rounded-sm bg-primary/60 origin-center animate-[clip-pop_1.8s_ease-in-out_infinite]"
                      style={{ height: `${h}%`, animationDelay: `${i * 0.12}s` }}
                    />
                  ))}
                </div>

                {/* Cut markers */}
                <span className="absolute top-0 left-[30%] h-full w-px bg-accent/70" />
                <span className="absolute top-0 left-[62%] h-full w-px bg-accent/70" />

                {/* Moving playhead */}
                <span className="absolute top-0 h-full w-[2px] bg-destructive shadow-[0_0_12px] shadow-destructive animate-[playhead_5s_linear_infinite]">
                  <span className="absolute -top-0.5 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-destructive" />
                </span>
              </div>

              {/* Bottom bar: play + timecode */}
              <div className="mt-3 flex items-center justify-between text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Play className="h-3.5 w-3.5 fill-current text-primary" />
                  <span className="font-mono text-[10px] tracking-widest">00:00:14:08</span>
                </div>
                <span className="font-mono text-[10px] tracking-widest text-primary/80">
                  3 CLIPS DETECTED
                </span>
              </div>

              {/* Inner shine sweep */}
              <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/5 to-transparent animate-[playhead_6s_linear_infinite]" />
            </div>
          </div>

          {/* Headline dengan gradient shimmer */}
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 animate-fade-in-up [animation-delay:150ms] opacity-0 [animation-fill-mode:forwards]">
            <span className="bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
              Ubah Video Panjang Jadi Klip Viral
            </span>
          </h1>

          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 animate-fade-in-up [animation-delay:300ms] opacity-0 [animation-fill-mode:forwards]">
            Biarkan AI memotong momen terbaik dari videomu secara otomatis, siap diunggah dalam hitungan detik.
          </p>

          {/* CTA dengan hover glow & scale */}
          <div className="flex items-center justify-center gap-4 animate-fade-in-up [animation-delay:450ms] opacity-0 [animation-fill-mode:forwards]">
            <Link
              href="/clip"
              className="relative px-8 py-3 rounded-full bg-primary text-primary-foreground font-semibold overflow-hidden transition-transform duration-300 hover:scale-105 shadow-[0_0_30px_-8px] shadow-primary/60 group"
            >
              <span className="relative z-10">Mulai Gratis</span>
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </Link>
            <Link
              href="/demo"
              className="px-8 py-3 rounded-full border border-border font-semibold hover:border-primary/50 hover:bg-primary/5 transition-all duration-300 hover:scale-105"
            >
              Lihat Demo
            </Link>
          </div>

          <div className="mt-12 flex gap-8 justify-center flex-wrap">
            <div className="flex flex-col items-center gap-2">
              <shieldAlert className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Auto-detect</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Clapperboard className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Multi-clips</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Smartphone className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">All Platforms</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 py-20">
        <div className="mx-auto max-w-6xl">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
              Kenapa pakai IClip?
            </h2>
            <p className="mt-4 text-muted-foreground text-pretty">
              Dibuat khusus untuk menemukan momen terbaik dari video panjangmu, bukan sekadar
              membelahnya jadi potongan acak.
            </p>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div
                key={f.title}
                className="group rounded-2xl border border-border bg-card/50 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/10"
              >
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-transform duration-300 group-hover:scale-110">
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-lg font-semibold">{f.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA band */}
      <section className="px-4 py-20">
        <div className="mx-auto max-w-4xl overflow-hidden rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-background p-10 text-center shadow-xl shadow-primary/10 md:p-14">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
            Siap membuat klip viral pertamamu?
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground text-pretty">
            Tempel link video apa pun dan biarkan AI menemukan momen terbaiknya. Gratis, tanpa daftar.
          </p>
          <div className="mt-8 flex items-center justify-center gap-4">
            <Link
              href="/clip"
              className="relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-primary px-8 py-3 font-semibold text-primary-foreground shadow-[0_0_30px_-8px] shadow-primary/60 transition-transform duration-300 hover:scale-105 group"
            >
              <Scissors className="h-4 w-4" />
              <span className="relative z-10">Mulai Gratis</span>
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </Link>
          </div>
        </div>
      </section>

      <SiteFooter />
    </main>
  );
}
