'use client';

import { Loader2, CheckCircle, AlertCircle, Sparkles } from 'lucide-react';

export interface ProcessingStep {
  name: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  message?: string;
}

interface ProcessingStatusProps {
  steps: ProcessingStep[];
  isComplete: boolean;
  clipsCount?: number;
}

export function ProcessingStatus({ steps, isComplete, clipsCount }: ProcessingStatusProps) {
  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="bg-card rounded-xl border border-border p-8 shadow-lg">
        <h2 className="text-2xl font-bold mb-6 text-foreground flex items-center gap-2">
          {isComplete ? (
            <>
              <Sparkles className="w-6 h-6 text-accent" /> Clips Generated!
            </>
          ) : (
            'Processing Your Video...'
          )}
        </h2>

        <div className="space-y-4">
          {steps.map((step, idx) => (
            <div key={idx} className="flex items-start gap-4">
              <div className="pt-1">
                {step.status === 'pending' && (
                  <div className="w-6 h-6 rounded-full border-2 border-muted-foreground bg-muted" />
                )}
                {step.status === 'processing' && (
                  <Loader2 className="w-6 h-6 text-primary animate-spin" />
                )}
                {step.status === 'completed' && (
                  <CheckCircle className="w-6 h-6 text-accent" />
                )}
                {step.status === 'error' && (
                  <AlertCircle className="w-6 h-6 text-destructive" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">{step.name}</p>
                {step.message && (
                  <p className="text-sm text-muted-foreground mt-1">{step.message}</p>
                )}
              </div>
            </div>
          ))}
        </div>

        {isComplete && clipsCount && (
          <div className="mt-8 p-4 bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg border border-primary/20">
            <p className="text-center text-lg font-bold text-accent">
              Successfully generated {clipsCount} amazing clips!
            </p>
            <p className="text-center text-sm text-muted-foreground mt-2">
              Scroll down to preview and download your clips
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
