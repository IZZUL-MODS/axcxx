'use client';

import { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';
import { video, Clapperboard, Aperture, Moon, CloudSun } from 'lucide-react';

export function SiteHeader() {
  const { resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const isDark = resolvedTheme === 'dark';

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/80 backdrop-blur-md">
      <div className="max-w-6xl mx-auto flex h-16 items-center justify-between px-4">
        {/* Logo */}
<div className="group flex items-center gap-3 cursor-pointer">
  <div className="relative">
    {/* Rotating gradient ring */}
    <div className="absolute -inset-[3px] rounded-xl bg-[conic-gradient(from_0deg,theme(colors.primary.DEFAULT),transparent_30%,theme(colors.primary.DEFAULT)_50%,transparent_80%,theme(colors.primary.DEFAULT))] animate-spin-slow opacity-70 group-hover:opacity-100 transition-opacity blur-[2px]" />

    {/* Glow pulse */}
    <div className="absolute inset-0 rounded-xl bg-primary/40 blur-lg animate-logo-glow" />

    {/* Logo box */}
    <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-primary shadow-lg shadow-primary/30 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6 overflow-hidden">
      {/* Shine sweep */}
      <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
      <video
  className="relative z-10 h-6 w-6 text-primary-foreground transition-transform duration-500 ease-out group-hover:rotate-12 group-hover:scale-110"
  aria-hidden="true"
/>
    </div>
  </div>

  <div className="flex flex-col leading-none">
    <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
      IClip
    </span>
    <span className="text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground group-hover:text-primary/70 group-hover:tracking-[0.3em] transition-all duration-500">
      AI Video Clipper
    </span>
  </div>
</div>


        {/* Day / Night toggle */}
        {mounted ? (
          <button
            type="button"
            onClick={() => setTheme(isDark ? 'light' : 'dark')}
            aria-label={isDark ? 'Aktifkan mode terang' : 'Aktifkan mode gelap'}
            className="group relative flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card text-foreground transition-all hover:scale-105 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10 active:scale-95"
          >
            {isDark ? (
              <CloudSun className="h-5 w-5 transition-transform duration-300 group-hover:rotate-12" aria-hidden="true" />
            ) : (
              <Moon className="h-5 w-5 transition-transform duration-300 group-hover:-rotate-12" aria-hidden="true" />
            )}
            <span className="sr-only">{isDark ? 'Mode terang' : 'Mode gelap'}</span>
          </button>
        ) : (
          <div className="h-10 w-10 rounded-xl border border-border bg-card" aria-hidden="true" />
        )}
      </div>
    </header>
  );
}
