'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Link2, Zap, Bot, Clapperboard } from 'lucide-react';

interface InputFormProps {
  onSubmit: (url: string) => Promise<void>;
  isLoading: boolean;
}

export function InputForm({ onSubmit, isLoading }: InputFormProps) {
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    setError('');
    const trimmed = url.trim();

    if (!trimmed) {
      setError('Please enter a video URL');
      return;
    }

    try {
      const parsed = new URL(trimmed);
      if (!['http:', 'https:'].includes(parsed.protocol)) {
        setError('Only http/https URLs are supported');
        return;
      }
    } catch {
      setError('Invalid URL. Paste a full link, e.g. https://www.tiktok.com/...');
      return;
    }

    await onSubmit(trimmed);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.nativeEvent.isComposing && e.keyCode !== 229) {
      handleSubmit();
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4">
      <div className="relative p-8 md:p-12 rounded-lg border-2 border-dashed border-primary/30 bg-card/50">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="p-3 bg-primary/20 rounded-lg">
              <Link2 className="w-8 h-8 text-primary" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Paste a social media video link
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              TikTok, Instagram, Facebook, YouTube, Twitter/X, Pinterest, CapCut
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="https://www.tiktok.com/@user/video/..."
              disabled={isLoading}
              aria-label="Video URL"
              className="flex-1 h-11 px-4 rounded-md border border-border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"
            />
            <Button
              onClick={handleSubmit}
              disabled={isLoading}
              className="gap-2 h-11"
              size="lg"
            >
              <Zap className="w-4 h-4" />
              {isLoading ? 'Processing...' : 'Clip Video'}
            </Button>
          </div>

          {error && (
            <p className="text-sm text-destructive font-medium" role="alert">
              {error}
            </p>
          )}
        </div>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="flex flex-col items-center text-center gap-1">
          <Bot className="w-6 h-6 text-primary mb-1" />
          <p className="text-sm text-muted-foreground">AI Analysis</p>
          <p className="text-xs text-muted-foreground">With Gemini Vision</p>
        </div>
        <div className="flex flex-col items-center text-center gap-1">
          <Zap className="w-6 h-6 text-accent mb-1" />
          <p className="text-sm text-muted-foreground">Instant Clips</p>
          <p className="text-xs text-muted-foreground">Client-side processing</p>
        </div>
        <div className="flex flex-col items-center text-center gap-1">
          <Clapperboard className="w-6 h-6 text-primary mb-1" />
          <p className="text-sm text-muted-foreground">Download Direct</p>
          <p className="text-xs text-muted-foreground">No storage needed</p>
        </div>
      </div>
    </div>
  );
}
