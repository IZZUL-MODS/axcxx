/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  serverExternalPackages: ['ab-downloader'],
  images: {
    unoptimized: true,
  },
}

export default nextConfig
