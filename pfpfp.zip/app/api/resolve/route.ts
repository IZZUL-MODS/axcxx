import { NextRequest, NextResponse } from 'next/server';
// @ts-expect-error - ab-downloader has no type definitions
import { ttdl, igdl, fbdown, twitter, youtube, aio, pinterest, capcut } from 'ab-downloader';

export const runtime = 'nodejs';
export const maxDuration = 60;

interface ResolveResult {
  videoUrl: string;
  title: string;
  thumbnail?: string;
}

function detectPlatform(url: string): string {
  const u = url.toLowerCase();
  if (u.includes('tiktok.com')) return 'tiktok';
  if (u.includes('instagram.com')) return 'instagram';
  if (u.includes('facebook.com') || u.includes('fb.watch')) return 'facebook';
  if (u.includes('youtube.com') || u.includes('youtu.be')) return 'youtube';
  if (u.includes('twitter.com') || u.includes('x.com')) return 'twitter';
  if (u.includes('pinterest.com') || u.includes('pin.it')) return 'pinterest';
  if (u.includes('capcut.com')) return 'capcut';
  return 'aio';
}

async function resolveVideo(url: string): Promise<ResolveResult> {
  const platform = detectPlatform(url);
  console.log('[clipper] Resolving URL via ab-downloader, platform:', platform);

  switch (platform) {
    case 'tiktok': {
      const data = await ttdl(url);
      if (data?.status === false || !data?.video) {
        throw new Error(data?.message || 'TikTok video not found');
      }
      const video = Array.isArray(data.video) ? data.video[0] : data.video;
      return { videoUrl: video, title: data.title || 'TikTok Video', thumbnail: data.thumbnail };
    }
    case 'instagram': {
      const data = await igdl(url);
      if (!Array.isArray(data) || data.length === 0) {
        throw new Error((data as any)?.message || 'Instagram video not found');
      }
      const item = data.find((d: any) => d.url) || data[0];
      return { videoUrl: item.url, title: 'Instagram Video', thumbnail: item.thumbnail };
    }
    case 'facebook': {
      const data = await fbdown(url);
      const video = data?.HD || data?.Normal_video;
      if (data?.status === false || !video) {
        throw new Error(data?.message || 'Facebook video not found');
      }
      return { videoUrl: video, title: 'Facebook Video' };
    }
    case 'youtube': {
      const data = await youtube(url);
      if (data?.status === false || !data?.mp4) {
        throw new Error(data?.message || 'YouTube video not found');
      }
      return { videoUrl: data.mp4, title: data.title || 'YouTube Video', thumbnail: data.thumbnail };
    }
    case 'twitter': {
      const data = await twitter(url);
      if (data?.status === false || !data?.url) {
        throw new Error(data?.message || 'Twitter/X video not found');
      }
      const video = Array.isArray(data.url)
        ? (data.url[data.url.length - 1]?.hd || data.url[data.url.length - 1]?.sd || data.url[0])
        : data.url;
      return { videoUrl: typeof video === 'string' ? video : video?.hd || video?.sd, title: data.title || 'Twitter Video' };
    }
    case 'pinterest': {
      const data = await pinterest(url);
      const result = data?.result;
      const video = result?.video || result?.url || result?.media;
      if (data?.status === false || !video) {
        throw new Error(data?.message || 'Pinterest video not found');
      }
      return { videoUrl: video, title: 'Pinterest Video' };
    }
    case 'capcut': {
      const data = await capcut(url);
      const video = data?.video || data?.url || data?.data?.video;
      if (data?.status === false || !video) {
        throw new Error(data?.message || 'CapCut video not found');
      }
      return { videoUrl: video, title: data?.title || 'CapCut Video' };
    }
    default: {
      const data = await aio(url);
      if (data?.status === false || !data?.url) {
        throw new Error(data?.message || 'Video not found for this URL');
      }
      const video = Array.isArray(data.url) ? (data.url[0]?.url || data.url[0]) : data.url;
      return { videoUrl: typeof video === 'string' ? video : video?.url, title: 'Video' };
    }
  }
}

export async function POST(req: NextRequest) {
  try {
    const { url } = await req.json();

    if (!url || typeof url !== 'string') {
      return NextResponse.json({ error: 'URL is required' }, { status: 400 });
    }

    let parsed: URL;
    try {
      parsed = new URL(url);
    } catch {
      return NextResponse.json({ error: 'Invalid URL format' }, { status: 400 });
    }
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return NextResponse.json({ error: 'Only http/https URLs are supported' }, { status: 400 });
    }

    const result = await resolveVideo(url);

    if (!result.videoUrl) {
      return NextResponse.json({ error: 'Could not extract video URL' }, { status: 404 });
    }

    console.log('[clipper] Resolved video URL:', result.videoUrl.slice(0, 100));
    return NextResponse.json(result);
  } catch (error) {
    console.error('[clipper] Resolve error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to resolve video' },
      { status: 500 }
    );
  }
}
