import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';
export const maxDuration = 120;

// Streams the remote video through the server to the browser (no storage used).
export async function GET(req: NextRequest) {
  const videoUrl = req.nextUrl.searchParams.get('url');

  if (!videoUrl) {
    return NextResponse.json({ error: 'url parameter is required' }, { status: 400 });
  }

  let parsed: URL;
  try {
    parsed = new URL(videoUrl);
  } catch {
    return NextResponse.json({ error: 'Invalid URL' }, { status: 400 });
  }
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    return NextResponse.json({ error: 'Only http/https URLs are supported' }, { status: 400 });
  }

  try {
    console.log('[clipper] Proxying video:', videoUrl.slice(0, 100));
    const upstream = await fetch(videoUrl, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        Accept: '*/*',
        Referer: `${parsed.protocol}//${parsed.host}/`,
      },
      redirect: 'follow',
    });

    if (!upstream.ok || !upstream.body) {
      return NextResponse.json(
        { error: `Upstream returned ${upstream.status}` },
        { status: 502 }
      );
    }

    const contentType = upstream.headers.get('content-type') || 'video/mp4';
    const contentLength = upstream.headers.get('content-length');

    const headers = new Headers({
      'Content-Type': contentType,
      'Cache-Control': 'no-store',
    });
    if (contentLength) headers.set('Content-Length', contentLength);

    return new NextResponse(upstream.body, { status: 200, headers });
  } catch (error) {
    console.error('[clipper] Proxy error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to fetch video' },
      { status: 500 }
    );
  }
}
