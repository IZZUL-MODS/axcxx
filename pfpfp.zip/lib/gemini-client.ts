import { GoogleGenerativeAI } from '@google/generative-ai';

let genAI: GoogleGenerativeAI | null = null;

const MODEL_ID = 'gemini-2.5-flash';

export function initGemini(apiKey: string) {
  genAI = new GoogleGenerativeAI(apiKey);
}

export interface DetectedMoment {
  startTime: number;
  endTime: number;
  actionType: string;
  intensity: number;
  description: string;
}

// Analyze ALL frames in a single Gemini request and ask the model to return
// complete MOMENTS (scenes) with a start AND end time, so clips cover the
// whole action instead of being cut to a fixed length.
export async function detectMoments(
  frames: Array<{ timestamp: number; imageBase64: string }>,
  videoDuration: number,
  onProgress?: (current: number, total: number) => void
): Promise<DetectedMoment[]> {
  if (!genAI) {
    throw new Error('Gemini API not initialized. Call initGemini first.');
  }
  if (frames.length === 0) return [];

  onProgress?.(1, 1);

  const model = genAI.getGenerativeModel(
    {
      model: MODEL_ID,
      generationConfig: {
        responseMimeType: 'application/json',
      },
    },
    // Hard timeout so the request can never hang forever
    { timeout: 60000 }
  );

  const parts: Array<
    | { text: string }
    | { inlineData: { mimeType: string; data: string } }
  > = [];

  parts.push({
    text: `You are an expert viral-video editor. You will receive ${frames.length} frames extracted from a single video (total duration: ${Math.round(videoDuration)} seconds), each labeled with its timestamp in seconds.

Your job: identify the CRUCIAL, most clip-worthy MOMENTS (scenes) in this video — action sequences, emotional peaks, funny moments, kills/wins in gaming, reveals, climaxes, dramatic changes, anything special.

CRITICAL RULES for each moment:
- A moment is a COMPLETE scene with a startTime and an endTime. The clip must cover the ENTIRE action from just before it begins until the action/scene fully finishes. NEVER cut a moment short.
- Moments can be ANY length — some scenes are 5 seconds, others 20, 30, 60 seconds or more. Use the frames to judge where each scene naturally starts and ends. Do NOT default to a fixed length.
- Start slightly BEFORE the action begins (1-3 seconds of lead-in) and end only AFTER the action has clearly concluded.
- Moments must NOT overlap each other.
- endTime must never exceed ${Math.round(videoDuration)} (the video duration).
- Return between 2 and 8 moments, only genuinely crucial/stand-out ones.`,
  });

  for (const frame of frames) {
    parts.push({ text: `Frame at timestamp ${frame.timestamp} seconds:` });
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: frame.imageBase64,
      },
    });
  }

  parts.push({
    text: `Now respond ONLY with a valid JSON array (no markdown), ordered by startTime, with this exact shape:
[
  {
    "startTime": number (seconds where the scene/moment begins, including 1-3s lead-in),
    "endTime": number (seconds where the scene/moment has FULLY finished — do not cut it short),
    "actionType": "short label of the action type",
    "intensity": number 1-10 (how crucial/clip-worthy the moment is),
    "description": "brief description of what happens during the whole moment"
  }
]`,
  });

  const response = await model.generateContent(parts as never);
  const responseText = response.response.text();
  console.log('[clipper] Gemini moments response:', responseText.slice(0, 500));

  const jsonMatch = responseText.match(/\[[\s\S]*\]/);
  if (!jsonMatch) {
    throw new Error('Could not parse Gemini moments response');
  }

  const parsed = JSON.parse(jsonMatch[0]) as Array<Record<string, unknown>>;

  const moments: DetectedMoment[] = parsed
    .map((m) => {
      const start = Math.max(0, Number(m.startTime));
      const end = Math.min(videoDuration, Number(m.endTime));
      return {
        startTime: start,
        endTime: end,
        actionType: typeof m.actionType === 'string' ? m.actionType : 'Moment',
        intensity: typeof m.intensity === 'number' ? m.intensity : 5,
        description:
          typeof m.description === 'string' ? m.description : 'No description',
      };
    })
    .filter(
      (m) =>
        Number.isFinite(m.startTime) &&
        Number.isFinite(m.endTime) &&
        m.endTime - m.startTime >= 2
    )
    .sort((a, b) => a.startTime - b.startTime);

  // Remove overlaps: if a moment starts before the previous one ends, trim its start
  for (let i = 1; i < moments.length; i++) {
    if (moments[i].startTime < moments[i - 1].endTime) {
      moments[i] = {
        ...moments[i],
        startTime: moments[i - 1].endTime,
      };
    }
  }

  return moments.filter((m) => m.endTime - m.startTime >= 2);
}
