import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL } from '@ffmpeg/util';

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

export async function initFFmpeg(): Promise<FFmpeg> {
  if (ffmpegInstance?.loaded) {
    return ffmpegInstance;
  }

  // Reuse in-flight load to prevent double initialization
  if (loadPromise) {
    return loadPromise;
  }

  loadPromise = (async () => {
    const ffmpeg = new FFmpeg();
    const baseURL = 'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd';

    ffmpeg.on('log', ({ message }) => {
      console.log('[ffmpeg]', message);
    });

    console.log('[clipper] Loading FFmpeg core...');
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
    console.log('[clipper] FFmpeg loaded successfully');

    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  try {
    return await loadPromise;
  } catch (error) {
    loadPromise = null;
    console.error('[clipper] Failed to load FFmpeg:', error);
    throw error;
  }
}

// Get video duration using the browser's native video element (fast, no FFmpeg needed)
export async function getVideoDurationFromBuffer(
  videoBuffer: Uint8Array
): Promise<number> {
  return new Promise((resolve, reject) => {
    const blob = new Blob([videoBuffer], { type: 'video/mp4' });
    const video = document.createElement('video');
    const url = URL.createObjectURL(blob);

    const timeout = setTimeout(() => {
      URL.revokeObjectURL(url);
      reject(new Error('Timeout getting video duration'));
    }, 15000);

    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      clearTimeout(timeout);
      const duration = video.duration;
      URL.revokeObjectURL(url);
      resolve(duration);
    };

    video.onerror = () => {
      clearTimeout(timeout);
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load video metadata'));
    };

    video.src = url;
  });
}

// Convert a Blob to a base64 string (without the data URL prefix)
function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      // Strip the "data:image/jpeg;base64," prefix
      const base64 = result.split(',')[1] || '';
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Extract frames as base64 JPEG images for AI analysis
export async function extractFramesAsImages(
  videoBuffer: Uint8Array,
  duration: number,
  intervalSeconds: number = 2,
  onProgress?: (current: number, total: number) => void,
  maxFrames: number = 16
): Promise<Array<{ timestamp: number; imageBase64: string }>> {
  const ffmpeg = await initFFmpeg();

  // Copy the buffer — writeFile transfers it to the worker, detaching the original
  await ffmpeg.writeFile('input.mp4', new Uint8Array(videoBuffer.slice()));

  let timestamps: number[] = [];
  for (let i = 0; i < duration; i += intervalSeconds) {
    timestamps.push(Math.floor(i));
  }

  // Cap the number of frames so extraction never takes too long —
  // resample evenly across the whole video if we have too many.
  if (timestamps.length > maxFrames) {
    const step = duration / maxFrames;
    timestamps = [];
    for (let i = 0; i < maxFrames; i++) {
      timestamps.push(Math.floor(i * step));
    }
  }

  const frames: Array<{ timestamp: number; imageBase64: string }> = [];

  for (let idx = 0; idx < timestamps.length; idx++) {
    const timestamp = timestamps[idx];
    onProgress?.(idx + 1, timestamps.length);
    const frameFile = `frame_${timestamp}.jpg`;
    try {
      await ffmpeg.exec(
        [
          '-ss', timestamp.toString(),
          '-i', 'input.mp4',
          '-frames:v', '1',
          '-vf', 'scale=640:-1',
          '-q:v', '5',
          frameFile,
        ],
        15000 // per-frame timeout so extraction can never hang
      );

      const frameBuffer = (await ffmpeg.readFile(frameFile)) as Uint8Array;
      const blob = new Blob([frameBuffer], { type: 'image/jpeg' });
      const imageBase64 = await blobToBase64(blob);

      frames.push({ timestamp, imageBase64 });
      await ffmpeg.deleteFile(frameFile);
    } catch (error) {
      console.error(`[clipper] Failed to extract frame at ${timestamp}s:`, error);
    }
  }

  await ffmpeg.deleteFile('input.mp4');
  console.log('[clipper] Extracted', frames.length, 'frames');
  return frames;
}

// Cut multiple clips from the video.
// IMPORTANT: uses stream copy (-c copy) — no re-encoding. Re-encoding with
// libx264 inside single-threaded ffmpeg.wasm is extremely slow and makes the
// UI look stuck at "Generating Clips". Stream copy is near-instant.
export async function cutVideoClips(
  videoBuffer: Uint8Array,
  clips: Array<{ startTime: number; endTime: number; clipId: string; description?: string }>,
  onProgress?: (current: number, total: number) => void
): Promise<Array<{ clipId: string; blob: Blob; fileName: string; description?: string }>> {
  const ffmpeg = await initFFmpeg();

  console.log('[clipper] Starting to cut', clips.length, 'clips');
  // Copy the buffer — writeFile transfers it to the worker, detaching the original
  await ffmpeg.writeFile('input.mp4', new Uint8Array(videoBuffer.slice()));

  const results: Array<{ clipId: string; blob: Blob; fileName: string; description?: string }> = [];

  // Per-clip hard timeouts so a single clip can never hang the whole pipeline
  const COPY_TIMEOUT_MS = 30000;
  const REENCODE_TIMEOUT_MS = 120000;

  for (let i = 0; i < clips.length; i++) {
    const clip = clips[i];
    onProgress?.(i + 1, clips.length);

    const outputFileName = `${clip.clipId}.mp4`;
    try {
      const clipDuration = clip.endTime - clip.startTime;
      console.log(`[clipper] Cutting ${clip.clipId} (${clip.startTime}s - ${clip.endTime}s, ${clipDuration}s)`);

      // Fast path: stream copy (no re-encoding). -ss before -i seeks to the
      // nearest keyframe, which is fast and reliable in ffmpeg.wasm.
      let ok = false;
      try {
        const code = await ffmpeg.exec(
          [
            '-ss', clip.startTime.toString(),
            '-i', 'input.mp4',
            '-t', clipDuration.toString(),
            '-c', 'copy',
            '-avoid_negative_ts', 'make_zero',
            '-movflags', 'faststart',
            outputFileName,
          ],
          COPY_TIMEOUT_MS
        );
        ok = code === 0;
      } catch (copyError) {
        console.error(`[clipper] Stream copy failed for ${clip.clipId}:`, copyError);
        ok = false;
      }

      // Validate the copy output — if it failed or is suspiciously tiny,
      // fall back to a fast re-encode for this clip only.
      let clipBuffer: Uint8Array | null = null;
      if (ok) {
        try {
          clipBuffer = (await ffmpeg.readFile(outputFileName)) as Uint8Array;
        } catch {
          clipBuffer = null;
        }
      }

      if (!clipBuffer || clipBuffer.length < 5000) {
        console.log(`[clipper] Copy output invalid for ${clip.clipId}, falling back to re-encode...`);
        try { await ffmpeg.deleteFile(outputFileName); } catch { /* may not exist */ }

        const code = await ffmpeg.exec(
          [
            '-ss', clip.startTime.toString(),
            '-i', 'input.mp4',
            '-t', clipDuration.toString(),
            '-c:v', 'libx264',
            '-preset', 'ultrafast',
            '-crf', '28',
            '-vf', 'scale=-2:720',
            '-c:a', 'aac',
            '-b:a', '96k',
            outputFileName,
          ],
          REENCODE_TIMEOUT_MS
        );
        if (code !== 0) {
          throw new Error(`Re-encode failed with exit code ${code}`);
        }
        clipBuffer = (await ffmpeg.readFile(outputFileName)) as Uint8Array;
      }

      if (!clipBuffer || clipBuffer.length < 1000) {
        throw new Error('Output clip is empty');
      }

      const blob = new Blob([clipBuffer], { type: 'video/mp4' });
      console.log(`[clipper] ${clip.clipId} generated, size:`, blob.size, 'bytes');

      results.push({
        clipId: clip.clipId,
        blob,
        fileName: outputFileName,
        description: clip.description,
      });

      try { await ffmpeg.deleteFile(outputFileName); } catch { /* ignore */ }
    } catch (error) {
      console.error(`[clipper] Failed to cut clip ${clip.clipId}:`, error);
    }
  }

  try { await ffmpeg.deleteFile('input.mp4'); } catch { /* ignore */ }
  console.log('[clipper] Finished cutting all clips, results:', results.length);
  return results;
}
