'use client';

import { useState } from 'react';
import { Zap, Clapperboard, Smartphone } from 'lucide-react';
import { InputForm } from '@/components/input-form';
import { SiteHeader } from '@/components/site-header';
import { ProcessingStatus, type ProcessingStep } from '@/components/processing-status';
import { ClipsGallery } from '@/components/clips-gallery';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [clips, setClips] = useState<Clip[]>([]);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [showResults, setShowResults] = useState(false);

  const updateStep = (stepName: string, status: ProcessingStep['status'], message?: string) => {
    setProcessingSteps((prev) => {
      const existing = prev.find((s) => s.name === stepName);
      if (existing) {
        return prev.map((s) =>
          s.name === stepName ? { ...s, status, message } : s
        );
      }
      return [...prev, { name: stepName, status, message }];
    });
  };

  const handleUrlSubmit = async (url: string) => {
    setIsLoading(true);
    setClips([]);
    setProcessingSteps([]);
    setShowResults(true);

    try {
      // Step 1: Resolve social media URL to direct video URL via ab-downloader
      updateStep('Resolving URL', 'processing', 'Extracting video from social media link...');
      console.log('[clipper] Resolving URL:', url);
      const resolveRes = await fetch('/api/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const resolveData = await resolveRes.json();
      if (!resolveRes.ok) {
        throw new Error(resolveData.error || 'Failed to resolve video URL');
      }
      const { videoUrl, title } = resolveData as { videoUrl: string; title: string };
      console.log('[clipper] Resolved video:', title);
      updateStep('Resolving URL', 'completed', title);

      // Step 2: Download video into the browser through the proxy (no storage)
      updateStep('Downloading Video', 'processing', 'Fetching video into your browser...');
      const proxyRes = await fetch(`/api/proxy?url=${encodeURIComponent(videoUrl)}`);
      if (!proxyRes.ok) {
        const err = await proxyRes.json().catch(() => null);
        throw new Error(err?.error || 'Failed to download video');
      }
      const arrayBuffer = await proxyRes.arrayBuffer();
      const videoBuffer = new Uint8Array(arrayBuffer);
      console.log('[clipper] Downloaded video, size:', videoBuffer.length, 'bytes');
      if (videoBuffer.length < 10000) {
        throw new Error('Downloaded file is too small — the link may not contain a video');
      }
      updateStep('Downloading Video', 'completed', `${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`);

      // Step 3: Load FFmpeg
      updateStep('Loading FFmpeg', 'processing', 'Initializing video processing...');
      const { initFFmpeg, extractFramesAsImages, cutVideoClips, getVideoDurationFromBuffer } = await import('@/lib/ffmpeg-client');
      console.log('[clipper] Initializing FFmpeg...');
      await initFFmpeg();
      updateStep('Loading FFmpeg', 'completed');

      // Step 4: Get video duration
      updateStep('Analyzing Video', 'processing', 'Reading video metadata...');
      console.log('[clipper] Getting video duration...');
      const duration = await getVideoDurationFromBuffer(videoBuffer);
      console.log('[clipper] Video duration:', duration, 'seconds');
      updateStep('Analyzing Video', 'completed', `Duration: ${Math.round(duration)}s`);

      // Step 5: AI analysis — the AI returns FULL moments (start → end of scene),
      // so clips are NOT limited to a fixed length and never cut a moment short.
      let detectedMoments: Array<{
        startTime: number;
        endTime: number;
        actionType: string;
        intensity: number;
        description: string;
      }> = [];

      const geminiApiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (geminiApiKey) {
        try {
          updateStep('Detecting Moments', 'processing', 'AI analyzing for crucial moments...');
          const { initGemini, detectMoments } = await import('@/lib/gemini-client');
          initGemini(geminiApiKey);

          // Hard overall timeout: if AI analysis takes too long, abort it and
          // fall back to smart segmentation so processing NEVER hangs here.
          const AI_TIMEOUT_MS = 90000;
          const aiAnalysis = async () => {
            // Denser sampling so the AI can judge where scenes start AND end
            const frameInterval = Math.max(1, Math.min(4, Math.floor(duration / 24) || 1));
            const frames = await extractFramesAsImages(
              videoBuffer,
              duration,
              frameInterval,
              (current, total) => {
                updateStep('Detecting Moments', 'processing', `Extracting frames ${current}/${total}...`);
              }
            );
            console.log('[clipper] Extracted frames:', frames.length);
            if (frames.length === 0) throw new Error('No frames could be extracted');

            updateStep('Detecting Moments', 'processing', `AI analyzing ${frames.length} frames...`);
            return detectMoments(frames, duration);
          };

          detectedMoments = await Promise.race([
            aiAnalysis(),
            new Promise<never>((_, reject) =>
              setTimeout(() => reject(new Error('AI analysis timed out')), AI_TIMEOUT_MS)
            ),
          ]);
          console.log('[clipper] AI detected moments:', detectedMoments);
        } catch (aiError) {
          console.error('[clipper] AI analysis failed, using smart segmentation fallback:', aiError);
          updateStep('Detecting Moments', 'processing', 'AI unavailable — using smart segmentation...');
          detectedMoments = [];
        }
      }

      // Fallback: if AI found nothing, split the video into natural variable-length segments
      if (detectedMoments.length === 0) {
        const segmentCount = Math.min(5, Math.max(2, Math.floor(duration / 20)));
        const base = duration / segmentCount;
        for (let i = 0; i < segmentCount; i++) {
          const start = Math.floor(base * i);
          const end = i === segmentCount - 1 ? Math.floor(duration) : Math.floor(base * (i + 1));
          detectedMoments.push({
            startTime: start,
            endTime: end,
            actionType: 'Highlight',
            intensity: 7,
            description: `Highlight segment ${i + 1} (${start}s - ${end}s)`,
          });
        }
      }
      detectedMoments.sort((a, b) => a.startTime - b.startTime);
      updateStep('Detecting Moments', 'completed', `Found ${detectedMoments.length} moments`);

      // Step 6: Build clip segments directly from the AI moment boundaries —
      // each clip runs from the start of the scene until it fully finishes.
      const clipSegments = detectedMoments.map((moment, index) => {
        const start = Math.max(0, moment.startTime);
        const end = Math.min(duration, Math.max(moment.endTime, start + 3));
        return {
          startTime: start,
          endTime: end,
          clipId: `clip_${index + 1}`,
          description: `${moment.actionType}: ${moment.description}`,
        };
      });
      console.log('[clipper] Clip segments:', clipSegments);

      // Step 7: Generate clips with FFmpeg in the browser
      updateStep('Generating Clips', 'processing', `Cutting ${clipSegments.length} clips...`);
      const generatedClips = await cutVideoClips(videoBuffer, clipSegments, (current, total) => {
        updateStep('Generating Clips', 'processing', `Cutting clip ${current}/${total}...`);
      });

      if (generatedClips.length === 0) {
        throw new Error('Failed to generate clips from this video');
      }

      const clipsData: Clip[] = generatedClips.map((clip) => {
        const segIndex = clipSegments.findIndex((s) => s.clipId === clip.clipId);
        const seg = clipSegments[segIndex];
        return {
          clipId: clip.clipId,
          startTime: seg.startTime,
          endTime: seg.endTime,
          description: seg.description,
          intensity: detectedMoments[segIndex]?.intensity ?? 7,
          duration: seg.endTime - seg.startTime,
          blobUrl: URL.createObjectURL(clip.blob),
          fileSize: clip.blob.size,
        };
      });

      setClips(clipsData);
      updateStep('Generating Clips', 'completed', `Generated ${clipsData.length} clips`);
      updateStep('Complete', 'completed', 'Ready to download your clips!');

      console.log('[clipper] Processing complete. Clips:', clipsData.length);
    } catch (error) {
      console.error('[clipper] Error processing video:', error);
      updateStep('Error', 'error', error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-background">
<SiteHeader />
{/* Hero Section */}
<section className="relative pt-24 pb-20 px-4 border-b border-border overflow-hidden">
  {/* Animated gradient orbs */}
  <div className="absolute inset-0 -z-10">
    <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-float-slow" />
    <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl animate-float-slower" />
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-3xl animate-pulse-glow" />
  </div>

  {/* Grid background dengan fade */}
  <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:48px_48px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,black,transparent)]" />

  {/* Floating particles */}
  <div className="absolute inset-0 -z-10 pointer-events-none">
    {[...Array(6)].map((_, i) => (
      <span
        key={i}
        className="absolute w-1 h-1 bg-primary/60 rounded-full animate-particle"
        style={{
          left: `${15 + i * 14}%`,
          top: `${20 + (i % 3) * 25}%`,
          animationDelay: `${i * 0.8}s`,
        }}
      />
    ))}
  </div>

  <div className="max-w-4xl mx-auto text-center">
    {/* Badge dengan glow pulse & shimmer border */}
    <div className="group inline-flex items-center gap-2 mb-6 px-4 py-2 bg-primary/10 border border-primary/30 rounded-full backdrop-blur-sm animate-fade-in-up shadow-[0_0_20px_-5px] shadow-primary/40 hover:shadow-primary/70 transition-shadow duration-500">
      <span className="relative flex h-2 w-2">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
        <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
      </span>
      <p className="text-sm font-medium text-primary">AI-Powered Video Clipping</p>
    </div>

    {/* Headline dengan gradient shimmer */}
    <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 animate-fade-in-up [animation-delay:150ms] opacity-0 [animation-fill-mode:forwards]">
      <span className="bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
        Ubah Video Panjang Jadi Klip Viral
      </span>
    </h1>

    <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 animate-fade-in-up [animation-delay:300ms] opacity-0 [animation-fill-mode:forwards]">
      Biarkan AI memotong momen terbaik dari videomu secara otomatis, siap diunggah dalam hitungan detik.
    </p>

    {/* CTA dengan hover glow & scale */}
    <div className="flex items-center justify-center gap-4 animate-fade-in-up [animation-delay:450ms] opacity-0 [animation-fill-mode:forwards]">
      <button className="relative px-8 py-3 rounded-full bg-primary text-primary-foreground font-semibold overflow-hidden transition-transform duration-300 hover:scale-105 shadow-[0_0_30px_-8px] shadow-primary/60 group">
        <span className="relative z-10">Mulai Gratis</span>
        <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
      </button>
      <button className="px-8 py-3 rounded-full border border-border font-semibold hover:border-primary/50 hover:bg-primary/5 transition-all duration-300 hover:scale-105">
        Lihat Demo
      </button>
    </div>
  </div>
</section>

          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-b from-foreground to-muted-foreground bg-clip-text text-transparent text-balance">
            Extract Epic Moments Instantly
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8 text-pretty">
            Paste any TikTok, Instagram, YouTube, Facebook, or Twitter/X link and get viral-worthy clips. AI detects the best moments automatically.
          </p>
          <div className="flex gap-8 justify-center flex-wrap">
            <div className="flex flex-col items-center gap-2">
              <Zap className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Auto-detect</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Clapperboard className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Multi-clips</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Smartphone className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">All Platforms</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4">
        <div className="space-y-12">
          {/* Input Form */}
          <InputForm
            onSubmit={handleUrlSubmit}
            isLoading={isLoading}
          />

          {/* Processing Status */}
          {showResults && (
            <ProcessingStatus
              steps={processingSteps}
              isComplete={!isLoading && clips.length > 0}
              clipsCount={clips.length}
            />
          )}

          {/* Clips Gallery */}
          {clips.length > 0 && !isLoading && (
            <div className="py-8">
              <ClipsGallery clips={clips} />
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-10 px-4 mt-16 bg-card/30">
        <div className="max-w-6xl mx-auto flex flex-col items-center gap-3 text-center">
          <p className="text-sm font-medium tracking-wide text-foreground">
            {'\u00A9'} {new Date().getFullYear()} IClip {'\u2014'} All Rights Reserved
          </p>
          <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
            Made <span className="text-destructive" aria-hidden="true">{'\u2665'}</span>{' '}
            <span className="sr-only">love</span>
            by <span className="font-semibold text-primary">Izzul</span>
          </p>
        </div>
      </footer>
    </main>
  );
}
