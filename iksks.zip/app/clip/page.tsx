import Link from 'next/link';
import { ArrowLeft, Link2, Sparkles } from 'lucide-react';
import { SiteHeader } from '@/components/site-header';
import { ClipTool } from '@/components/clip-tool';

export const metadata = {
  title: 'Clipper - Potong Klip dari URL | IClip',
  description:
    'Tempel link TikTok, Instagram, YouTube, Facebook, atau Twitter/X dan biarkan AI memotong momen terbaiknya jadi klip.',
};

export default function ClipPage() {
  return (
    <main className="min-h-screen bg-background">
      <SiteHeader />

      {/* Page heading */}
      <section className="relative border-b border-border px-4 pt-16 pb-12 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/3 h-72 w-72 rounded-full bg-primary/15 blur-3xl" />
          <div className="absolute bottom-0 right-1/3 h-64 w-64 rounded-full bg-cyan-500/10 blur-3xl" />
        </div>

        <div className="mx-auto max-w-3xl text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            <ArrowLeft className="h-4 w-4" />
            Kembali ke beranda
          </Link>

          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wide text-primary">
            <Sparkles className="h-3.5 w-3.5" />
            AI CLIPPER
          </div>

          <h1 className="mt-4 flex items-center justify-center gap-3 text-3xl font-bold tracking-tight text-balance md:text-4xl">
            <Link2 className="h-7 w-7 text-primary" />
            Potong Klip dari URL
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-pretty text-muted-foreground">
            Tempel link video sosial media, lalu AI akan mendeteksi momen paling menarik dan
            memotongnya menjadi klip siap unggah — bukan sekadar membelah video jadi beberapa bagian.
          </p>
        </div>
      </section>

      {/* Clipper tool */}
      <section className="px-4 py-16">
        <ClipTool />
      </section>
    </main>
  );
}
