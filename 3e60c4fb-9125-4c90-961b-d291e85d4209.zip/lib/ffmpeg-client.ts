import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL } from '@ffmpeg/util';

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

export async function initFFmpeg(): Promise<FFmpeg> {
  if (ffmpegInstance?.loaded) {
    return ffmpegInstance;
  }

  // Reuse in-flight load to prevent double initialization
  if (loadPromise) {
    return loadPromise;
  }

  loadPromise = (async () => {
    const ffmpeg = new FFmpeg();
    const baseURL = 'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd';

    ffmpeg.on('log', ({ message }) => {
      console.log('[v0 FFmpeg]', message);
    });

    console.log('[v0] Loading FFmpeg core...');
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
    console.log('[v0] FFmpeg loaded successfully');

    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  try {
    return await loadPromise;
  } catch (error) {
    loadPromise = null;
    console.error('[v0] Failed to load FFmpeg:', error);
    throw error;
  }
}

// Get video duration using the browser's native video element (fast, no FFmpeg needed)
export async function getVideoDurationFromBuffer(
  videoBuffer: Uint8Array
): Promise<number> {
  return new Promise((resolve, reject) => {
    const blob = new Blob([videoBuffer], { type: 'video/mp4' });
    const video = document.createElement('video');
    const url = URL.createObjectURL(blob);

    const timeout = setTimeout(() => {
      URL.revokeObjectURL(url);
      reject(new Error('Timeout getting video duration'));
    }, 15000);

    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      clearTimeout(timeout);
      const duration = video.duration;
      URL.revokeObjectURL(url);
      resolve(duration);
    };

    video.onerror = () => {
      clearTimeout(timeout);
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load video metadata'));
    };

    video.src = url;
  });
}

// Convert a Blob to a base64 string (without the data URL prefix)
function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      // Strip the "data:image/jpeg;base64," prefix
      const base64 = result.split(',')[1] || '';
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Extract frames as base64 JPEG images for AI analysis
export async function extractFramesAsImages(
  videoBuffer: Uint8Array,
  duration: number,
  intervalSeconds: number = 2
): Promise<Array<{ timestamp: number; imageBase64: string }>> {
  const ffmpeg = await initFFmpeg();

  await ffmpeg.writeFile('input.mp4', videoBuffer);

  const timestamps: number[] = [];
  for (let i = 0; i < duration; i += intervalSeconds) {
    timestamps.push(Math.floor(i));
  }

  const frames: Array<{ timestamp: number; imageBase64: string }> = [];

  for (const timestamp of timestamps) {
    const frameFile = `frame_${timestamp}.jpg`;
    try {
      await ffmpeg.exec([
        '-ss', timestamp.toString(),
        '-i', 'input.mp4',
        '-frames:v', '1',
        '-vf', 'scale=640:-1',
        '-q:v', '5',
        frameFile,
      ]);

      const frameBuffer = (await ffmpeg.readFile(frameFile)) as Uint8Array;
      const blob = new Blob([frameBuffer], { type: 'image/jpeg' });
      const imageBase64 = await blobToBase64(blob);

      frames.push({ timestamp, imageBase64 });
      await ffmpeg.deleteFile(frameFile);
    } catch (error) {
      console.error(`[v0] Failed to extract frame at ${timestamp}s:`, error);
    }
  }

  await ffmpeg.deleteFile('input.mp4');
  console.log('[v0] Extracted', frames.length, 'frames');
  return frames;
}

// Cut multiple clips from the video
export async function cutVideoClips(
  videoBuffer: Uint8Array,
  clips: Array<{ startTime: number; endTime: number; clipId: string; description?: string }>,
  onProgress?: (current: number, total: number) => void
): Promise<Array<{ clipId: string; blob: Blob; fileName: string; description?: string }>> {
  const ffmpeg = await initFFmpeg();

  console.log('[v0] Starting to cut', clips.length, 'clips');
  await ffmpeg.writeFile('input.mp4', videoBuffer);

  const results: Array<{ clipId: string; blob: Blob; fileName: string; description?: string }> = [];

  for (let i = 0; i < clips.length; i++) {
    const clip = clips[i];
    onProgress?.(i + 1, clips.length);

    const outputFileName = `${clip.clipId}.mp4`;
    try {
      const clipDuration = clip.endTime - clip.startTime;
      console.log(`[v0] Cutting ${clip.clipId} (${clip.startTime}s - ${clip.endTime}s)`);

      await ffmpeg.exec([
        '-ss', clip.startTime.toString(),
        '-i', 'input.mp4',
        '-t', clipDuration.toString(),
        '-c:v', 'libx264',
        '-preset', 'ultrafast',
        '-crf', '26',
        '-c:a', 'aac',
        '-b:a', '128k',
        outputFileName,
      ]);

      const clipBuffer = (await ffmpeg.readFile(outputFileName)) as Uint8Array;
      const blob = new Blob([clipBuffer], { type: 'video/mp4' });

      console.log(`[v0] ${clip.clipId} generated, size:`, blob.size, 'bytes');

      results.push({
        clipId: clip.clipId,
        blob,
        fileName: outputFileName,
        description: clip.description,
      });

      await ffmpeg.deleteFile(outputFileName);
    } catch (error) {
      console.error(`[v0] Failed to cut clip ${clip.clipId}:`, error);
    }
  }

  await ffmpeg.deleteFile('input.mp4');
  console.log('[v0] Finished cutting all clips');
  return results;
}
