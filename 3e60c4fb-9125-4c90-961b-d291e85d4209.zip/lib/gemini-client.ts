import { GoogleGenerativeAI } from '@google/generative-ai';

let genAI: GoogleGenerativeAI | null = null;

export function initGemini(apiKey: string) {
  genAI = new GoogleGenerativeAI(apiKey);
}

export async function analyzeFrameForExcitingMoments(
  imageBase64: string,
  mimeType: string = 'image/jpeg'
): Promise<{
  isExciting: boolean;
  actionType: string;
  intensity: number;
  description: string;
}> {
  if (!genAI) {
    throw new Error('Gemini API not initialized. Call initGemini first.');
  }

  const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });

  const response = await model.generateContent([
    {
      inlineData: {
        mimeType: mimeType as any,
        data: imageBase64,
      },
    },
    {
      text: `Analyze this video frame and determine if it's an exciting/action-packed moment. 

For gaming/esports content, look for: kills, ultimate abilities, team fights, wins, close calls, amazing plays, critical moments, etc.

Respond ONLY with valid JSON (no markdown, no extra text):
{
  "isExciting": boolean,
  "actionType": "string describing action type",
  "intensity": number between 1-10,
  "description": "brief description of what's happening"
}`,
    },
  ]);

  const responseText = response.response.text();
  console.log('[v0] Gemini response:', responseText);

  // Extract JSON from response
  const jsonMatch = responseText.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('Could not parse Gemini response');
  }

  const analysis = JSON.parse(jsonMatch[0]);
  return {
    isExciting: analysis.isExciting || false,
    actionType: analysis.actionType || 'Unknown',
    intensity: analysis.intensity || 5,
    description: analysis.description || 'No description',
  };
}

export async function analyzeMultipleFrames(
  frames: Array<{ timestamp: number; imageBase64: string }>,
  onProgress?: (current: number, total: number) => void
): Promise<
  Array<{
    timestamp: number;
    isExciting: boolean;
    actionType: string;
    intensity: number;
    description: string;
  }>
> {
  const results = [];

  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i];
    onProgress?.(i + 1, frames.length);

    try {
      const analysis = await analyzeFrameForExcitingMoments(frame.imageBase64);
      results.push({
        timestamp: frame.timestamp,
        ...analysis,
      });

      // Add small delay to avoid rate limiting
      await new Promise((resolve) => setTimeout(resolve, 500));
    } catch (error) {
      console.error(`[v0] Failed to analyze frame at ${frame.timestamp}s:`, error);
      results.push({
        timestamp: frame.timestamp,
        isExciting: false,
        actionType: 'Error',
        intensity: 0,
        description: 'Failed to analyze',
      });
    }
  }

  return results;
}
