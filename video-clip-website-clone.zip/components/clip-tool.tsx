'use client';

import { useState } from 'react';
import { InputForm } from '@/components/input-form';
import { ProcessingStatus, type ProcessingStep } from '@/components/processing-status';
import { ClipsGallery } from '@/components/clips-gallery';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

export function ClipTool() {
  const [isLoading, setIsLoading] = useState(false);
  const [clips, setClips] = useState<Clip[]>([]);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [showResults, setShowResults] = useState(false);

  const updateStep = (
    stepName: string,
    status: ProcessingStep['status'],
    message?: string
  ) => {
    setProcessingSteps((prev) => {
      const existing = prev.find((s) => s.name === stepName);
      if (existing) {
        return prev.map((s) =>
          s.name === stepName ? { ...s, status, message } : s
        );
      }
      return [...prev, { name: stepName, status, message }];
    });
  };

  const handleUrlSubmit = async (url: string) => {
    setIsLoading(true);
    setClips([]);
    setProcessingSteps([]);
    setShowResults(true);

    try {
      // ── Step 1: Resolve social media URL ──────────────────────────────────
      updateStep('Resolving URL', 'processing', 'Mengekstrak video dari link sosial media...');
      console.log('[clipper] Resolving URL:', url);

      const resolveRes = await fetch('/api/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const resolveData = await resolveRes.json();
      if (!resolveRes.ok) {
        throw new Error(resolveData.error || 'Failed to resolve video URL');
      }
      const { videoUrl, title } = resolveData as { videoUrl: string; title: string };
      console.log('[clipper] Resolved video:', title);
      updateStep('Resolving URL', 'completed', title);

      // Build the proxy URL — used for streaming seeks AND for the full download
      const proxyUrl = `/api/proxy?url=${encodeURIComponent(videoUrl)}`;

      // ── Step 2: Kick off full download in background (parallel with frames) ─
      // PERFORMANCE WIN: download runs while frame extraction + AI run.
      // For most videos it will be complete (or nearly complete) by the time
      // we need it for FFmpeg cutting.
      updateStep('Downloading Video', 'processing', 'Download berjalan di latar belakang...');

      const downloadPromise = fetch(proxyUrl)
        .then(async (res) => {
          if (!res.ok) {
            const err = await res.json().catch(() => null);
            throw new Error(err?.error || `Proxy returned ${res.status}`);
          }
          const ab = await res.arrayBuffer();
          const buf = new Uint8Array(ab);
          if (buf.length < 10000) {
            throw new Error('File terlalu kecil — link mungkin tidak mengandung video');
          }
          console.log(
            '[clipper] Download complete:',
            (buf.length / 1024 / 1024).toFixed(1),
            'MB'
          );
          updateStep(
            'Downloading Video',
            'completed',
            `${(buf.length / 1024 / 1024).toFixed(2)} MB`
          );
          return buf;
        });

      // ── Step 3: Get duration (range-request, <1 s even for 2hr videos) ────
      updateStep('Analyzing Video', 'processing', 'Membaca metadata video...');
      const { getVideoDurationFromUrl, extractFramesFromUrl, initFFmpeg, cutVideoClips } =
        await import('@/lib/ffmpeg-client');

      const duration = await getVideoDurationFromUrl(proxyUrl);
      console.log(
        '[clipper] Duration:',
        duration,
        's (',
        (duration / 60).toFixed(1),
        'min )'
      );
      updateStep(
        'Analyzing Video',
        'completed',
        `Durasi: ${Math.floor(duration / 60)}m ${Math.round(duration % 60)}s`
      );

      // ── Step 4: Extract frames via proxy streaming ────────────────────────
      // THE CORE FIX FOR "STUCK AT 1/32":
      //   We point the <video> element at the HTTP proxy URL (not a blob URL).
      //   The browser uses HTTP Range requests to seek to each timestamp in O(1).
      //   No full download is needed. Works instantly on 2hr+ videos.
      updateStep('Extracting Frames', 'processing', 'Mengambil frame untuk analisis...');

      const frames = await extractFramesFromUrl(
        proxyUrl,
        duration,
        (current, total) => {
          updateStep(
            'Extracting Frames',
            'processing',
            `Mengambil frame ${current}/${total}...`
          );
        }
      );

      console.log('[clipper] Extracted frames:', frames.length);
      if (frames.length === 0) {
        throw new Error('Tidak ada frame yang bisa diekstrak dari video ini');
      }
      updateStep('Extracting Frames', 'completed', `${frames.length} frame`);

      // ── Step 5: FFmpeg pre-init (run while AI analysis runs below) ─────────
      updateStep('Loading FFmpeg', 'processing', 'Memuat pemroses video...');
      const ffmpegInitPromise = initFFmpeg();

      // ── Step 6: Moment detection ──────────────────────────────────────────
      let detectedMoments: Array<{
        startTime: number;
        endTime: number;
        actionType: string;
        intensity: number;
        description: string;
      }> = [];
      let detectionMethod: 'ai' | 'motion' = 'motion';
      let aiFailReason = '';

      const { looksLikeUniformSplit, detectMotionMoments } = await import(
        '@/lib/motion-detect'
      );

      const geminiApiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (geminiApiKey) {
        try {
          updateStep(
            'Detecting Moments',
            'processing',
            `AI menganalisis ${frames.length} frame...`
          );
          const { initGemini, detectMoments } = await import('@/lib/gemini-client');
          initGemini(geminiApiKey);

          const AI_TIMEOUT_MS = 120000;
          const aiMoments = await Promise.race([
            detectMoments(frames, duration),
            new Promise<never>((_, reject) =>
              setTimeout(
                () => reject(new Error('AI analysis timed out')),
                AI_TIMEOUT_MS
              )
            ),
          ]);
          console.log('[clipper] AI detected moments:', aiMoments);

          if (aiMoments.length > 0 && looksLikeUniformSplit(aiMoments, duration)) {
            aiFailReason = 'Output AI berupa potongan seragam — ditolak';
            console.log('[clipper] AI output rejected: uniform split');
          } else if (aiMoments.length > 0) {
            detectedMoments = aiMoments;
            detectionMethod = 'ai';
          } else {
            aiFailReason = 'AI tidak menemukan momen';
          }
        } catch (aiError) {
          aiFailReason =
            aiError instanceof Error ? aiError.message : 'AI error';
          console.error('[clipper] AI analysis failed:', aiError);
        }
      } else {
        aiFailReason = 'NEXT_PUBLIC_GEMINI_API_KEY belum diset';
      }

      if (detectedMoments.length === 0) {
        updateStep(
          'Detecting Moments',
          'processing',
          `AI tidak tersedia (${aiFailReason}) — menganalisis gerakan antar frame...`
        );
        detectedMoments = await detectMotionMoments(frames, duration, 5);
        console.log('[clipper] Motion-based moments:', detectedMoments);
      }

      if (detectedMoments.length === 0) {
        throw new Error(
          'Tidak ada momen menarik yang terdeteksi. Coba video lain yang memiliki aksi atau perubahan adegan.'
        );
      }

      detectedMoments.sort((a, b) => a.startTime - b.startTime);
      updateStep(
        'Detecting Moments',
        'completed',
        detectionMethod === 'ai'
          ? `AI menemukan ${detectedMoments.length} momen penting`
          : `${detectedMoments.length} momen aksi dari analisis gerakan`
      );

      const clipSegments = detectedMoments.map((moment, index) => {
        const start = Math.max(0, moment.startTime);
        const end = Math.min(duration, Math.max(moment.endTime, start + 3));
        return {
          startTime: start,
          endTime: end,
          clipId: `clip_${index + 1}`,
          description: `${moment.actionType}: ${moment.description}`,
        };
      });
      console.log('[clipper] Clip segments:', clipSegments);

      // ── Step 7: Wait for FFmpeg init + video download (both ran in parallel) ─
      // Both started earlier and have been running while AI was working.
      await ffmpegInitPromise;
      updateStep('Loading FFmpeg', 'completed');

      // Show a waiting message only if download is not done yet
      const videoBuffer = await downloadPromise;

      // ── Step 8: Cut clips ─────────────────────────────────────────────────
      updateStep(
        'Generating Clips',
        'processing',
        `Memotong ${clipSegments.length} klip...`
      );
      const generatedClips = await cutVideoClips(
        videoBuffer,
        clipSegments,
        (current, total) => {
          updateStep(
            'Generating Clips',
            'processing',
            `Memotong klip ${current}/${total}...`
          );
        }
      );

      if (generatedClips.length === 0) {
        throw new Error('Gagal membuat klip dari video ini');
      }

      const clipsData: Clip[] = generatedClips.map((clip) => {
        const segIndex = clipSegments.findIndex((s) => s.clipId === clip.clipId);
        const seg = clipSegments[segIndex];
        return {
          clipId: clip.clipId,
          startTime: seg.startTime,
          endTime: seg.endTime,
          description: seg.description,
          intensity: detectedMoments[segIndex]?.intensity ?? 7,
          duration: seg.endTime - seg.startTime,
          blobUrl: URL.createObjectURL(clip.blob),
          fileSize: clip.blob.size,
        };
      });

      setClips(clipsData);
      updateStep(
        'Generating Clips',
        'completed',
        `${clipsData.length} klip berhasil dibuat`
      );
      updateStep('Complete', 'completed', 'Klip siap diunduh!');

      console.log('[clipper] Processing complete. Clips:', clipsData.length);
    } catch (error) {
      console.error('[clipper] Error processing video:', error);
      updateStep(
        'Error',
        'error',
        error instanceof Error ? error.message : 'Unknown error occurred'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-12">
      <InputForm onSubmit={handleUrlSubmit} isLoading={isLoading} />

      {showResults && (
        <ProcessingStatus
          steps={processingSteps}
          isComplete={!isLoading && clips.length > 0}
          clipsCount={clips.length}
        />
      )}

      {clips.length > 0 && !isLoading && (
        <div className="py-8">
          <ClipsGallery clips={clips} />
        </div>
      )}
    </div>
  );
}
