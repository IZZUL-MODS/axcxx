/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  // Required so ab-downloader (and other Node-only packages) run in Node runtime
  serverExternalPackages: ['ab-downloader'],
  images: {
    unoptimized: true,
  },

  // HTTP response headers applied globally
  async headers() {
    return [
      {
        // Cross-Origin Isolation enables SharedArrayBuffer, which @ffmpeg/ffmpeg
        // uses for multi-threaded WASM. Without these headers FFmpeg falls back
        // to single-thread mode and is 3-5x slower.
        source: '/(.*)',
        headers: [
          { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
          { key: 'Cross-Origin-Embedder-Policy', value: 'require-corp' },
        ],
      },
      {
        // Allow the proxy to serve video bytes to <video crossOrigin="anonymous">
        source: '/api/proxy',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Expose-Headers', value: 'Content-Length, Content-Range, Accept-Ranges' },
        ],
      },
    ];
  },
};

export default nextConfig
