'use client';

import { useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, Zap, Bot, Clapperboard, Check } from 'lucide-react';

interface InputFormProps {
  onSubmit: (videoBuffer: Uint8Array, fileName: string) => Promise<void>;
  isLoading: boolean;
}

export function InputForm({ onSubmit, isLoading }: InputFormProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [fileName, setFileName] = useState<string>('');

  const handleFileSelect = async (file: File) => {
    if (!file.type.startsWith('video/')) {
      alert('Please select a valid video file');
      return;
    }

    setFileName(file.name);
    const buffer = await file.arrayBuffer();
    const uint8Array = new Uint8Array(buffer);

    console.log('[v0] File selected:', file.name, 'Size:', file.size, 'bytes');
    await onSubmit(uint8Array, file.name);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsHovering(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        onDrop={handleDrop}
        onDragOver={(e) => {
          e.preventDefault();
          setIsHovering(true);
        }}
        onDragLeave={() => setIsHovering(false)}
        className={`relative p-12 rounded-lg border-2 border-dashed transition-all cursor-pointer ${
          isHovering
            ? 'border-accent bg-accent/10'
            : 'border-primary/30 bg-card/50 hover:border-primary/50'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          onChange={handleFileInputChange}
          className="hidden"
          disabled={isLoading}
        />

        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="p-3 bg-primary/20 rounded-lg">
              <Upload className="w-8 h-8 text-primary" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Drop your video here
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              or click to select a file from your computer
            </p>
            <p className="text-xs text-muted-foreground">
              Supports: MP4, WebM, MOV, AVI, and other video formats
            </p>
          </div>

          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="gap-2"
            size="lg"
          >
            <Zap className="w-4 h-4" />
            {isLoading ? 'Processing...' : 'Select Video'}
          </Button>

          {fileName && (
            <p className="text-sm text-primary font-medium pt-2 flex items-center justify-center gap-1">
              <Check className="w-4 h-4" /> {fileName}
            </p>
          )}
        </div>
      </div>

      <div className="mt-6 grid grid-cols-3 gap-4">
        <div className="flex flex-col items-center text-center gap-1">
          <Bot className="w-6 h-6 text-primary mb-1" />
          <p className="text-sm text-muted-foreground">AI Analysis</p>
          <p className="text-xs text-muted-foreground">With Gemini Vision</p>
        </div>
        <div className="flex flex-col items-center text-center gap-1">
          <Zap className="w-6 h-6 text-accent mb-1" />
          <p className="text-sm text-muted-foreground">Instant Clips</p>
          <p className="text-xs text-muted-foreground">Client-side processing</p>
        </div>
        <div className="flex flex-col items-center text-center gap-1">
          <Clapperboard className="w-6 h-6 text-primary mb-1" />
          <p className="text-sm text-muted-foreground">Download Direct</p>
          <p className="text-xs text-muted-foreground">No storage needed</p>
        </div>
      </div>
    </div>
  );
}
