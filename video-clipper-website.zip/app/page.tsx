'use client';

import { useState } from 'react';
import { Zap, Clapperboard, Smartphone } from 'lucide-react';
import { InputForm } from '@/components/input-form';
import { ProcessingStatus, type ProcessingStep } from '@/components/processing-status';
import { ClipsGallery } from '@/components/clips-gallery';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [clips, setClips] = useState<Clip[]>([]);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [showResults, setShowResults] = useState(false);

  const updateStep = (stepName: string, status: ProcessingStep['status'], message?: string) => {
    setProcessingSteps((prev) => {
      const existing = prev.find((s) => s.name === stepName);
      if (existing) {
        return prev.map((s) =>
          s.name === stepName ? { ...s, status, message } : s
        );
      }
      return [...prev, { name: stepName, status, message }];
    });
  };

  const handleVideoSubmit = async (videoBuffer: Uint8Array, fileName: string) => {
    setIsLoading(true);
    setClips([]);
    setProcessingSteps([]);
    setShowResults(true);

    try {
      // Import utilities
      const { initGemini, analyzeMultipleFrames } = await import('@/lib/gemini-client');
      const { initFFmpeg, extractFramesAsImages, cutVideoClips, getVideoDurationFromBuffer } = await import('@/lib/ffmpeg-client');

      // Initialize Gemini with API key
      const geminiApiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (!geminiApiKey) {
        throw new Error('Gemini API key not configured');
      }
      initGemini(geminiApiKey);

      // Step 1: Load FFmpeg
      updateStep('Loading FFmpeg', 'processing', 'Initializing video processing...');
      console.log('[v0] Initializing FFmpeg...');
      await initFFmpeg();
      updateStep('Loading FFmpeg', 'completed');

      // Step 2: Get video duration
      updateStep('Analyzing Video', 'processing', 'Reading video metadata...');
      console.log('[v0] Getting video duration...');
      const duration = await getVideoDurationFromBuffer(videoBuffer);
      console.log('[v0] Video duration:', duration, 'seconds');
      updateStep('Analyzing Video', 'completed', `Duration: ${Math.round(duration)}s`);

      // Step 3: Extract frames for AI analysis
      updateStep('Analyzing Video', 'processing', 'AI analyzing for exciting moments...');
      console.log('[v0] Extracting frames...');
      const frameInterval = Math.max(2, Math.floor(duration / 20)); // Extract ~20 frames or every 2s
      const frames = await extractFramesAsImages(videoBuffer, duration, frameInterval);
      console.log('[v0] Extracted frames:', frames.length);

      // Step 4: Analyze frames with Gemini (frames already contain base64 data)
      updateStep('Analyzing Video', 'processing', `Analyzing ${frames.length} frames with AI...`);
      const analysis = await analyzeMultipleFrames(frames, (current, total) => {
        updateStep('Analyzing Video', 'processing', `Analyzing frame ${current}/${total}...`);
      });
      console.log('[v0] Analysis completed:', analysis);

      // Step 5: Identify exciting clips based on intensity
      updateStep('Detecting Moments', 'processing', 'Finding the best clips...');
      const excitingMoments = analysis.filter((a) => a.isExciting && a.intensity >= 6);
      console.log('[v0] Found exciting moments:', excitingMoments.length);

      if (excitingMoments.length === 0) {
        throw new Error('No exciting moments detected in video. Try a different video with action scenes.');
      }

      // Create clip segments with 1-2 second buffer before and after
      const clipSegments = excitingMoments.map((moment, index) => ({
        startTime: Math.max(0, moment.timestamp - 2),
        endTime: Math.min(duration, moment.timestamp + 8), // 10 second clips around exciting moment
        clipId: `clip_${index + 1}`,
        description: `${moment.actionType}: ${moment.description}`,
      }));

      console.log('[v0] Clip segments:', clipSegments);

      // Step 6: Generate clips with FFmpeg
      updateStep('Generating Clips', 'processing', `Cutting ${clipSegments.length} clips...`);
      const generatedClips = await cutVideoClips(videoBuffer, clipSegments, (current, total) => {
        updateStep('Generating Clips', 'processing', `Cutting clip ${current}/${total}...`);
      });

      // Convert blobs to downloadable clips
      const clipsData: Clip[] = generatedClips.map((clip, index) => ({
        clipId: clip.clipId,
        startTime: clipSegments[index].startTime,
        endTime: clipSegments[index].endTime,
        description: clipSegments[index].description,
        intensity: excitingMoments[index].intensity,
        duration: clipSegments[index].endTime - clipSegments[index].startTime,
        blobUrl: URL.createObjectURL(clip.blob),
        fileSize: clip.blob.size,
      }));

      setClips(clipsData);
      updateStep('Generating Clips', 'completed', `Generated ${clipsData.length} clips`);
      updateStep('Complete', 'completed', 'Ready to download your clips!');

      console.log('[v0] Processing complete. Clips:', clipsData);
    } catch (error) {
      console.error('[v0] Error processing video:', error);
      updateStep('Error', 'error', error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-4 border-b border-border">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block mb-4 px-4 py-2 bg-primary/10 border border-primary/30 rounded-full">
            <p className="text-sm font-medium text-primary">AI-Powered Video Clipping</p>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-b from-foreground to-muted-foreground bg-clip-text text-transparent">
            Extract Epic Moments Instantly
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Turn long gameplay videos and streams into viral-worthy clips. AI detects the best moments automatically.
          </p>
          <div className="flex gap-8 justify-center flex-wrap">
            <div className="flex flex-col items-center gap-2">
              <Zap className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Auto-detect</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Clapperboard className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Multi-clips</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Smartphone className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">All Platforms</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4">
        <div className="space-y-12">
          {/* Input Form */}
          <InputForm
            onSubmit={handleVideoSubmit}
            isLoading={isLoading}
          />

          {/* Processing Status */}
          {showResults && (
            <ProcessingStatus
              steps={processingSteps}
              isComplete={!isLoading && clips.length > 0}
              clipsCount={clips.length}
            />
          )}

          {/* Clips Gallery */}
          {clips.length > 0 && !isLoading && (
            <div className="py-8">
              <ClipsGallery clips={clips} />
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 mt-16 bg-card/30">
        <div className="max-w-6xl mx-auto text-center text-muted-foreground text-sm">
          <p>ClipMaster - AI-Powered Video Clipper for Content Creators</p>
          <p className="mt-2">Powered by advanced AI scene detection and FFmpeg</p>
        </div>
      </footer>
    </main>
  );
}
