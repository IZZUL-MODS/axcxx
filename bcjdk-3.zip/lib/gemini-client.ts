import { GoogleGenerativeAI } from '@google/generative-ai';

let genAI: GoogleGenerativeAI | null = null;

const MODEL_ID = 'gemini-2.5-flash';

export function initGemini(apiKey: string) {
  genAI = new GoogleGenerativeAI(apiKey);
}

export interface FrameAnalysis {
  timestamp: number;
  isExciting: boolean;
  actionType: string;
  intensity: number;
  description: string;
}

// Analyze ALL frames in a single Gemini request.
// This lets the model compare frames against each other and pick the truly
// interesting/special moments, instead of judging each frame in isolation.
export async function analyzeMultipleFrames(
  frames: Array<{ timestamp: number; imageBase64: string }>,
  onProgress?: (current: number, total: number) => void
): Promise<FrameAnalysis[]> {
  if (!genAI) {
    throw new Error('Gemini API not initialized. Call initGemini first.');
  }
  if (frames.length === 0) return [];

  onProgress?.(1, 1);

  const model = genAI.getGenerativeModel({
    model: MODEL_ID,
    generationConfig: {
      responseMimeType: 'application/json',
    },
  });

  const parts: Array<
    | { text: string }
    | { inlineData: { mimeType: string; data: string } }
  > = [];

  parts.push({
    text: `You are an expert viral-video editor. You will receive ${frames.length} frames extracted from a single video, each labeled with its timestamp in seconds. Compare ALL frames against each other and identify which moments are the MOST exciting, interesting, and clip-worthy (action, emotions, funny moments, kills/wins in gaming, reveals, climaxes, dramatic changes, anything special). Be selective: only mark a frame as exciting if it clearly stands out compared to the others.`,
  });

  for (const frame of frames) {
    parts.push({ text: `Frame at timestamp ${frame.timestamp} seconds:` });
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: frame.imageBase64,
      },
    });
  }

  parts.push({
    text: `Now respond ONLY with a valid JSON array (no markdown). One object per frame, in the same order, with this exact shape:
[
  {
    "timestamp": number (the timestamp label of the frame),
    "isExciting": boolean (true only for genuinely special/stand-out moments),
    "actionType": "short label of the action type",
    "intensity": number 1-10 (how exciting/clip-worthy relative to the other frames),
    "description": "brief description of what is happening"
  }
]`,
  });

  try {
    const response = await model.generateContent(parts as never);
    const responseText = response.response.text();
    console.log('[v0] Gemini batch response:', responseText.slice(0, 500));

    const jsonMatch = responseText.match(/\[[\s\S]*\]/);
    if (!jsonMatch) {
      throw new Error('Could not parse Gemini batch response');
    }

    const parsed = JSON.parse(jsonMatch[0]) as Array<Record<string, unknown>>;

    return frames.map((frame, i) => {
      const a =
        parsed.find((p) => Math.abs(Number(p.timestamp) - frame.timestamp) < 1) ||
        parsed[i] ||
        {};
      return {
        timestamp: frame.timestamp,
        isExciting: Boolean(a.isExciting),
        actionType: typeof a.actionType === 'string' ? a.actionType : 'Moment',
        intensity: typeof a.intensity === 'number' ? a.intensity : 5,
        description:
          typeof a.description === 'string' ? a.description : 'No description',
      };
    });
  } catch (batchError) {
    console.error('[v0] Batch analysis failed, falling back to per-frame:', batchError);
    return analyzeFramesOneByOne(frames, onProgress);
  }
}

// Fallback: analyze frames one at a time (slower, used only if batch fails)
async function analyzeFramesOneByOne(
  frames: Array<{ timestamp: number; imageBase64: string }>,
  onProgress?: (current: number, total: number) => void
): Promise<FrameAnalysis[]> {
  if (!genAI) {
    throw new Error('Gemini API not initialized. Call initGemini first.');
  }

  const model = genAI.getGenerativeModel({
    model: MODEL_ID,
    generationConfig: { responseMimeType: 'application/json' },
  });

  const results: FrameAnalysis[] = [];

  for (let i = 0; i < frames.length; i++) {
    const frame = frames[i];
    onProgress?.(i + 1, frames.length);

    try {
      const response = await model.generateContent([
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: frame.imageBase64,
          },
        },
        {
          text: `Analyze this video frame and determine if it's an exciting/action-packed, clip-worthy moment (action, emotion, gaming kills/wins, reveals, funny or dramatic moments).

Respond ONLY with valid JSON:
{
  "isExciting": boolean,
  "actionType": "string describing action type",
  "intensity": number between 1-10,
  "description": "brief description of what's happening"
}`,
        },
      ]);

      const responseText = response.response.text();
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error('Could not parse Gemini response');
      const analysis = JSON.parse(jsonMatch[0]);

      results.push({
        timestamp: frame.timestamp,
        isExciting: Boolean(analysis.isExciting),
        actionType: analysis.actionType || 'Moment',
        intensity: typeof analysis.intensity === 'number' ? analysis.intensity : 5,
        description: analysis.description || 'No description',
      });

      // Small delay to avoid free-tier rate limiting
      await new Promise((resolve) => setTimeout(resolve, 1200));
    } catch (error) {
      console.error(`[v0] Failed to analyze frame at ${frame.timestamp}s:`, error);
      results.push({
        timestamp: frame.timestamp,
        isExciting: false,
        actionType: 'Error',
        intensity: 0,
        description: 'Failed to analyze',
      });
    }
  }

  return results;
}
