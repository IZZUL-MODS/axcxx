'use client';

import { useState } from 'react';
import { Zap, Clapperboard, Smartphone } from 'lucide-react';
import { InputForm } from '@/components/input-form';
import { ProcessingStatus, type ProcessingStep } from '@/components/processing-status';
import { ClipsGallery } from '@/components/clips-gallery';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [clips, setClips] = useState<Clip[]>([]);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [showResults, setShowResults] = useState(false);

  const updateStep = (stepName: string, status: ProcessingStep['status'], message?: string) => {
    setProcessingSteps((prev) => {
      const existing = prev.find((s) => s.name === stepName);
      if (existing) {
        return prev.map((s) =>
          s.name === stepName ? { ...s, status, message } : s
        );
      }
      return [...prev, { name: stepName, status, message }];
    });
  };

  const handleUrlSubmit = async (url: string) => {
    setIsLoading(true);
    setClips([]);
    setProcessingSteps([]);
    setShowResults(true);

    try {
      // Step 1: Resolve social media URL to direct video URL via ab-downloader
      updateStep('Resolving URL', 'processing', 'Extracting video from social media link...');
      console.log('[clipper] Resolving URL:', url);
      const resolveRes = await fetch('/api/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const resolveData = await resolveRes.json();
      if (!resolveRes.ok) {
        throw new Error(resolveData.error || 'Failed to resolve video URL');
      }
      const { videoUrl, title } = resolveData as { videoUrl: string; title: string };
      console.log('[clipper] Resolved video:', title);
      updateStep('Resolving URL', 'completed', title);

      // Step 2: Download video into the browser through the proxy (no storage)
      updateStep('Downloading Video', 'processing', 'Fetching video into your browser...');
      const proxyRes = await fetch(`/api/proxy?url=${encodeURIComponent(videoUrl)}`);
      if (!proxyRes.ok) {
        const err = await proxyRes.json().catch(() => null);
        throw new Error(err?.error || 'Failed to download video');
      }
      const arrayBuffer = await proxyRes.arrayBuffer();
      const videoBuffer = new Uint8Array(arrayBuffer);
      console.log('[clipper] Downloaded video, size:', videoBuffer.length, 'bytes');
      if (videoBuffer.length < 10000) {
        throw new Error('Downloaded file is too small — the link may not contain a video');
      }
      updateStep('Downloading Video', 'completed', `${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`);

      // Step 3: Load FFmpeg
      updateStep('Loading FFmpeg', 'processing', 'Initializing video processing...');
      const { initFFmpeg, extractFramesAsImages, cutVideoClips, getVideoDurationFromBuffer } = await import('@/lib/ffmpeg-client');
      console.log('[clipper] Initializing FFmpeg...');
      await initFFmpeg();
      updateStep('Loading FFmpeg', 'completed');

      // Step 4: Get video duration
      updateStep('Analyzing Video', 'processing', 'Reading video metadata...');
      console.log('[clipper] Getting video duration...');
      const duration = await getVideoDurationFromBuffer(videoBuffer);
      console.log('[clipper] Video duration:', duration, 'seconds');
      updateStep('Analyzing Video', 'completed', `Duration: ${Math.round(duration)}s`);

      // Step 5: AI analysis — the AI returns FULL moments (start → end of scene),
      // so clips are NOT limited to a fixed length and never cut a moment short.
      let detectedMoments: Array<{
        startTime: number;
        endTime: number;
        actionType: string;
        intensity: number;
        description: string;
      }> = [];

      const geminiApiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (geminiApiKey) {
        try {
          updateStep('Detecting Moments', 'processing', 'AI analyzing for crucial moments...');
          const { initGemini, detectMoments } = await import('@/lib/gemini-client');
          initGemini(geminiApiKey);

          // Denser sampling so the AI can judge where scenes start AND end
          const frameInterval = Math.max(1, Math.min(4, Math.floor(duration / 24) || 1));
          const frames = await extractFramesAsImages(videoBuffer, duration, frameInterval);
          console.log('[clipper] Extracted frames:', frames.length);

          detectedMoments = await detectMoments(frames, duration, (current, total) => {
            updateStep('Detecting Moments', 'processing', `Analyzing frames ${current}/${total}...`);
          });
          console.log('[clipper] AI detected moments:', detectedMoments);
        } catch (aiError) {
          console.error('[clipper] AI analysis failed, using smart segmentation fallback:', aiError);
        }
      }

      // Fallback: if AI found nothing, split the video into natural variable-length segments
      if (detectedMoments.length === 0) {
        const segmentCount = Math.min(5, Math.max(2, Math.floor(duration / 20)));
        const base = duration / segmentCount;
        for (let i = 0; i < segmentCount; i++) {
          const start = Math.floor(base * i);
          const end = i === segmentCount - 1 ? Math.floor(duration) : Math.floor(base * (i + 1));
          detectedMoments.push({
            startTime: start,
            endTime: end,
            actionType: 'Highlight',
            intensity: 7,
            description: `Highlight segment ${i + 1} (${start}s - ${end}s)`,
          });
        }
      }
      detectedMoments.sort((a, b) => a.startTime - b.startTime);
      updateStep('Detecting Moments', 'completed', `Found ${detectedMoments.length} moments`);

      // Step 6: Build clip segments directly from the AI moment boundaries —
      // each clip runs from the start of the scene until it fully finishes.
      const clipSegments = detectedMoments.map((moment, index) => {
        const start = Math.max(0, moment.startTime);
        const end = Math.min(duration, Math.max(moment.endTime, start + 3));
        return {
          startTime: start,
          endTime: end,
          clipId: `clip_${index + 1}`,
          description: `${moment.actionType}: ${moment.description}`,
        };
      });
      console.log('[clipper] Clip segments:', clipSegments);

      // Step 7: Generate clips with FFmpeg in the browser
      updateStep('Generating Clips', 'processing', `Cutting ${clipSegments.length} clips...`);
      const generatedClips = await cutVideoClips(videoBuffer, clipSegments, (current, total) => {
        updateStep('Generating Clips', 'processing', `Cutting clip ${current}/${total}...`);
      });

      if (generatedClips.length === 0) {
        throw new Error('Failed to generate clips from this video');
      }

      const clipsData: Clip[] = generatedClips.map((clip) => {
        const segIndex = clipSegments.findIndex((s) => s.clipId === clip.clipId);
        const seg = clipSegments[segIndex];
        return {
          clipId: clip.clipId,
          startTime: seg.startTime,
          endTime: seg.endTime,
          description: seg.description,
          intensity: detectedMoments[segIndex]?.intensity ?? 7,
          duration: seg.endTime - seg.startTime,
          blobUrl: URL.createObjectURL(clip.blob),
          fileSize: clip.blob.size,
        };
      });

      setClips(clipsData);
      updateStep('Generating Clips', 'completed', `Generated ${clipsData.length} clips`);
      updateStep('Complete', 'completed', 'Ready to download your clips!');

      console.log('[clipper] Processing complete. Clips:', clipsData.length);
    } catch (error) {
      console.error('[clipper] Error processing video:', error);
      updateStep('Error', 'error', error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-4 border-b border-border">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block mb-4 px-4 py-2 bg-primary/10 border border-primary/30 rounded-full">
            <p className="text-sm font-medium text-primary">AI-Powered Video Clipping</p>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-b from-foreground to-muted-foreground bg-clip-text text-transparent text-balance">
            Extract Epic Moments Instantly
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8 text-pretty">
            Paste any TikTok, Instagram, YouTube, Facebook, or Twitter/X link and get viral-worthy clips. AI detects the best moments automatically.
          </p>
          <div className="flex gap-8 justify-center flex-wrap">
            <div className="flex flex-col items-center gap-2">
              <Zap className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Auto-detect</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Clapperboard className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Multi-clips</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Smartphone className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">All Platforms</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-16 px-4">
        <div className="space-y-12">
          {/* Input Form */}
          <InputForm
            onSubmit={handleUrlSubmit}
            isLoading={isLoading}
          />

          {/* Processing Status */}
          {showResults && (
            <ProcessingStatus
              steps={processingSteps}
              isComplete={!isLoading && clips.length > 0}
              clipsCount={clips.length}
            />
          )}

          {/* Clips Gallery */}
          {clips.length > 0 && !isLoading && (
            <div className="py-8">
              <ClipsGallery clips={clips} />
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 mt-16 bg-card/30">
        <div className="max-w-6xl mx-auto text-center text-muted-foreground text-sm">
          <p>ClipMaster - AI-Powered Video Clipper for Content Creators</p>
          <p className="mt-2">Powered by ab-downloader, AI scene detection, and FFmpeg</p>
        </div>
      </footer>
    </main>
  );
}
