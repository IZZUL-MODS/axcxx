'use client';

import { useState } from 'react';
import { Download, Share2, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

interface ClipsGalleryProps {
  clips: Clip[];
}

function IntensityBar({ intensity }: { intensity: number }) {
  // intensity is on a 1-10 scale; render 5 bars
  const filledBars = Math.round(intensity / 2);
  return (
    <div className="flex gap-1 items-center">
      {[1, 2, 3, 4, 5].map((level) => (
        <div
          key={level}
          className={`h-1.5 w-4 rounded-full transition-colors ${
            level <= filledBars ? 'bg-accent' : 'bg-muted'
          }`}
        />
      ))}
      <span className="text-xs text-muted-foreground ml-1">{intensity}/10</span>
    </div>
  );
}

export function ClipsGallery({ clips }: ClipsGalleryProps) {
  const [expandedClip, setExpandedClip] = useState<string | null>(null);

  const handleDownload = async (clip: Clip) => {
    if (!clip.blobUrl) {
      alert('Clip URL not available');
      return;
    }

    try {
      const a = document.createElement('a');
      a.href = clip.blobUrl;
      a.download = `${clip.clipId}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      console.log('[clipper] Downloaded clip:', clip.clipId);
    } catch (error) {
      console.error('[clipper] Download error:', error);
      alert('Failed to download clip');
    }
  };

  const handleShare = async (clip: Clip) => {
    const text = `Check out this epic clip! "${clip.description}" - Intensity: ${clip.intensity}/10`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'ClipMaster - Generated Clip',
          text: text,
          url: clip.blobUrl || window.location.href,
        });
      } catch (error) {
        console.error('[clipper] Share error:', error);
      }
    } else {
      navigator.clipboard.writeText(text);
      alert('Clip info copied to clipboard!');
    }
  };

  if (clips.length === 0) {
    return null;
  }

  return (
    <div className="w-full">
      <div className="max-w-6xl mx-auto mb-8">
        <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
          Your Generated Clips
        </h2>
        <p className="text-muted-foreground">
          {clips.length} {clips.length === 1 ? 'clip' : 'clips'} extracted and ready to share
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {clips.map((clip, idx) => (
          <div
            key={clip.clipId}
            className="group bg-card rounded-xl border border-border overflow-hidden hover:border-primary transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
          >
            {/* Video Preview */}
            <div className="relative bg-black aspect-video flex items-center justify-center overflow-hidden">
              {clip.blobUrl ? (
                <video
                  src={clip.blobUrl}
                  controls
                  playsInline
                  preload="metadata"
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="flex flex-col items-center justify-center gap-3">
                  <div className="w-16 h-16 rounded-full bg-primary/20 border-2 border-primary flex items-center justify-center">
                    <Play size={32} className="text-primary fill-primary" />
                  </div>
                  <p className="text-sm font-medium text-foreground">Clip {idx + 1}</p>
                </div>
              )}
              <span className="absolute top-2 left-2 z-10 text-xs font-bold text-primary-foreground bg-primary px-2 py-1 rounded-full">
                Clip {idx + 1}
              </span>
            </div>

            {/* Clip Info */}
            <div className="p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-foreground text-sm line-clamp-2">
                  {clip.description}
                </h3>
                <span className="text-xs font-bold text-accent bg-accent/20 px-2 py-1 rounded-full">
                  #{idx + 1}
                </span>
              </div>

              {/* Duration and Intensity */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Duration: {clip.duration.toFixed(1)}s</span>
                  <span>{(clip.fileSize ? clip.fileSize / 1024 / 1024 : 0).toFixed(2)} MB</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Intensity</span>
                  <IntensityBar intensity={clip.intensity} />
                </div>
              </div>

              {/* Time Range */}
              <div className="bg-secondary rounded px-3 py-2 mb-4">
                <p className="text-xs text-muted-foreground">
                  {clip.startTime.toFixed(1)}s - {clip.endTime.toFixed(1)}s
                </p>
              </div>

              {/* Expandable Details */}
              <button
                onClick={() =>
                  setExpandedClip(expandedClip === clip.clipId ? null : clip.clipId)
                }
                className="text-xs text-primary hover:text-accent mb-4 font-medium"
              >
                {expandedClip === clip.clipId ? 'Hide details' : 'Show details'}
              </button>

              {expandedClip === clip.clipId && (
                <div className="bg-secondary rounded p-3 mb-4 text-xs text-muted-foreground space-y-2 border border-border">
                  <p>
                    <span className="text-foreground font-medium">Clip ID:</span> {clip.clipId}
                  </p>
                  <p>
                    <span className="text-foreground font-medium">Intensity Score:</span> {clip.intensity}/10
                  </p>
                  <p className="line-clamp-3">
                    <span className="text-foreground font-medium">Description:</span> {clip.description}
                  </p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-2">
                <Button
                  onClick={() => handleDownload(clip)}
                  disabled={!clip.blobUrl}
                  variant="outline"
                  size="sm"
                  className="flex-1 gap-2"
                >
                  <Download size={16} />
                  Download
                </Button>
                <Button
                  onClick={() => handleShare(clip)}
                  variant="outline"
                  size="sm"
                  className="flex-1 gap-2"
                >
                  <Share2 size={16} />
                  Share
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bulk Actions */}
      <div className="mt-12 max-w-6xl mx-auto">
        <div className="bg-card rounded-xl border border-border p-6 text-center">
          <h3 className="font-bold text-foreground mb-4">Want more clips?</h3>
          <Button
            onClick={() => window.location.reload()}
            className="bg-gradient-to-r from-primary to-accent hover:opacity-90"
          >
            Clip Another Video
          </Button>
        </div>
      </div>
    </div>
  );
}
