'use client';

import { useState } from 'react';
import { Zap, Clapperboard, Smartphone, Camera, Scissors, Film, Play } from 'lucide-react';
import { InputForm } from '@/components/input-form';
import { SiteHeader } from '@/components/site-header';

// Brand icons (removed from newer lucide-react versions) as inline SVGs
function Github({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4" />
      <path d="M9 18c-4.51 2-5-2-7-2" />
    </svg>
  );
}

function Youtube({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
      <path d="m10 15 5-3-5-3z" />
    </svg>
  );
}
import { ProcessingStatus, type ProcessingStep } from '@/components/processing-status';
import { ClipsGallery } from '@/components/clips-gallery';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

export default function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [clips, setClips] = useState<Clip[]>([]);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [showResults, setShowResults] = useState(false);

  const updateStep = (stepName: string, status: ProcessingStep['status'], message?: string) => {
    setProcessingSteps((prev) => {
      const existing = prev.find((s) => s.name === stepName);
      if (existing) {
        return prev.map((s) =>
          s.name === stepName ? { ...s, status, message } : s
        );
      }
      return [...prev, { name: stepName, status, message }];
    });
  };

  const handleUrlSubmit = async (url: string) => {
    setIsLoading(true);
    setClips([]);
    setProcessingSteps([]);
    setShowResults(true);

    try {
      // Step 1: Resolve social media URL to direct video URL via ab-downloader
      updateStep('Resolving URL', 'processing', 'Extracting video from social media link...');
      console.log('[clipper] Resolving URL:', url);
      const resolveRes = await fetch('/api/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const resolveData = await resolveRes.json();
      if (!resolveRes.ok) {
        throw new Error(resolveData.error || 'Failed to resolve video URL');
      }
      const { videoUrl, title } = resolveData as { videoUrl: string; title: string };
      console.log('[clipper] Resolved video:', title);
      updateStep('Resolving URL', 'completed', title);

      // Step 2: Download video into the browser through the proxy (no storage)
      updateStep('Downloading Video', 'processing', 'Fetching video into your browser...');
      const proxyRes = await fetch(`/api/proxy?url=${encodeURIComponent(videoUrl)}`);
      if (!proxyRes.ok) {
        const err = await proxyRes.json().catch(() => null);
        throw new Error(err?.error || 'Failed to download video');
      }
      const arrayBuffer = await proxyRes.arrayBuffer();
      const videoBuffer = new Uint8Array(arrayBuffer);
      console.log('[clipper] Downloaded video, size:', videoBuffer.length, 'bytes');
      if (videoBuffer.length < 10000) {
        throw new Error('Downloaded file is too small — the link may not contain a video');
      }
      updateStep('Downloading Video', 'completed', `${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`);

      // Step 3: Load FFmpeg
      updateStep('Loading FFmpeg', 'processing', 'Initializing video processing...');
      const { initFFmpeg, extractFramesAsImages, cutVideoClips, getVideoDurationFromBuffer } = await import('@/lib/ffmpeg-client');
      console.log('[clipper] Initializing FFmpeg...');
      await initFFmpeg();
      updateStep('Loading FFmpeg', 'completed');

      // Step 4: Get video duration
      updateStep('Analyzing Video', 'processing', 'Reading video metadata...');
      console.log('[clipper] Getting video duration...');
      const duration = await getVideoDurationFromBuffer(videoBuffer);
      console.log('[clipper] Video duration:', duration, 'seconds');
      updateStep('Analyzing Video', 'completed', `Duration: ${Math.round(duration)}s`);

      // Step 5: AI analysis — the AI returns FULL moments (start → end of scene),
      // so clips are NOT limited to a fixed length and never cut a moment short.
      let detectedMoments: Array<{
        startTime: number;
        endTime: number;
        actionType: string;
        intensity: number;
        description: string;
      }> = [];

      const geminiApiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (geminiApiKey) {
        try {
          updateStep('Detecting Moments', 'processing', 'AI analyzing for crucial moments...');
          const { initGemini, detectMoments } = await import('@/lib/gemini-client');
          initGemini(geminiApiKey);

          // Hard overall timeout: if AI analysis takes too long, abort it and
          // fall back to smart segmentation so processing NEVER hangs here.
          const AI_TIMEOUT_MS = 90000;
          const aiAnalysis = async () => {
            // Denser sampling so the AI can judge where scenes start AND end
            const frameInterval = Math.max(1, Math.min(4, Math.floor(duration / 24) || 1));
            const frames = await extractFramesAsImages(
              videoBuffer,
              duration,
              frameInterval,
              (current, total) => {
                updateStep('Detecting Moments', 'processing', `Extracting frames ${current}/${total}...`);
              }
            );
            console.log('[clipper] Extracted frames:', frames.length);
            if (frames.length === 0) throw new Error('No frames could be extracted');

            updateStep('Detecting Moments', 'processing', `AI analyzing ${frames.length} frames...`);
            return detectMoments(frames, duration);
          };

          detectedMoments = await Promise.race([
            aiAnalysis(),
            new Promise<never>((_, reject) =>
              setTimeout(() => reject(new Error('AI analysis timed out')), AI_TIMEOUT_MS)
            ),
          ]);
          console.log('[clipper] AI detected moments:', detectedMoments);
        } catch (aiError) {
          console.error('[clipper] AI analysis failed, using smart segmentation fallback:', aiError);
          updateStep('Detecting Moments', 'processing', 'AI unavailable — using smart segmentation...');
          detectedMoments = [];
        }
      }

      // Fallback: if AI found nothing, split the video into natural variable-length segments
      if (detectedMoments.length === 0) {
        const segmentCount = Math.min(5, Math.max(2, Math.floor(duration / 20)));
        const base = duration / segmentCount;
        for (let i = 0; i < segmentCount; i++) {
          const start = Math.floor(base * i);
          const end = i === segmentCount - 1 ? Math.floor(duration) : Math.floor(base * (i + 1));
          detectedMoments.push({
            startTime: start,
            endTime: end,
            actionType: 'Highlight',
            intensity: 7,
            description: `Highlight segment ${i + 1} (${start}s - ${end}s)`,
          });
        }
      }
      detectedMoments.sort((a, b) => a.startTime - b.startTime);
      updateStep('Detecting Moments', 'completed', `Found ${detectedMoments.length} moments`);

      // Step 6: Build clip segments directly from the AI moment boundaries —
      // each clip runs from the start of the scene until it fully finishes.
      const clipSegments = detectedMoments.map((moment, index) => {
        const start = Math.max(0, moment.startTime);
        const end = Math.min(duration, Math.max(moment.endTime, start + 3));
        return {
          startTime: start,
          endTime: end,
          clipId: `clip_${index + 1}`,
          description: `${moment.actionType}: ${moment.description}`,
        };
      });
      console.log('[clipper] Clip segments:', clipSegments);

      // Step 7: Generate clips with FFmpeg in the browser
      updateStep('Generating Clips', 'processing', `Cutting ${clipSegments.length} clips...`);
      const generatedClips = await cutVideoClips(videoBuffer, clipSegments, (current, total) => {
        updateStep('Generating Clips', 'processing', `Cutting clip ${current}/${total}...`);
      });

      if (generatedClips.length === 0) {
        throw new Error('Failed to generate clips from this video');
      }

      const clipsData: Clip[] = generatedClips.map((clip) => {
        const segIndex = clipSegments.findIndex((s) => s.clipId === clip.clipId);
        const seg = clipSegments[segIndex];
        return {
          clipId: clip.clipId,
          startTime: seg.startTime,
          endTime: seg.endTime,
          description: seg.description,
          intensity: detectedMoments[segIndex]?.intensity ?? 7,
          duration: seg.endTime - seg.startTime,
          blobUrl: URL.createObjectURL(clip.blob),
          fileSize: clip.blob.size,
        };
      });

      setClips(clipsData);
      updateStep('Generating Clips', 'completed', `Generated ${clipsData.length} clips`);
      updateStep('Complete', 'completed', 'Ready to download your clips!');

      console.log('[clipper] Processing complete. Clips:', clipsData.length);
    } catch (error) {
      console.error('[clipper] Error processing video:', error);
      updateStep('Error', 'error', error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-background">
<SiteHeader />
{/* Hero Section */}
<section className="relative pt-24 pb-20 px-4 border-b border-border overflow-hidden">
  {/* Animated gradient orbs */}
  <div className="absolute inset-0 -z-10">
    <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-float-slow" />
    <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl animate-float-slower" />
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-3xl animate-pulse-glow" />
  </div>

  {/* Grid background dengan fade */}
  <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:48px_48px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,black,transparent)]" />

  {/* Floating particles */}
  <div className="absolute inset-0 -z-10 pointer-events-none">
    {[...Array(6)].map((_, i) => (
      <span
        key={i}
        className="absolute w-1 h-1 bg-primary/60 rounded-full animate-particle"
        style={{
          left: `${15 + i * 14}%`,
          top: `${20 + (i % 3) * 25}%`,
          animationDelay: `${i * 0.8}s`,
        }}
      />
    ))}
  </div>

<div className="mx-auto max-w-4xl text-center">
  {/* Animated Video Editing Timeline */}
  <div className="mx-auto mb-8 w-full max-w-md animate-fade-in-up">
    <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-background/70 p-4 shadow-[0_18px_60px_-24px] shadow-primary/70 backdrop-blur-xl">
      {/* Top bar: REC indicator + tools */}
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="relative flex h-4 w-4 items-center justify-center">
            <span className="absolute h-full w-full rounded-full border border-destructive/50 animate-ping" />
            <span className="h-2 w-2 rounded-full bg-destructive animate-[rec-blink_1.2s_ease-in-out_infinite]" />
          </span>
          <span className="text-[10px] font-bold tracking-[0.25em] text-destructive uppercase">
            REC
          </span>
          <Camera className="h-4 w-4 text-muted-foreground animate-[shutter_4s_ease-in-out_infinite]" />
        </div>
        <div className="flex items-center gap-3 text-muted-foreground">
          <Scissors className="h-4 w-4 animate-[clip-pop_2.4s_ease-in-out_infinite]" />
          <Film className="h-4 w-4" />
          <span className="rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 text-[10px] font-bold tracking-widest text-primary">
            AI CUT
          </span>
        </div>
      </div>

      {/* Timeline track with clip segments */}
      <div className="relative h-12 overflow-hidden rounded-lg border border-white/10 bg-white/[0.03]">
        {/* Clip segments (audio/video bars) */}
        <div className="absolute inset-0 flex items-center gap-1 px-2">
          {[40, 70, 55, 90, 45, 80, 60, 95, 50, 75, 65, 85, 42, 68, 58].map((h, i) => (
            <span
              key={i}
              className="flex-1 rounded-sm bg-primary/60 origin-center animate-[clip-pop_1.8s_ease-in-out_infinite]"
              style={{ height: `${h}%`, animationDelay: `${i * 0.12}s` }}
            />
          ))}
        </div>

        {/* Cut markers */}
        <span className="absolute top-0 left-[30%] h-full w-px bg-accent/70" />
        <span className="absolute top-0 left-[62%] h-full w-px bg-accent/70" />

        {/* Moving playhead */}
        <span className="absolute top-0 h-full w-[2px] bg-destructive shadow-[0_0_12px] shadow-destructive animate-[playhead_5s_linear_infinite]">
          <span className="absolute -top-0.5 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-destructive" />
        </span>
      </div>

      {/* Bottom bar: play + timecode */}
      <div className="mt-3 flex items-center justify-between text-muted-foreground">
        <div className="flex items-center gap-2">
          <Play className="h-3.5 w-3.5 fill-current text-primary" />
          <span className="font-mono text-[10px] tracking-widest">00:00:14:08</span>
        </div>
        <span className="font-mono text-[10px] tracking-widest text-primary/80">
          3 CLIPS DETECTED
        </span>
      </div>

      {/* Inner shine sweep */}
      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/5 to-transparent animate-[playhead_6s_linear_infinite]" />
    </div>
  </div>

    {/* Headline dengan gradient shimmer */}
    <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 animate-fade-in-up [animation-delay:150ms] opacity-0 [animation-fill-mode:forwards]">
      <span className="bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
        Ubah Video Panjang Jadi Klip Viral
      </span>
    </h1>

    <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 animate-fade-in-up [animation-delay:300ms] opacity-0 [animation-fill-mode:forwards]">
      Biarkan AI memotong momen terbaik dari videomu secara otomatis, siap diunggah dalam hitungan detik.
    </p>

    {/* CTA dengan hover glow & scale */}
    <div className="flex items-center justify-center gap-4 animate-fade-in-up [animation-delay:450ms] opacity-0 [animation-fill-mode:forwards]">
      <button className="relative px-8 py-3 rounded-full bg-primary text-primary-foreground font-semibold overflow-hidden transition-transform duration-300 hover:scale-105 shadow-[0_0_30px_-8px] shadow-primary/60 group">
        <span className="relative z-10">Mulai Gratis</span>
        <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
      </button>
      <button className="px-8 py-3 rounded-full border border-border font-semibold hover:border-primary/50 hover:bg-primary/5 transition-all duration-300 hover:scale-105">
        Lihat Demo
      </button>
    </div>

          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mt-10 mb-8 text-pretty">
            Paste any TikTok, Instagram, YouTube, Facebook, or Twitter/X link and get viral-worthy clips. AI detects the best moments automatically.
          </p>
          <div className="flex gap-8 justify-center flex-wrap">
            <div className="flex flex-col items-center gap-2">
              <Zap className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Auto-detect</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Clapperboard className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Multi-clips</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Smartphone className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">All Platforms</p>
            </div>
          </div>
  </div>
</section>

      {/* Main Content */}
      <section className="py-16 px-4">
        <div className="space-y-12">
          {/* Input Form */}
          <InputForm
            onSubmit={handleUrlSubmit}
            isLoading={isLoading}
          />

          {/* Processing Status */}
          {showResults && (
            <ProcessingStatus
              steps={processingSteps}
              isComplete={!isLoading && clips.length > 0}
              clipsCount={clips.length}
            />
          )}

          {/* Clips Gallery */}
          {clips.length > 0 && !isLoading && (
            <div className="py-8">
              <ClipsGallery clips={clips} />
            </div>
          )}
        </div>
      </section>

{/* Footer */}
<footer className="relative mt-20 overflow-hidden border-t border-white/10 bg-background/80 px-4 py-10">
  {/* Soft ambient glow */}
  <div className="pointer-events-none absolute inset-x-0 top-0 mx-auto h-px max-w-4xl bg-gradient-to-r from-transparent via-primary/60 to-transparent" />
  <div className="pointer-events-none absolute left-1/2 top-0 h-32 w-72 -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" />

  <div className="relative mx-auto flex max-w-6xl flex-col items-center gap-4 text-center">
    {/* Brand chip */}
    <div className="group relative overflow-hidden rounded-full border border-white/10 bg-white/[0.03] px-5 py-2 shadow-[0_0_40px_-18px] shadow-primary backdrop-blur-xl">
      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />

      <p className="relative text-sm font-semibold tracking-[0.22em] text-foreground uppercase">
        {'\u00A9'} {new Date().getFullYear()}{' '}
        <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
          IClip
        </span>
      </p>
    </div>
{/* Social Icons Container */}
<div className="flex items-center justify-center gap-4">
  
  {/* GitHub */}
  <a
    href="https://github.com/IZZUL-MODS"
    target="_blank"
    rel="noopener noreferrer"
    aria-label="GitHub"
    className="group relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border border-slate-900/10 bg-white/50 shadow-[0_4px_12px_-2px_rgba(0,0,0,0.1)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-slate-900/30 hover:shadow-xl dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
  >
    <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(0,0,0,0.05),transparent)] dark:bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
    <Github className="relative z-10 h-5 w-5 text-slate-700 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6 dark:text-white" />
  </a>

  {/* YouTube (Kamera Jepret) */}
  <a
    href="https://youtube.com/@izzul_maker?si=0SOXOpYXJgWtgqbF"
    target="_blank"
    rel="noopener noreferrer"
    aria-label="YouTube"
    className="group relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border border-red-500/30 bg-white/60 dark:bg-red-500/10 shadow-[0_4px_12px_-2px_rgba(239,68,68,0.3)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-red-500/60 hover:shadow-red-500/30"
  >
    {/* Efek gradasi radial untuk interaksi */}
    <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(239,68,68,0.2),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
    
    {/* Logo Youtube dengan kontras yang disesuaikan */}
    <Youtube 
      className="relative z-10 h-6 w-6 text-red-600 dark:text-red-500 transition-transform duration-300 group-hover:scale-110" 
    />
  </a>
  
</div>

<footer className="footer-container">
  {/* Copyright text */}
  <p className="text-xs font-medium tracking-wide text-muted-foreground">
    All rights reserved.
  </p>

  {/* Made by */}
  <div className="flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-muted-foreground">
    <span>Made</span>

    {/* Wadah ikon dan teks */}
    <div className="flex items-center gap-2">
      <span className="relative inline-flex h-5 w-5 items-center justify-center" aria-hidden="true">
        <span className="absolute h-5 w-5 rounded-full bg-destructive/20 animate-ping" />
        <span className="relative text-destructive animate-heartbeat">
          {'\u2665'}
        </span>
      </span>

      <span>
        by{' '}
        <span className="font-bold text-primary drop-shadow-[0_0_12px_rgba(255,255,255,0.25)]">
          Izzul
        </span>
      </span>
    </div>
    
    <span className="sr-only">with love</span>
  </div>
</footer>


    </main>
  );
}
