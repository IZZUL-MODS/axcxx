import { NextRequest, NextResponse } from 'next/server';
import { spawn } from 'child_process';
import { readFile, unlink } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { randomUUID } from 'crypto';
// @ts-expect-error - ffmpeg-static exports a string path
import ffmpegPath from 'ffmpeg-static';

export const runtime = 'nodejs';
export const maxDuration = 300;

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

// Cache resolved redirect targets so every frame seek hits the CDN directly
const redirectCache = new Map<string, { finalUrl: string; ts: number }>();
const REDIRECT_TTL_MS = 10 * 60 * 1000;

async function resolveFinalUrl(videoUrl: string, referer: string): Promise<string> {
  const cached = redirectCache.get(videoUrl);
  if (cached && Date.now() - cached.ts < REDIRECT_TTL_MS) return cached.finalUrl;
  try {
    const res = await fetch(videoUrl, {
      method: 'HEAD',
      redirect: 'follow',
      headers: { 'User-Agent': UA, Referer: referer },
      signal: AbortSignal.timeout(15000),
    });
    const finalUrl = res.url || videoUrl;
    redirectCache.set(videoUrl, { finalUrl, ts: Date.now() });
    return finalUrl;
  } catch {
    return videoUrl;
  }
}

function runFFmpeg(
  args: string[],
  timeoutMs: number
): Promise<{ code: number; stderr: string }> {
  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegPath as string, args, {
      stdio: ['ignore', 'ignore', 'pipe'],
    });
    let stderr = '';
    const timer = setTimeout(() => {
      proc.kill('SIGKILL');
      reject(new Error('FFmpeg timed out'));
    }, timeoutMs);
    proc.stderr.on('data', (d) => {
      stderr += d.toString();
      if (stderr.length > 16000) stderr = stderr.slice(-16000);
    });
    proc.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
    proc.on('close', (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stderr });
    });
  });
}

// Parse "Duration: HH:MM:SS.cc" from ffmpeg stderr
function parseDuration(stderr: string): number | null {
  const m = stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
  if (!m) return null;
  return parseInt(m[1], 10) * 3600 + parseInt(m[2], 10) * 60 + parseFloat(m[3]);
}

// ─────────────────────────────────────────────────────────────────────────────
// Server-side video probing + frame extraction with NATIVE FFmpeg.
//
// WHY THIS FIXES "stuck at frame 1/32":
//   Browser <video> seeking requires the MP4 moov index and buffered data up
//   to each seek point. Large/long videos (8 min ... 2 hr+) routinely stall
//   the browser's seek pipeline. Native ffmpeg instead uses `-ss` BEFORE `-i`
//   with HTTP Range requests: it downloads ONLY the few hundred KB around
//   each keyframe. Extracting a frame at minute 110 of a 2-hour video costs
//   the same as at second 5 of a 30-second clip. Frames are extracted in
//   PARALLEL (6 at a time), so 24 frames of a 2-hour video finish in seconds.
//
// POST body:
//   { videoUrl: string, count?: number }            → probe + extract frames
//   { videoUrl: string, probeOnly: true }           → duration only
// ─────────────────────────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  const tmpFiles: string[] = [];
  try {
    const { videoUrl, count, probeOnly } = (await req.json()) as {
      videoUrl?: string;
      count?: number;
      probeOnly?: boolean;
    };

    if (!videoUrl) {
      return NextResponse.json({ error: 'videoUrl is required' }, { status: 400 });
    }
    let parsed: URL;
    try {
      parsed = new URL(videoUrl);
    } catch {
      return NextResponse.json({ error: 'Invalid videoUrl' }, { status: 400 });
    }
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return NextResponse.json(
        { error: 'Only http/https URLs supported' },
        { status: 400 }
      );
    }

    const referer = `${parsed.protocol}//${parsed.host}/`;
    const headers = `User-Agent: ${UA}\r\nReferer: ${referer}\r\n`;
    const finalUrl = await resolveFinalUrl(videoUrl, referer);

    // ── Probe duration: ffmpeg reads only the container header via ranges ──
    const t0 = Date.now();
    const probe = await runFFmpeg(
      [
        '-hide_banner',
        '-headers', headers,
        '-multiple_requests', '1',
        '-i', finalUrl,
        '-t', '0.1',
        '-f', 'null', '-',
      ],
      30000
    );
    const duration = parseDuration(probe.stderr);
    if (!duration || !isFinite(duration) || duration <= 0) {
      console.error('[clipper] Probe failed:', probe.stderr.slice(-600));
      return NextResponse.json(
        { error: 'Tidak bisa membaca durasi video', detail: probe.stderr.slice(-400) },
        { status: 502 }
      );
    }
    console.log(
      `[clipper] Probe: duration=${duration.toFixed(1)}s in ${((Date.now() - t0) / 1000).toFixed(1)}s`
    );

    if (probeOnly) {
      return NextResponse.json({ duration });
    }

    // ── Build evenly-spaced timestamps across the whole video ──────────────
    // 8min → 16 frames; 30min → 20; 2hr → 28. Enough for AI moment detection
    // without slowing the pipeline down.
    const resolvedCount = Math.min(
      32,
      Math.max(12, count ?? Math.ceil(duration / 240) + 12)
    );
    const usable = Math.max(1, duration - 2);
    const timestamps = Array.from({ length: resolvedCount }, (_, i) =>
      parseFloat((1 + (i / Math.max(1, resolvedCount - 1)) * usable).toFixed(2))
    );

    // ── Extract frames in PARALLEL with native ffmpeg range-seeks ──────────
    const CONCURRENCY = 6;
    const FRAME_TIMEOUT_MS = 45000;
    const results: Array<{ timestamp: number; imageBase64: string }> = [];
    const queue = timestamps.map((ts, i) => ({ ts, i }));

    const workers = Array.from(
      { length: Math.min(CONCURRENCY, queue.length) },
      async () => {
        while (queue.length > 0) {
          const item = queue.shift();
          if (!item) break;
          const outPath = join(tmpdir(), `frame-${randomUUID()}.jpg`);
          tmpFiles.push(outPath);
          try {
            const res = await runFFmpeg(
              [
                '-hide_banner',
                '-loglevel', 'error',
                '-headers', headers,
                '-multiple_requests', '1',
                '-reconnect', '1',
                '-reconnect_streamed', '1',
                '-reconnect_delay_max', '3',
                '-ss', item.ts.toFixed(3),
                '-i', finalUrl,
                '-frames:v', '1',
                '-vf', 'scale=640:-2',
                '-q:v', '6',
                '-y', outPath,
              ],
              FRAME_TIMEOUT_MS
            );
            if (res.code === 0) {
              const buf = await readFile(outPath).catch(() => null);
              if (buf && buf.length > 500) {
                results.push({
                  timestamp: item.ts,
                  imageBase64: buf.toString('base64'),
                });
              }
            } else {
              console.warn(
                `[clipper] Frame at ${item.ts}s failed:`,
                res.stderr.slice(-200)
              );
            }
          } catch (e) {
            console.warn(`[clipper] Frame at ${item.ts}s error:`, e);
          }
        }
      }
    );
    await Promise.all(workers);

    results.sort((a, b) => a.timestamp - b.timestamp);
    console.log(
      `[clipper] Extracted ${results.length}/${timestamps.length} frames server-side in ${((Date.now() - t0) / 1000).toFixed(1)}s`
    );

    if (results.length === 0) {
      return NextResponse.json(
        { error: 'Tidak ada frame yang bisa diekstrak dari video ini' },
        { status: 502 }
      );
    }

    return NextResponse.json({ duration, frames: results });
  } catch (error) {
    console.error('[clipper] Frames route error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to extract frames' },
      { status: 500 }
    );
  } finally {
    await Promise.all(tmpFiles.map((f) => unlink(f).catch(() => {})));
  }
}
