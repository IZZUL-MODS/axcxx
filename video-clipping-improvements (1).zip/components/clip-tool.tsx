'use client';

import { useState } from 'react';
import { InputForm } from '@/components/input-form';
import { ProcessingStatus, type ProcessingStep } from '@/components/processing-status';
import { ClipsGallery } from '@/components/clips-gallery';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

interface ClipSegment {
  startTime: number;
  endTime: number;
  clipId: string;
  description: string;
}

// Cut clips on the SERVER with native FFmpeg (HTTP range seek — only the
// segment bytes are downloaded, never the whole video). Runs with limited
// concurrency so multiple clips are produced in parallel.
async function cutClipsOnServer(
  videoUrl: string,
  segments: ClipSegment[],
  onOneDone: (done: number, total: number) => void
): Promise<Array<{ clipId: string; blob: Blob }>> {
  const results: Array<{ clipId: string; blob: Blob }> = [];
  let done = 0;
  const CONCURRENCY = 3;

  const queue = [...segments];
  const workers = Array.from({ length: Math.min(CONCURRENCY, queue.length) }, async () => {
    while (queue.length > 0) {
      const seg = queue.shift();
      if (!seg) break;
      try {
        const res = await fetch('/api/clip', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            videoUrl,
            start: seg.startTime,
            duration: seg.endTime - seg.startTime,
          }),
        });
        if (!res.ok) {
          const err = await res.json().catch(() => null);
          throw new Error(err?.error || `Server returned ${res.status}`);
        }
        const blob = await res.blob();
        if (blob.size < 1000) throw new Error('Klip terlalu kecil / kosong');
        results.push({ clipId: seg.clipId, blob });
      } catch (e) {
        console.error(`[clipper] Server cut failed for ${seg.clipId}:`, e);
      } finally {
        done++;
        onOneDone(done, segments.length);
      }
    }
  });

  await Promise.all(workers);
  results.sort((a, b) => a.clipId.localeCompare(b.clipId, undefined, { numeric: true }));
  return results;
}

export function ClipTool() {
  const [isLoading, setIsLoading] = useState(false);
  const [clips, setClips] = useState<Clip[]>([]);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [showResults, setShowResults] = useState(false);

  const updateStep = (
    stepName: string,
    status: ProcessingStep['status'],
    message?: string
  ) => {
    setProcessingSteps((prev) => {
      const existing = prev.find((s) => s.name === stepName);
      if (existing) {
        return prev.map((s) =>
          s.name === stepName ? { ...s, status, message } : s
        );
      }
      return [...prev, { name: stepName, status, message }];
    });
  };

  const handleUrlSubmit = async (url: string) => {
    setIsLoading(true);
    setClips([]);
    setProcessingSteps([]);
    setShowResults(true);

    try {
      // ── Step 1: Resolve social media URL ──────────────────────────────────
      updateStep('Resolving URL', 'processing', 'Mengekstrak video dari link sosial media...');
      console.log('[clipper] Resolving URL:', url);

      const resolveRes = await fetch('/api/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const resolveData = await resolveRes.json();
      if (!resolveRes.ok) {
        throw new Error(resolveData.error || 'Failed to resolve video URL');
      }
      const { videoUrl, title } = resolveData as { videoUrl: string; title: string };
      console.log('[clipper] Resolved video:', title);
      updateStep('Resolving URL', 'completed', title);

      // ── Step 2+3: Probe duration & extract frames SERVER-SIDE ─────────────
      // Native FFmpeg on the server seeks via HTTP Range requests and pulls
      // ONLY the keyframe bytes it needs — 6 frames in parallel. This is O(1)
      // per frame for ANY video length (8 min, 30 min, or 2 hr+) and never
      // depends on slow browser <video> seeking (the old cause of the
      // "stuck at frame 1/32" bug).
      updateStep(
        'Analyzing Video',
        'processing',
        'Menganalisis video di server (streaming, tanpa download penuh)...'
      );

      const framesRes = await fetch('/api/frames', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoUrl }),
      });
      const framesData = await framesRes.json();
      if (!framesRes.ok) {
        throw new Error(framesData.error || 'Gagal menganalisis video');
      }

      const duration: number = framesData.duration;
      let frames: Array<{ timestamp: number; imageBase64: string }> =
        framesData.frames ?? [];

      console.log(
        '[clipper] Duration:',
        duration,
        's (',
        (duration / 60).toFixed(1),
        'min ) — frames from server:',
        frames.length
      );
      updateStep(
        'Analyzing Video',
        'completed',
        `Durasi: ${Math.floor(duration / 60)}m ${Math.round(duration % 60)}s`
      );

      // Fallback: if the server could not extract frames (very rare), try the
      // browser streaming method via the proxy.
      if (frames.length === 0) {
        updateStep(
          'Extracting Frames',
          'processing',
          'Fallback: mengambil frame via browser...'
        );
        const proxyUrl = `/api/proxy?url=${encodeURIComponent(videoUrl)}`;
        const { extractFramesFromUrl } = await import('@/lib/ffmpeg-client');
        frames = await extractFramesFromUrl(proxyUrl, duration, (current, total) => {
          updateStep(
            'Extracting Frames',
            'processing',
            `Mengambil frame ${current}/${total}...`
          );
        });
      }

      console.log('[clipper] Extracted frames:', frames.length);
      if (frames.length === 0) {
        throw new Error('Tidak ada frame yang bisa diekstrak dari video ini');
      }
      updateStep('Extracting Frames', 'completed', `${frames.length} frame`);

      // ── Step 4: Moment detection (AI with motion-analysis fallback) ───────
      let detectedMoments: Array<{
        startTime: number;
        endTime: number;
        actionType: string;
        intensity: number;
        description: string;
      }> = [];
      let detectionMethod: 'ai' | 'motion' = 'motion';
      let aiFailReason = '';

      const { looksLikeUniformSplit, detectMotionMoments } = await import(
        '@/lib/motion-detect'
      );

      const geminiApiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (geminiApiKey) {
        try {
          updateStep(
            'Detecting Moments',
            'processing',
            `AI menganalisis ${frames.length} frame...`
          );
          const { initGemini, detectMoments } = await import('@/lib/gemini-client');
          initGemini(geminiApiKey);

          const AI_TIMEOUT_MS = 120000;
          const aiMoments = await Promise.race([
            detectMoments(frames, duration),
            new Promise<never>((_, reject) =>
              setTimeout(
                () => reject(new Error('AI analysis timed out')),
                AI_TIMEOUT_MS
              )
            ),
          ]);
          console.log('[clipper] AI detected moments:', aiMoments);

          if (aiMoments.length > 0 && looksLikeUniformSplit(aiMoments, duration)) {
            aiFailReason = 'Output AI berupa potongan seragam — ditolak';
            console.log('[clipper] AI output rejected: uniform split');
          } else if (aiMoments.length > 0) {
            detectedMoments = aiMoments;
            detectionMethod = 'ai';
          } else {
            aiFailReason = 'AI tidak menemukan momen';
          }
        } catch (aiError) {
          aiFailReason =
            aiError instanceof Error ? aiError.message : 'AI error';
          console.error('[clipper] AI analysis failed:', aiError);
        }
      } else {
        aiFailReason = 'NEXT_PUBLIC_GEMINI_API_KEY belum diset';
      }

      if (detectedMoments.length === 0) {
        updateStep(
          'Detecting Moments',
          'processing',
          `AI tidak tersedia (${aiFailReason}) — menganalisis gerakan antar frame...`
        );
        detectedMoments = await detectMotionMoments(frames, duration, 5);
        console.log('[clipper] Motion-based moments:', detectedMoments);
      }

      if (detectedMoments.length === 0) {
        throw new Error(
          'Tidak ada momen menarik yang terdeteksi. Coba video lain yang memiliki aksi atau perubahan adegan.'
        );
      }

      detectedMoments.sort((a, b) => a.startTime - b.startTime);
      updateStep(
        'Detecting Moments',
        'completed',
        detectionMethod === 'ai'
          ? `AI menemukan ${detectedMoments.length} momen penting`
          : `${detectedMoments.length} momen aksi dari analisis gerakan`
      );

      const clipSegments: ClipSegment[] = detectedMoments.map((moment, index) => {
        const start = Math.max(0, moment.startTime);
        const end = Math.min(duration, Math.max(moment.endTime, start + 3));
        return {
          startTime: start,
          endTime: end,
          clipId: `clip_${index + 1}`,
          description: `${moment.actionType}: ${moment.description}`,
        };
      });
      console.log('[clipper] Clip segments:', clipSegments);

      // ── Step 5: Cut clips SERVER-SIDE with native FFmpeg ──────────────────
      // No download, no WASM. The server seeks directly into the remote video
      // via HTTP ranges and only encodes the requested segments. 3 clips are
      // processed in parallel.
      updateStep(
        'Generating Clips',
        'processing',
        `Memotong ${clipSegments.length} klip di server (paralel)...`
      );
      const generatedClips = await cutClipsOnServer(
        videoUrl,
        clipSegments,
        (done, total) => {
          updateStep(
            'Generating Clips',
            'processing',
            `Klip selesai ${done}/${total}...`
          );
        }
      );

      if (generatedClips.length === 0) {
        throw new Error('Gagal membuat klip dari video ini');
      }

      const clipsData: Clip[] = generatedClips.map((clip) => {
        const segIndex = clipSegments.findIndex((s) => s.clipId === clip.clipId);
        const seg = clipSegments[segIndex];
        return {
          clipId: clip.clipId,
          startTime: seg.startTime,
          endTime: seg.endTime,
          description: seg.description,
          intensity: detectedMoments[segIndex]?.intensity ?? 7,
          duration: seg.endTime - seg.startTime,
          blobUrl: URL.createObjectURL(clip.blob),
          fileSize: clip.blob.size,
        };
      });

      setClips(clipsData);
      updateStep(
        'Generating Clips',
        'completed',
        `${clipsData.length} klip berhasil dibuat`
      );
      updateStep('Complete', 'completed', 'Klip siap diunduh!');

      console.log('[clipper] Processing complete. Clips:', clipsData.length);
    } catch (error) {
      console.error('[clipper] Error processing video:', error);
      updateStep(
        'Error',
        'error',
        error instanceof Error ? error.message : 'Unknown error occurred'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-12">
      <InputForm onSubmit={handleUrlSubmit} isLoading={isLoading} />

      {showResults && (
        <ProcessingStatus
          steps={processingSteps}
          isComplete={!isLoading && clips.length > 0}
          clipsCount={clips.length}
        />
      )}

      {clips.length > 0 && !isLoading && (
        <div className="py-8">
          <ClipsGallery clips={clips} />
        </div>
      )}
    </div>
  );
}
