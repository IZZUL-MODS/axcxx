import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL } from '@ffmpeg/util';

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

export async function initFFmpeg(): Promise<FFmpeg> {
  if (ffmpegInstance?.loaded) {
    return ffmpegInstance;
  }

  if (loadPromise) {
    return loadPromise;
  }

  loadPromise = (async () => {
    const ffmpeg = new FFmpeg();
    const baseURL = 'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd';

    ffmpeg.on('log', ({ message }) => {
      console.log('[ffmpeg]', message);
    });

    console.log('[clipper] Loading FFmpeg core...');
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
    console.log('[clipper] FFmpeg loaded successfully');

    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  try {
    return await loadPromise;
  } catch (error) {
    loadPromise = null;
    console.error('[clipper] Failed to load FFmpeg:', error);
    throw error;
  }
}

// Duration probe — uses native <video> element (fast, zero network overhead).
export async function getVideoDurationFromBuffer(
  videoBuffer: Uint8Array
): Promise<number> {
  return new Promise((resolve, reject) => {
    const blob = new Blob([videoBuffer], { type: 'video/mp4' });
    const video = document.createElement('video');
    const url = URL.createObjectURL(blob);

    const timeout = setTimeout(() => {
      URL.revokeObjectURL(url);
      reject(new Error('Timeout getting video duration'));
    }, 15000);

    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      clearTimeout(timeout);
      const duration = video.duration;
      URL.revokeObjectURL(url);
      resolve(duration);
    };

    video.onerror = () => {
      clearTimeout(timeout);
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load video metadata'));
    };

    video.src = url;
  });
}

// Get video duration directly from a streaming proxy URL (no download needed).
// The browser fetches only the moov/header bytes via HTTP Range requests.
export async function getVideoDurationFromUrl(videoUrl: string): Promise<number> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');

    const timeout = setTimeout(() => {
      video.src = '';
      reject(new Error('Timeout getting video duration from URL'));
    }, 20000);

    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      clearTimeout(timeout);
      const duration = video.duration;
      video.src = '';
      resolve(duration);
    };

    video.onerror = () => {
      clearTimeout(timeout);
      video.src = '';
      reject(new Error('Failed to load video metadata from URL'));
    };

    video.src = videoUrl;
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Extract frames via the STREAMING proxy URL — THE CORE FIX for stuck-at-1/32.
//
// ROOT CAUSE OF THE BUG:
//   The old code downloaded the ENTIRE video into a blob URL, then tried to
//   seek inside it. For an 8-minute video (~200-400 MB) or a 2-hour video
//   (~2-4 GB), the browser must buffer sequentially to each seek point, which
//   consistently times out at the old 8s limit.
//
// THE FIX:
//   Point the <video> element at the HTTP proxy URL instead of a blob URL.
//   The browser then uses HTTP Range requests to fetch only the keyframe it
//   needs for each seek — this is O(1) regardless of where in the video the
//   timestamp falls. A 2-hour video seeks just as fast as a 30-second clip.
//   No prior download is needed at all for frame extraction.
// ─────────────────────────────────────────────────────────────────────────────
export async function extractFramesFromUrl(
  proxyUrl: string,
  duration: number,
  onProgress?: (current: number, total: number) => void,
  maxFrames?: number
): Promise<Array<{ timestamp: number; imageBase64: string }>> {
  // Smart frame count: enough coverage without being slow.
  // 2hr video → 24 frames (1 per 5 min); 8min → 14 frames; 30min → 18 frames.
  const resolvedMax =
    maxFrames ?? Math.min(24, Math.max(12, Math.ceil(duration / 300)));

  // Build evenly-spaced timestamps across the full duration
  const timestamps: number[] = Array.from({ length: resolvedMax }, (_, i) =>
    parseFloat(((i / (resolvedMax - 1)) * Math.max(0, duration - 1)).toFixed(2))
  );
  // Ensure we always start at t=1 (not t=0 which is often a black frame)
  if (timestamps[0] < 1 && duration > 2) timestamps[0] = 1;

  const frames: Array<{ timestamp: number; imageBase64: string }> = [];

  const video = document.createElement('video');
  video.muted = true;
  video.crossOrigin = 'anonymous';
  // preload=metadata so the browser fetches only the index, not the full video
  video.preload = 'metadata';

  // Wait for metadata — typically <1s even for 2hr videos (range request)
  await new Promise<void>((resolve, reject) => {
    const t = setTimeout(
      () => reject(new Error('Video metadata timeout (proxy URL)')),
      20000
    );
    video.onloadedmetadata = () => { clearTimeout(t); resolve(); };
    video.onerror = () => {
      clearTimeout(t);
      reject(new Error('Video load error (proxy URL)'));
    };
    video.src = proxyUrl;
    video.load();
  });

  const effectiveDuration = isFinite(video.duration) ? video.duration : duration;

  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 360;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  if (!ctx) {
    video.src = '';
    throw new Error('Canvas 2D context unavailable');
  }

  // Seek timeout scales with duration — proxy range requests are fast but
  // network latency can vary. Short videos: 15s; medium: 25s; long: 45s.
  const SEEK_TIMEOUT_MS =
    duration < 300 ? 15000 : duration < 1800 ? 25000 : 45000;

  for (let idx = 0; idx < timestamps.length; idx++) {
    const timestamp = Math.min(timestamps[idx], effectiveDuration - 0.5);
    onProgress?.(idx + 1, timestamps.length);

    // Two attempts per frame with a brief pause between retries
    let captured = false;
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        await new Promise<void>((resolve, reject) => {
          const t = setTimeout(
            () => reject(new Error(`Seek timeout at ${timestamp}s`)),
            SEEK_TIMEOUT_MS
          );
          const onSeeked = () => {
            clearTimeout(t);
            video.removeEventListener('seeked', onSeeked);
            resolve();
          };
          video.addEventListener('seeked', onSeeked);
          video.currentTime = timestamp;
        });

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageBase64 = canvas.toDataURL('image/jpeg', 0.7).split(',')[1] ?? '';
        if (imageBase64.length > 100) {
          frames.push({ timestamp, imageBase64 });
          captured = true;
        }
        break;
      } catch (e) {
        console.warn(
          `[clipper] Frame attempt ${attempt + 1} failed at ${timestamp}s:`,
          e
        );
        if (attempt === 0) await new Promise(r => setTimeout(r, 600));
      }
    }

    if (!captured) {
      console.error(`[clipper] Skipping frame at ${timestamp}s — seek failed`);
    }
  }

  video.pause();
  video.src = '';

  console.log(
    `[clipper] Extracted ${frames.length}/${timestamps.length} frames via proxy streaming`
  );
  return frames;
}

// ─────────────────────────────────────────────────────────────────────────────
// Legacy fallback: extract frames from an already-downloaded Uint8Array.
// Only used when a proxy URL is not available.
// ─────────────────────────────────────────────────────────────────────────────
export async function extractFramesAsImages(
  videoBuffer: Uint8Array,
  duration: number,
  intervalSeconds: number = 2,
  onProgress?: (current: number, total: number) => void,
  maxFrames: number = 24
): Promise<Array<{ timestamp: number; imageBase64: string }>> {
  const resolvedMax = Math.min(maxFrames, Math.max(12, Math.ceil(duration / 300)));

  let timestamps: number[] = [];
  const safeInterval = Math.max(intervalSeconds, 1);
  for (let t = 0; t < duration; t += safeInterval) {
    timestamps.push(parseFloat(t.toFixed(2)));
  }
  if (timestamps.length > resolvedMax) {
    const step = duration / resolvedMax;
    timestamps = Array.from({ length: resolvedMax }, (_, i) =>
      parseFloat((i * step).toFixed(2))
    );
  }
  if (timestamps.length > 0 && timestamps[0] !== 0) timestamps.unshift(0);
  const lastTs = Math.max(0, duration - 0.5);
  if (timestamps[timestamps.length - 1] < lastTs) timestamps.push(lastTs);

  const frames: Array<{ timestamp: number; imageBase64: string }> = [];

  const blob = new Blob([videoBuffer], { type: 'video/mp4' });
  const videoUrl = URL.createObjectURL(blob);

  const video = document.createElement('video');
  video.muted = true;
  video.preload = 'auto';
  video.crossOrigin = 'anonymous';

  await new Promise<void>((resolve, reject) => {
    const timeout = setTimeout(
      () => reject(new Error('Video load timeout for frame extraction')),
      30000
    );
    video.oncanplay = () => { clearTimeout(timeout); resolve(); };
    video.onerror = () => { clearTimeout(timeout); reject(new Error('Video load error')); };
    video.src = videoUrl;
    video.load();
  });

  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 360;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  if (!ctx) {
    URL.revokeObjectURL(videoUrl);
    throw new Error('Canvas 2D context unavailable');
  }

  const SEEK_TIMEOUT_MS =
    duration < 300 ? 15000 : duration < 1800 ? 25000 : 45000;

  for (let idx = 0; idx < timestamps.length; idx++) {
    const timestamp = timestamps[idx];
    onProgress?.(idx + 1, timestamps.length);

    try {
      await new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(
          () => reject(new Error('Seek timeout')),
          SEEK_TIMEOUT_MS
        );
        const onSeeked = () => {
          clearTimeout(timeout);
          video.removeEventListener('seeked', onSeeked);
          resolve();
        };
        video.addEventListener('seeked', onSeeked);
        video.currentTime = timestamp;
      });

      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageBase64 = canvas.toDataURL('image/jpeg', 0.7).split(',')[1] ?? '';
      if (imageBase64.length > 100) {
        frames.push({ timestamp, imageBase64 });
      }
    } catch (err) {
      console.error(`[clipper] Frame seek failed at ${timestamp}s:`, err);
    }
  }

  video.pause();
  video.src = '';
  URL.revokeObjectURL(videoUrl);

  console.log('[clipper] Extracted', frames.length, 'frames via native canvas (buffer)');
  return frames;
}

// ─────────────────────────────────────────────────────────────────────────────
// Cut multiple clips from the video — optimised for ANY duration, including 2hr+.
//
// Strategy:
//   1. `-ss` BEFORE `-i` → keyframe-seek in O(1) regardless of video length.
//   2. Re-encode only the tiny segment (ultrafast/crf28) → precise boundaries.
//   3. Fallback to stream copy if re-encode fails (near-instant via keyframe seek).
// ─────────────────────────────────────────────────────────────────────────────
export async function cutVideoClips(
  videoBuffer: Uint8Array,
  clips: Array<{
    startTime: number;
    endTime: number;
    clipId: string;
    description?: string;
  }>,
  onProgress?: (current: number, total: number) => void
): Promise<
  Array<{
    clipId: string;
    blob: Blob;
    fileName: string;
    description?: string;
  }>
> {
  const ffmpeg = await initFFmpeg();

  const sizeMB = videoBuffer.length / 1024 / 1024;
  console.log(
    '[clipper] Starting to cut',
    clips.length,
    'clips from',
    sizeMB.toFixed(1),
    'MB video'
  );

  await ffmpeg.writeFile('input.mp4', videoBuffer);

  const results: Array<{
    clipId: string;
    blob: Blob;
    fileName: string;
    description?: string;
  }> = [];

  // Generous timeouts — re-encoding a ~60s clip with ultrafast takes 15-45s in wasm.
  const REENCODE_TIMEOUT_MS = 300000; // 5 min per clip
  const COPY_TIMEOUT_MS = 60000;     // 1 min for stream copy

  for (let i = 0; i < clips.length; i++) {
    const clip = clips[i];
    onProgress?.(i + 1, clips.length);

    const outputFileName = `${clip.clipId}.mp4`;
    const clipDuration = clip.endTime - clip.startTime;
    console.log(
      `[clipper] Cutting ${clip.clipId} (${clip.startTime}s–${clip.endTime}s, ${clipDuration.toFixed(1)}s)`
    );

    let clipBuffer: Uint8Array | null = null;

    // Primary: keyframe seek (-ss before -i) + re-encode only the segment.
    // This is O(segment_length), NOT O(full_video_length).
    try {
      const code = await ffmpeg.exec(
        [
          '-ss', clip.startTime.toFixed(3),
          '-i', 'input.mp4',
          '-t', clipDuration.toFixed(3),
          '-c:v', 'libx264',
          '-preset', 'ultrafast',
          '-crf', '28',
          '-c:a', 'aac',
          '-b:a', '96k',
          '-avoid_negative_ts', 'make_zero',
          '-movflags', 'faststart',
          outputFileName,
        ],
        REENCODE_TIMEOUT_MS
      );
      if (code === 0) {
        clipBuffer = (await ffmpeg.readFile(outputFileName)) as Uint8Array;
        if (clipBuffer.length < 5000) clipBuffer = null;
      }
    } catch (encodeError) {
      console.warn(`[clipper] Re-encode failed for ${clip.clipId}:`, encodeError);
    }

    // Fallback: stream copy — near-instant, slight keyframe offset on start frame
    if (!clipBuffer) {
      console.log(`[clipper] Falling back to stream copy for ${clip.clipId}`);
      try { await ffmpeg.deleteFile(outputFileName); } catch { /* ignore */ }
      try {
        const code = await ffmpeg.exec(
          [
            '-ss', clip.startTime.toFixed(3),
            '-i', 'input.mp4',
            '-t', clipDuration.toFixed(3),
            '-c', 'copy',
            '-avoid_negative_ts', 'make_zero',
            '-movflags', 'faststart',
            outputFileName,
          ],
          COPY_TIMEOUT_MS
        );
        if (code === 0) {
          clipBuffer = (await ffmpeg.readFile(outputFileName)) as Uint8Array;
          if (clipBuffer.length < 1000) clipBuffer = null;
        }
      } catch (copyError) {
        console.error(`[clipper] Stream copy also failed for ${clip.clipId}:`, copyError);
      }
    }

    if (!clipBuffer) {
      console.error(`[clipper] Skipping ${clip.clipId} — both encode and copy failed`);
      try { await ffmpeg.deleteFile(outputFileName); } catch { /* ignore */ }
      continue;
    }

    const blob = new Blob([clipBuffer], { type: 'video/mp4' });
    console.log(`[clipper] ${clip.clipId} done — ${(blob.size / 1024).toFixed(0)} KB`);
    results.push({
      clipId: clip.clipId,
      blob,
      fileName: outputFileName,
      description: clip.description,
    });
    try { await ffmpeg.deleteFile(outputFileName); } catch { /* ignore */ }
  }

  try { await ffmpeg.deleteFile('input.mp4'); } catch { /* ignore */ }
  console.log('[clipper] All clips done. Total:', results.length);
  return results;
}
