// Motion-based highlight detection that runs entirely in the browser.
// Instead of blindly splitting the video into equal parts, this analyzes the
// visual difference between consecutive frames to find where the REAL action
// happens (scene changes, fast movement, explosions, cuts, etc.) and builds
// variable-length moments around those activity peaks.

import type { DetectedMoment } from './gemini-client';

interface FrameInput {
  timestamp: number;
  imageBase64: string;
}

// Decode a base64 JPEG into a small grayscale pixel array for fast diffing
async function decodeToGray(
  imageBase64: string,
  size = 64
): Promise<Uint8ClampedArray> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) {
        reject(new Error('Canvas 2D context unavailable'));
        return;
      }
      ctx.drawImage(img, 0, 0, size, size);
      const { data } = ctx.getImageData(0, 0, size, size);
      const gray = new Uint8ClampedArray(size * size);
      for (let i = 0; i < gray.length; i++) {
        const o = i * 4;
        gray[i] = (data[o] * 299 + data[o + 1] * 587 + data[o + 2] * 114) / 1000;
      }
      resolve(gray);
    };
    img.onerror = () => reject(new Error('Failed to decode frame'));
    img.src = `data:image/jpeg;base64,${imageBase64}`;
  });
}

// Mean absolute pixel difference between two grayscale frames (0-255)
function frameDiff(a: Uint8ClampedArray, b: Uint8ClampedArray): number {
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    sum += Math.abs(a[i] - b[i]);
  }
  return sum / a.length;
}

// Detect the highest-activity moments from sampled frames.
// Returns variable-length, non-uniform moments centered on activity peaks —
// NEVER a fixed equal split of the video.
export async function detectMotionMoments(
  frames: FrameInput[],
  videoDuration: number,
  maxMoments = 5
): Promise<DetectedMoment[]> {
  if (frames.length < 3) return [];

  // 1. Decode all frames to small grayscale buffers
  const grays: Array<{ timestamp: number; gray: Uint8ClampedArray }> = [];
  for (const f of frames) {
    try {
      grays.push({ timestamp: f.timestamp, gray: await decodeToGray(f.imageBase64) });
    } catch {
      // skip undecodable frames
    }
  }
  if (grays.length < 3) return [];

  // 2. Activity score between each consecutive pair of frames
  const activity: Array<{ time: number; score: number }> = [];
  for (let i = 1; i < grays.length; i++) {
    activity.push({
      time: (grays[i - 1].timestamp + grays[i].timestamp) / 2,
      score: frameDiff(grays[i - 1].gray, grays[i].gray),
    });
  }

  const scores = activity.map((a) => a.score);
  const mean = scores.reduce((s, v) => s + v, 0) / scores.length;
  const std = Math.sqrt(
    scores.reduce((s, v) => s + (v - mean) ** 2, 0) / scores.length
  );
  // A point is "interesting" when its activity is clearly above average
  const threshold = mean + std * 0.5;

  // 3. Group consecutive above-threshold points into activity bursts
  interface Burst {
    start: number;
    end: number;
    peak: number;
  }
  const bursts: Burst[] = [];
  let current: Burst | null = null;
  const sampleGap =
    grays.length > 1
      ? (grays[grays.length - 1].timestamp - grays[0].timestamp) / (grays.length - 1)
      : 2;

  for (const a of activity) {
    if (a.score >= threshold) {
      if (current && a.time - current.end <= sampleGap * 2.5) {
        current.end = a.time;
        current.peak = Math.max(current.peak, a.score);
      } else {
        if (current) bursts.push(current);
        current = { start: a.time, end: a.time, peak: a.score };
      }
    }
  }
  if (current) bursts.push(current);

  // If the video is basically static (no bursts), take the top individual peaks
  if (bursts.length === 0) {
    const top = [...activity]
      .sort((a, b) => b.score - a.score)
      .slice(0, Math.min(3, activity.length));
    for (const t of top) {
      bursts.push({ start: t.time, end: t.time, peak: t.score });
    }
  }

  // 4. Rank bursts by peak intensity and keep the strongest ones
  bursts.sort((a, b) => b.peak - a.peak);
  const kept = bursts.slice(0, maxMoments).sort((a, b) => a.start - b.start);

  const maxPeak = Math.max(...kept.map((b) => b.peak), 1);

  // 5. Build moments with lead-in / lead-out so the action is fully covered
  const LEAD_IN = Math.max(2, sampleGap);
  const LEAD_OUT = Math.max(3, sampleGap * 1.5);
  const MIN_LEN = 5;
  const MAX_LEN = Math.max(30, videoDuration * 0.25);

  const moments: DetectedMoment[] = kept.map((b, i) => {
    let start = Math.max(0, b.start - LEAD_IN);
    let end = Math.min(videoDuration, b.end + LEAD_OUT);
    if (end - start < MIN_LEN) {
      const pad = (MIN_LEN - (end - start)) / 2;
      start = Math.max(0, start - pad);
      end = Math.min(videoDuration, end + pad);
    }
    if (end - start > MAX_LEN) {
      end = start + MAX_LEN;
    }
    const intensity = Math.max(3, Math.min(10, Math.round((b.peak / maxPeak) * 10)));
    return {
      startTime: Math.floor(start),
      endTime: Math.ceil(end),
      actionType: 'High activity',
      intensity,
      description: `Momen aktivitas tinggi terdeteksi dari analisis gerakan (puncak aksi #${i + 1})`,
    };
  });

  // 6. Merge overlapping moments
  const merged: DetectedMoment[] = [];
  for (const m of moments) {
    const last = merged[merged.length - 1];
    if (last && m.startTime <= last.endTime) {
      last.endTime = Math.max(last.endTime, m.endTime);
      last.intensity = Math.max(last.intensity, m.intensity);
    } else {
      merged.push({ ...m });
    }
  }

  return merged;
}

// Detect whether a set of moments is just a uniform equal split of the video
// (the "asal potong" pattern) — used to reject bad AI output.
export function looksLikeUniformSplit(
  moments: DetectedMoment[],
  videoDuration: number
): boolean {
  if (moments.length < 3) return false;

  const lengths = meanLengths(moments);
  const totalCovered = moments.reduce((s, m) => s + (m.endTime - m.startTime), 0);

  // All segments are nearly the same length AND they cover ~the whole video
  const allSameLength = lengths.every(
    (l) => Math.abs(l - lengths[0]) <= Math.max(2, lengths[0] * 0.1)
  );
  const coversWholeVideo = totalCovered >= videoDuration * 0.9;

  // Segments are back-to-back (each starts where the previous ended)
  let contiguous = true;
  for (let i = 1; i < moments.length; i++) {
    if (Math.abs(moments[i].startTime - moments[i - 1].endTime) > 2) {
      contiguous = false;
      break;
    }
  }

  return allSameLength && coversWholeVideo && contiguous;
}

function meanLengths(moments: DetectedMoment[]): number[] {
  return moments.map((m) => m.endTime - m.startTime);
}
