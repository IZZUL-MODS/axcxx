/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  // Node-only packages must run in the Node runtime, unbundled
  serverExternalPackages: ['ab-downloader', 'ffmpeg-static'],
  images: {
    unoptimized: true,
  },

  async headers() {
    return [
      {
        // Allow the proxy to serve video bytes to <video crossOrigin="anonymous">
        source: '/api/proxy',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: '*' },
          {
            key: 'Access-Control-Expose-Headers',
            value: 'Content-Length, Content-Range, Accept-Ranges',
          },
        ],
      },
    ];
  },
};

export default nextConfig;
