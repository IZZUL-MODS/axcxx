// Shared site footer used by every page (home, /demo, /clip)

// Brand icons (removed from newer lucide-react versions) as inline SVGs
function Github({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4" />
      <path d="M9 18c-4.51 2-5-2-7-2" />
    </svg>
  );
}

function Youtube({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
      <path d="m10 15 5-3-5-3z" />
    </svg>
  );
}

export function SiteFooter() {
  return (
    <footer className="relative mt-4 overflow-hidden border-t border-white/10 bg-background/80 px-4 py-10">
      {/* Soft ambient glow */}
      <div className="pointer-events-none absolute inset-x-0 top-0 mx-auto h-px max-w-4xl bg-gradient-to-r from-transparent via-primary/60 to-transparent" />
      <div className="pointer-events-none absolute left-1/2 top-0 h-32 w-72 -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" />

      <div className="relative mx-auto flex max-w-6xl flex-col items-center gap-4 text-center">
        {/* Brand chip */}
        <div className="group relative overflow-hidden rounded-full border border-white/10 bg-white/[0.03] px-5 py-2 shadow-[0_0_40px_-18px] shadow-primary backdrop-blur-xl">
          <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />

          <p className="relative text-sm font-semibold tracking-[0.22em] text-foreground uppercase">
            {'\u00A9'} {new Date().getFullYear()}{' '}
            <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
              IClip
            </span>
          </p>
        </div>

        {/* Social Icons */}
        <div className="flex items-center justify-center gap-4">
          <a
            href="https://github.com/IZZUL-MODS"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="GitHub"
            className="group relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border border-slate-900/10 bg-white/50 shadow-[0_4px_12px_-2px_rgba(0,0,0,0.1)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-slate-900/30 hover:shadow-xl dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
          >
            <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(0,0,0,0.05),transparent)] dark:bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            <Github className="relative z-10 h-5 w-5 text-slate-700 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6 dark:text-white" />
          </a>

          <a
  href="https://youtube.com/@izzul_maker?si=0SOXOpYXJgWtgqbF"
  target="_blank"
  rel="noopener noreferrer"
  aria-label="YouTube"
  className="group relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border border-slate-900/10 bg-white/50 shadow-[0_4px_12px_-2px_rgba(0,0,0,0.1)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-slate-900/30 hover:shadow-xl dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
>
  <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(0,0,0,0.05),transparent)] dark:bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
  <Youtube className="relative z-10 h-5 w-5 text-[#FF0000] transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6" />
</a>

        </div>

        <div className="footer-container">
          <p className="text-xs font-medium tracking-wide text-muted-foreground">
            All rights reserved.
          </p>

          <div className="flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-muted-foreground">
            <span>Made</span>
            <div className="flex items-center gap-2">
              <span className="relative inline-flex h-5 w-5 items-center justify-center" aria-hidden="true">
                <span className="absolute h-5 w-5 rounded-full bg-destructive/20 animate-ping" />
                <span className="relative text-destructive animate-heartbeat">{'\u2665'}</span>
              </span>
              <span>
                by{' '}
                <span className="font-bold text-primary drop-shadow-[0_0_12px_rgba(255,255,255,0.25)]">
                  Izzul
                </span>
              </span>
            </div>
            <span className="sr-only">with love</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
