import Link from 'next/link';
import { ArrowLeft, Link2, Wand2, Download, Play, Scissors, Camera, Film } from 'lucide-react';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/site-footer';

export const metadata = {
  title: 'Demo - Cara Kerja IClip | IClip',
  description:
    'Lihat cara kerja IClip: tempel link video sosial media, AI mencari momen terbaik, lalu unduh klip siap unggah.',
};

const steps = [
  {
    icon: Link2,
    title: 'Tempel Link',
    desc: 'Salin URL video dari sosial media favoritmu dan tempelkan ke halaman clipper.',
  },
  {
    icon: Wand2,
    title: 'AI Cari Momen',
    desc: 'AI memindai video, menandai momen paling clip-worthy beserta titik awal dan akhirnya.',
  },
  {
    icon: Download,
    title: 'Unduh Klip',
    desc: 'Dapatkan klip yang sudah dipotong per momen dan langsung unduh untuk diunggah.',
  },
];

const platforms = ['TikTok', 'Instagram', 'YouTube', 'Facebook', 'Twitter / X', 'Pinterest', 'CapCut'];

export default function DemoPage() {
  return (
    <main className="min-h-screen bg-background">
      <SiteHeader />

      {/* Page heading */}
      <section className="relative border-b border-border px-4 pt-16 pb-12 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/3 h-72 w-72 rounded-full bg-primary/15 blur-3xl" />
          <div className="absolute bottom-0 right-1/3 h-64 w-64 rounded-full bg-cyan-500/10 blur-3xl" />
        </div>

        <div className="mx-auto max-w-3xl text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            <ArrowLeft className="h-4 w-4" />
            Kembali ke beranda
          </Link>

          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wide text-primary">
            <Play className="h-3.5 w-3.5 fill-current" />
            DEMO ALUR KERJA
          </div>

          <h1 className="mt-4 text-3xl font-bold tracking-tight text-balance md:text-4xl">
            Tiga langkah, langsung jadi klip
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-pretty text-muted-foreground">
            Tidak perlu software editing. Cukup tempel link, biarkan AI bekerja, lalu unduh.
          </p>
        </div>
      </section>

      {/* Animated editor mockup */}
      <section className="px-4 pt-16">
        <div className="mx-auto w-full max-w-md">
          <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-background/70 p-4 shadow-[0_18px_60px_-24px] shadow-primary/70 backdrop-blur-xl">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="relative flex h-4 w-4 items-center justify-center">
                  <span className="absolute h-full w-full rounded-full border border-destructive/50 animate-ping" />
                  <span className="h-2 w-2 rounded-full bg-destructive animate-[rec-blink_1.2s_ease-in-out_infinite]" />
                </span>
                <span className="text-[10px] font-bold tracking-[0.25em] text-destructive uppercase">
                  REC
                </span>
                <Camera className="h-4 w-4 text-muted-foreground animate-[shutter_4s_ease-in-out_infinite]" />
              </div>
              <div className="flex items-center gap-3 text-muted-foreground">
                <Scissors className="h-4 w-4 animate-[clip-pop_2.4s_ease-in-out_infinite]" />
                <Film className="h-4 w-4" />
                <span className="rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 text-[10px] font-bold tracking-widest text-primary">
                  AI CUT
                </span>
              </div>
            </div>

            <div className="relative h-12 overflow-hidden rounded-lg border border-white/10 bg-white/[0.03]">
              <div className="absolute inset-0 flex items-center gap-1 px-2">
                {[40, 70, 55, 90, 45, 80, 60, 95, 50, 75, 65, 85, 42, 68, 58].map((h, i) => (
                  <span
                    key={i}
                    className="flex-1 rounded-sm bg-primary/60 origin-center animate-[clip-pop_1.8s_ease-in-out_infinite]"
                    style={{ height: `${h}%`, animationDelay: `${i * 0.12}s` }}
                  />
                ))}
              </div>

              <span className="absolute top-0 left-[30%] h-full w-px bg-accent/70" />
              <span className="absolute top-0 left-[62%] h-full w-px bg-accent/70" />

              <span className="absolute top-0 h-full w-[2px] bg-destructive shadow-[0_0_12px] shadow-destructive animate-[playhead_5s_linear_infinite]">
                <span className="absolute -top-0.5 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-destructive" />
              </span>
            </div>

            <div className="mt-3 flex items-center justify-between text-muted-foreground">
              <div className="flex items-center gap-2">
                <Play className="h-3.5 w-3.5 fill-current text-primary" />
                <span className="font-mono text-[10px] tracking-widest">00:00:14:08</span>
              </div>
              <span className="font-mono text-[10px] tracking-widest text-primary/80">
                3 CLIPS DETECTED
              </span>
            </div>

            <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/5 to-transparent animate-[playhead_6s_linear_infinite]" />
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="px-4 py-16">
        <div className="mx-auto max-w-6xl">
          <div className="grid gap-6 md:grid-cols-3">
            {steps.map((s, i) => (
              <div
                key={s.title}
                className="relative rounded-2xl border border-border bg-background/60 p-6 backdrop-blur"
              >
                <span className="absolute right-5 top-5 font-mono text-4xl font-bold text-primary/15">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg shadow-primary/30">
                  <s.icon className="h-6 w-6" />
                </div>
                <h2 className="mb-2 text-lg font-semibold">{s.title}</h2>
                <p className="text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>

          {/* Supported platforms */}
          <div className="mt-14 text-center">
            <p className="text-sm font-medium uppercase tracking-[0.2em] text-muted-foreground">
              Mendukung platform favoritmu
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
              {platforms.map((p) => (
                <span
                  key={p}
                  className="rounded-full border border-border bg-background/60 px-4 py-2 text-sm font-medium text-foreground/80"
                >
                  {p}
                </span>
              ))}
            </div>
          </div>

          {/* CTA to clipper */}
          <div className="mt-14 flex items-center justify-center">
            <Link
              href="/clip"
              className="relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-primary px-8 py-3 font-semibold text-primary-foreground shadow-[0_0_30px_-8px] shadow-primary/60 transition-transform duration-300 hover:scale-105 group"
            >
              <Scissors className="h-4 w-4" />
              <span className="relative z-10">Coba Sekarang</span>
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </Link>
          </div>
        </div>
      </section>

      <SiteFooter />
    </main>
  );
}
