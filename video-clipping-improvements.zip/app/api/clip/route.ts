import { NextRequest, NextResponse } from 'next/server';
import { spawn } from 'child_process';
import { readFile, unlink, stat } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { randomUUID } from 'crypto';
// @ts-expect-error - ffmpeg-static exports a string path
import ffmpegPath from 'ffmpeg-static';

export const runtime = 'nodejs';
// Generous per-clip timeout — native ffmpeg cuts a 60s segment in seconds,
// even from a 2-hour remote source, because -ss before -i uses HTTP range
// requests to fetch ONLY the segment bytes.
export const maxDuration = 300;

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

// Cache of resolved redirect targets (originalUrl -> finalUrl).
// CDNs like archive.org 302-redirect every request; ffmpeg would otherwise
// pay that redirect cost on EVERY range-seek. Resolving once and passing the
// final URL cuts ~30-40% off total clip time.
const redirectCache = new Map<string, { finalUrl: string; ts: number }>();
const REDIRECT_TTL_MS = 10 * 60 * 1000;

async function resolveFinalUrl(videoUrl: string, referer: string): Promise<string> {
  const cached = redirectCache.get(videoUrl);
  if (cached && Date.now() - cached.ts < REDIRECT_TTL_MS) return cached.finalUrl;
  try {
    const res = await fetch(videoUrl, {
      method: 'HEAD',
      redirect: 'follow',
      headers: { 'User-Agent': UA, Referer: referer },
      signal: AbortSignal.timeout(15000),
    });
    const finalUrl = res.url || videoUrl;
    redirectCache.set(videoUrl, { finalUrl, ts: Date.now() });
    return finalUrl;
  } catch {
    // HEAD not supported or timed out — just use the original URL
    return videoUrl;
  }
}

function runFFmpeg(args: string[], timeoutMs: number): Promise<{ code: number; stderr: string }> {
  return new Promise((resolve, reject) => {
    const proc = spawn(ffmpegPath as string, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let stderr = '';
    const timer = setTimeout(() => {
      proc.kill('SIGKILL');
      reject(new Error('FFmpeg timed out'));
    }, timeoutMs);

    proc.stderr.on('data', (d) => {
      stderr += d.toString();
      // keep only the tail to avoid unbounded memory
      if (stderr.length > 8000) stderr = stderr.slice(-8000);
    });
    proc.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
    proc.on('close', (code) => {
      clearTimeout(timer);
      resolve({ code: code ?? 1, stderr });
    });
  });
}

// Cuts a single clip from a remote video URL using NATIVE ffmpeg.
//
// WHY THIS IS FAST FOR ANY VIDEO LENGTH (even 2h+):
//   `-ss` placed BEFORE `-i` makes ffmpeg seek via HTTP Range requests —
//   it downloads ONLY the bytes of the requested segment, never the whole
//   file. Cutting minute 110 of a 2-hour video costs the same as cutting
//   minute 1 of a 30-second video.
export async function POST(req: NextRequest) {
  let outPath: string | null = null;
  try {
    const { videoUrl, start, duration } = (await req.json()) as {
      videoUrl?: string;
      start?: number;
      duration?: number;
    };

    if (!videoUrl || typeof start !== 'number' || typeof duration !== 'number') {
      return NextResponse.json(
        { error: 'videoUrl, start and duration are required' },
        { status: 400 }
      );
    }

    let parsed: URL;
    try {
      parsed = new URL(videoUrl);
    } catch {
      return NextResponse.json({ error: 'Invalid videoUrl' }, { status: 400 });
    }
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return NextResponse.json({ error: 'Only http/https URLs supported' }, { status: 400 });
    }

    const safeStart = Math.max(0, start);
    // Cap a single clip at 10 minutes to keep responses reasonable
    const safeDuration = Math.min(Math.max(duration, 1), 600);

    outPath = join(tmpdir(), `clip-${randomUUID()}.mp4`);

    const referer = `${parsed.protocol}//${parsed.host}/`;
    const headers = `User-Agent: ${UA}\r\nReferer: ${referer}\r\n`;

    // Resolve redirects ONCE so ffmpeg's range-seeks hit the CDN directly
    const finalUrl = await resolveFinalUrl(videoUrl, referer);

    const baseInputArgs = [
      '-hide_banner',
      '-loglevel', 'error',
      '-headers', headers,
      // Reuse one keep-alive connection for all range requests (much faster)
      '-multiple_requests', '1',
      // Auto-reconnect on flaky CDN connections
      '-reconnect', '1',
      '-reconnect_streamed', '1',
      '-reconnect_delay_max', '5',
      '-ss', safeStart.toFixed(3),
      '-i', finalUrl,
      '-t', safeDuration.toFixed(3),
    ];

    console.log(
      `[clipper] Server cut: start=${safeStart}s dur=${safeDuration}s url=${videoUrl.slice(0, 80)}`
    );

    // Attempt 1: precise re-encode (frame-accurate boundaries).
    // veryfast + crf26 + max 720p → a 60s clip encodes in a few seconds natively.
    const t0 = Date.now();
    let result = await runFFmpeg(
      [
        ...baseInputArgs,
        '-vf', "scale='min(1280,iw)':-2",
        '-c:v', 'libx264',
        '-preset', 'veryfast',
        '-crf', '26',
        '-c:a', 'aac',
        '-b:a', '128k',
        '-movflags', '+faststart',
        '-avoid_negative_ts', 'make_zero',
        '-y', outPath,
      ],
      240000
    );

    let ok = result.code === 0;
    if (ok) {
      const s = await stat(outPath).catch(() => null);
      ok = !!s && s.size > 5000;
    }

    // Attempt 2 (fallback): stream copy — near-instant, boundaries snap to keyframes
    if (!ok) {
      console.warn('[clipper] Re-encode failed, falling back to stream copy:', result.stderr.slice(-500));
      result = await runFFmpeg(
        [
          ...baseInputArgs,
          '-c', 'copy',
          '-movflags', '+faststart',
          '-avoid_negative_ts', 'make_zero',
          '-y', outPath,
        ],
        120000
      );
      ok = result.code === 0;
      if (ok) {
        const s = await stat(outPath).catch(() => null);
        ok = !!s && s.size > 1000;
      }
    }

    if (!ok) {
      console.error('[clipper] Both cut attempts failed:', result.stderr.slice(-800));
      return NextResponse.json(
        { error: 'FFmpeg failed to cut the clip', detail: result.stderr.slice(-500) },
        { status: 500 }
      );
    }

    const buffer = await readFile(outPath);
    console.log(
      `[clipper] Server cut done in ${((Date.now() - t0) / 1000).toFixed(1)}s — ${(buffer.length / 1024 / 1024).toFixed(2)} MB`
    );

    return new NextResponse(new Uint8Array(buffer), {
      status: 200,
      headers: {
        'Content-Type': 'video/mp4',
        'Content-Length': String(buffer.length),
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    console.error('[clipper] Clip route error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to cut clip' },
      { status: 500 }
    );
  } finally {
    if (outPath) {
      unlink(outPath).catch(() => {});
    }
  }
}
