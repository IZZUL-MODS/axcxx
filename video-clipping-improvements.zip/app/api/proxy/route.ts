import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';
// 5-minute timeout — supports very large videos (1h+ at typical bitrates)
export const maxDuration = 300;

// CORS preflight for <video crossOrigin="anonymous"> range requests
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Range, Content-Type',
      'Access-Control-Expose-Headers':
        'Content-Length, Content-Range, Accept-Ranges',
    },
  });
}

// Cache of resolved redirect targets (originalUrl -> finalUrl) so repeated
// range-seeks from the browser don't re-pay the CDN redirect on every request.
const redirectCache = new Map<string, { finalUrl: string; ts: number }>();
const REDIRECT_TTL_MS = 10 * 60 * 1000;

// Streams the remote video through the server to the browser (no storage used).
// Supports byte-range requests so the browser can resume and seek efficiently.
export async function GET(req: NextRequest) {
  const videoUrl = req.nextUrl.searchParams.get('url');

  if (!videoUrl) {
    return NextResponse.json({ error: 'url parameter is required' }, { status: 400 });
  }

  let parsed: URL;
  try {
    parsed = new URL(videoUrl);
  } catch {
    return NextResponse.json({ error: 'Invalid URL' }, { status: 400 });
  }
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    return NextResponse.json({ error: 'Only http/https URLs are supported' }, { status: 400 });
  }

  // Forward Range header if present (allows browser to seek without re-downloading)
  const rangeHeader = req.headers.get('range');

  try {
    console.log('[clipper] Proxying video:', videoUrl.slice(0, 100), rangeHeader ? `range: ${rangeHeader}` : '');
    const upstreamHeaders: Record<string, string> = {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
      Accept: '*/*',
      Referer: `${parsed.protocol}//${parsed.host}/`,
    };
    if (rangeHeader) upstreamHeaders['Range'] = rangeHeader;

    // Use the cached post-redirect URL when available (skips a 302 round trip)
    const cached = redirectCache.get(videoUrl);
    const targetUrl =
      cached && Date.now() - cached.ts < REDIRECT_TTL_MS
        ? cached.finalUrl
        : videoUrl;

    const upstream = await fetch(targetUrl, {
      headers: upstreamHeaders,
      redirect: 'follow',
    });

    // Remember where the CDN actually served from for future seeks
    if (upstream.ok && upstream.url && upstream.url !== videoUrl) {
      redirectCache.set(videoUrl, { finalUrl: upstream.url, ts: Date.now() });
    }

    if (!upstream.ok || !upstream.body) {
      return NextResponse.json(
        { error: `Upstream returned ${upstream.status}` },
        { status: 502 }
      );
    }

    const contentType = upstream.headers.get('content-type') || 'video/mp4';
    const contentLength = upstream.headers.get('content-length');
    const contentRange = upstream.headers.get('content-range');
    const acceptRanges = upstream.headers.get('accept-ranges') || 'bytes';

    const responseHeaders = new Headers({
      'Content-Type': contentType,
      'Cache-Control': 'no-store',
      // Always advertise range support so the browser <video> can seek
      'Accept-Ranges': acceptRanges,
      // CORS headers required for crossOrigin="anonymous" on <video> elements
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Expose-Headers':
        'Content-Length, Content-Range, Accept-Ranges',
    });
    if (contentLength) responseHeaders.set('Content-Length', contentLength);
    if (contentRange) responseHeaders.set('Content-Range', contentRange);

    // 206 Partial Content when upstream responded to a range request
    const status = upstream.status === 206 ? 206 : 200;

    return new NextResponse(upstream.body, { status, headers: responseHeaders });
  } catch (error) {
    console.error('[clipper] Proxy error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to fetch video' },
      { status: 500 }
    );
  }
}
