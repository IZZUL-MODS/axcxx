import Link from 'next/link';
import {
  Zap,
  Clapperboard,
  Smartphone,
  Camera,
  Scissors,
  Film,
  Play,
  Bot,
  Link2,
  Download,
  Wand2,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { SiteHeader } from '@/components/site-header';

// Brand icons (removed from newer lucide-react versions) as inline SVGs
function Github({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4" />
      <path d="M9 18c-4.51 2-5-2-7-2" />
    </svg>
  );
}

function Youtube({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17" />
      <path d="m10 15 5-3-5-3z" />
    </svg>
  );
}

const features = [
  {
    icon: Bot,
    title: 'Deteksi Momen AI',
    desc: 'Gemini Vision menganalisis frame demi frame dan menemukan momen paling menarik — bukan asal memotong.',
  },
  {
    icon: Scissors,
    title: 'Potong Utuh Per Momen',
    desc: 'Setiap klip dipotong dari awal hingga akhir aksi, jadi momen penting tidak pernah terpotong setengah.',
  },
  {
    icon: Smartphone,
    title: 'Semua Platform',
    desc: 'TikTok, Instagram, YouTube, Facebook, Twitter/X, Pinterest, sampai CapCut — cukup tempel link-nya.',
  },
  {
    icon: Zap,
    title: 'Proses di Browser',
    desc: 'Pemotongan berjalan langsung di browser dengan FFmpeg. Cepat, tanpa antre, tanpa upload ke server.',
  },
  {
    icon: ShieldCheck,
    title: 'Tanpa Penyimpanan',
    desc: 'Video kamu tidak disimpan di mana pun. Semua diproses lokal lalu langsung bisa diunduh.',
  },
  {
    icon: Clock,
    title: 'Hemat Waktu',
    desc: 'Dari video panjang menjadi beberapa klip viral hanya dalam hitungan detik, siap diunggah.',
  },
];

const steps = [
  {
    icon: Link2,
    title: 'Tempel Link',
    desc: 'Salin URL video dari sosial media favoritmu dan tempelkan ke halaman clipper.',
  },
  {
    icon: Wand2,
    title: 'AI Cari Momen',
    desc: 'AI memindai video, menandai momen paling clip-worthy beserta titik awal dan akhirnya.',
  },
  {
    icon: Download,
    title: 'Unduh Klip',
    desc: 'Dapatkan klip yang sudah dipotong per momen dan langsung unduh untuk diunggah.',
  },
];

const platforms = ['TikTok', 'Instagram', 'YouTube', 'Facebook', 'Twitter / X', 'Pinterest', 'CapCut'];

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <SiteHeader />

      {/* Hero Section */}
      <section className="relative pt-24 pb-20 px-4 border-b border-border overflow-hidden">
        {/* Animated gradient orbs */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-float-slow" />
          <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl animate-float-slower" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-3xl animate-pulse-glow" />
        </div>

        {/* Grid background dengan fade */}
        <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,rgba(255,255,255,0.04)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.04)_1px,transparent_1px)] bg-[size:48px_48px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,black,transparent)]" />

        {/* Floating particles */}
        <div className="absolute inset-0 -z-10 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <span
              key={i}
              className="absolute w-1 h-1 bg-primary/60 rounded-full animate-particle"
              style={{
                left: `${15 + i * 14}%`,
                top: `${20 + (i % 3) * 25}%`,
                animationDelay: `${i * 0.8}s`,
              }}
            />
          ))}
        </div>

        <div className="mx-auto max-w-4xl text-center">
          {/* Animated Video Editing Timeline */}
          <div className="mx-auto mb-8 w-full max-w-md animate-fade-in-up">
            <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-background/70 p-4 shadow-[0_18px_60px_-24px] shadow-primary/70 backdrop-blur-xl">
              {/* Top bar: REC indicator + tools */}
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-4 w-4 items-center justify-center">
                    <span className="absolute h-full w-full rounded-full border border-destructive/50 animate-ping" />
                    <span className="h-2 w-2 rounded-full bg-destructive animate-[rec-blink_1.2s_ease-in-out_infinite]" />
                  </span>
                  <span className="text-[10px] font-bold tracking-[0.25em] text-destructive uppercase">
                    REC
                  </span>
                  <Camera className="h-4 w-4 text-muted-foreground animate-[shutter_4s_ease-in-out_infinite]" />
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Scissors className="h-4 w-4 animate-[clip-pop_2.4s_ease-in-out_infinite]" />
                  <Film className="h-4 w-4" />
                  <span className="rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 text-[10px] font-bold tracking-widest text-primary">
                    AI CUT
                  </span>
                </div>
              </div>

              {/* Timeline track with clip segments */}
              <div className="relative h-12 overflow-hidden rounded-lg border border-white/10 bg-white/[0.03]">
                <div className="absolute inset-0 flex items-center gap-1 px-2">
                  {[40, 70, 55, 90, 45, 80, 60, 95, 50, 75, 65, 85, 42, 68, 58].map((h, i) => (
                    <span
                      key={i}
                      className="flex-1 rounded-sm bg-primary/60 origin-center animate-[clip-pop_1.8s_ease-in-out_infinite]"
                      style={{ height: `${h}%`, animationDelay: `${i * 0.12}s` }}
                    />
                  ))}
                </div>

                {/* Cut markers */}
                <span className="absolute top-0 left-[30%] h-full w-px bg-accent/70" />
                <span className="absolute top-0 left-[62%] h-full w-px bg-accent/70" />

                {/* Moving playhead */}
                <span className="absolute top-0 h-full w-[2px] bg-destructive shadow-[0_0_12px] shadow-destructive animate-[playhead_5s_linear_infinite]">
                  <span className="absolute -top-0.5 left-1/2 h-2 w-2 -translate-x-1/2 rotate-45 bg-destructive" />
                </span>
              </div>

              {/* Bottom bar: play + timecode */}
              <div className="mt-3 flex items-center justify-between text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Play className="h-3.5 w-3.5 fill-current text-primary" />
                  <span className="font-mono text-[10px] tracking-widest">00:00:14:08</span>
                </div>
                <span className="font-mono text-[10px] tracking-widest text-primary/80">
                  3 CLIPS DETECTED
                </span>
              </div>

              {/* Inner shine sweep */}
              <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/5 to-transparent animate-[playhead_6s_linear_infinite]" />
            </div>
          </div>

          {/* Headline dengan gradient shimmer */}
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 animate-fade-in-up [animation-delay:150ms] opacity-0 [animation-fill-mode:forwards]">
            <span className="bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
              Ubah Video Panjang Jadi Klip Viral
            </span>
          </h1>

          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 animate-fade-in-up [animation-delay:300ms] opacity-0 [animation-fill-mode:forwards]">
            Biarkan AI memotong momen terbaik dari videomu secara otomatis, siap diunggah dalam hitungan detik.
          </p>

          {/* CTA dengan hover glow & scale */}
          <div className="flex items-center justify-center gap-4 animate-fade-in-up [animation-delay:450ms] opacity-0 [animation-fill-mode:forwards]">
            <Link
              href="/clip"
              className="relative px-8 py-3 rounded-full bg-primary text-primary-foreground font-semibold overflow-hidden transition-transform duration-300 hover:scale-105 shadow-[0_0_30px_-8px] shadow-primary/60 group"
            >
              <span className="relative z-10">Mulai Gratis</span>
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </Link>
            <Link
              href="#demo"
              className="px-8 py-3 rounded-full border border-border font-semibold hover:border-primary/50 hover:bg-primary/5 transition-all duration-300 hover:scale-105"
            >
              Lihat Demo
            </Link>
          </div>

          <div className="mt-12 flex gap-8 justify-center flex-wrap">
            <div className="flex flex-col items-center gap-2">
              <Zap className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Auto-detect</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Clapperboard className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">Multi-clips</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Smartphone className="w-6 h-6 text-accent" />
              <p className="text-sm text-muted-foreground">All Platforms</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 py-20">
        <div className="mx-auto max-w-6xl">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
              Kenapa pakai IClip?
            </h2>
            <p className="mt-4 text-muted-foreground text-pretty">
              Dibuat khusus untuk menemukan momen terbaik dari video panjangmu, bukan sekadar
              membelahnya jadi potongan acak.
            </p>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div
                key={f.title}
                className="group rounded-2xl border border-border bg-card/50 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/10"
              >
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-transform duration-300 group-hover:scale-110">
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-lg font-semibold">{f.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works / Demo */}
      <section id="demo" className="scroll-mt-20 border-y border-border bg-card/30 px-4 py-20">
        <div className="mx-auto max-w-6xl">
          <div className="mx-auto max-w-2xl text-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wide text-primary">
              <Play className="h-3.5 w-3.5 fill-current" />
              DEMO ALUR KERJA
            </span>
            <h2 className="mt-4 text-3xl md:text-4xl font-bold tracking-tight text-balance">
              Tiga langkah, langsung jadi klip
            </h2>
            <p className="mt-4 text-muted-foreground text-pretty">
              Tidak perlu software editing. Cukup tempel link, biarkan AI bekerja, lalu unduh.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {steps.map((s, i) => (
              <div
                key={s.title}
                className="relative rounded-2xl border border-border bg-background/60 p-6 backdrop-blur"
              >
                <span className="absolute right-5 top-5 font-mono text-4xl font-bold text-primary/15">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg shadow-primary/30">
                  <s.icon className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-lg font-semibold">{s.title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{s.desc}</p>
              </div>
            ))}
          </div>

          {/* Supported platforms */}
          <div className="mt-14 text-center">
            <p className="text-sm font-medium uppercase tracking-[0.2em] text-muted-foreground">
              Mendukung platform favoritmu
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
              {platforms.map((p) => (
                <span
                  key={p}
                  className="rounded-full border border-border bg-background/60 px-4 py-2 text-sm font-medium text-foreground/80"
                >
                  {p}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA band */}
      <section className="px-4 py-20">
        <div className="mx-auto max-w-4xl overflow-hidden rounded-3xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-background p-10 text-center shadow-xl shadow-primary/10 md:p-14">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight text-balance">
            Siap membuat klip viral pertamamu?
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground text-pretty">
            Tempel link video apa pun dan biarkan AI menemukan momen terbaiknya. Gratis, tanpa daftar.
          </p>
          <div className="mt-8 flex items-center justify-center gap-4">
            <Link
              href="/clip"
              className="relative inline-flex items-center gap-2 overflow-hidden rounded-full bg-primary px-8 py-3 font-semibold text-primary-foreground shadow-[0_0_30px_-8px] shadow-primary/60 transition-transform duration-300 hover:scale-105 group"
            >
              <Scissors className="h-4 w-4" />
              <span className="relative z-10">Mulai Gratis</span>
              <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative mt-4 overflow-hidden border-t border-white/10 bg-background/80 px-4 py-10">
        {/* Soft ambient glow */}
        <div className="pointer-events-none absolute inset-x-0 top-0 mx-auto h-px max-w-4xl bg-gradient-to-r from-transparent via-primary/60 to-transparent" />
        <div className="pointer-events-none absolute left-1/2 top-0 h-32 w-72 -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" />

        <div className="relative mx-auto flex max-w-6xl flex-col items-center gap-4 text-center">
          {/* Brand chip */}
          <div className="group relative overflow-hidden rounded-full border border-white/10 bg-white/[0.03] px-5 py-2 shadow-[0_0_40px_-18px] shadow-primary backdrop-blur-xl">
            <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />

            <p className="relative text-sm font-semibold tracking-[0.22em] text-foreground uppercase">
              {'\u00A9'} {new Date().getFullYear()}{' '}
              <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
                IClip
              </span>
            </p>
          </div>

          {/* Social Icons Container */}
          <div className="flex items-center justify-center gap-4">
            {/* GitHub */}
            <a
              href="https://github.com/IZZUL-MODS"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="group relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border border-slate-900/10 bg-white/50 shadow-[0_4px_12px_-2px_rgba(0,0,0,0.1)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-slate-900/30 hover:shadow-xl dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
            >
              <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(0,0,0,0.05),transparent)] dark:bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <Github className="relative z-10 h-5 w-5 text-slate-700 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6 dark:text-white" />
            </a>

            {/* YouTube */}
            <a
              href="https://youtube.com/@izzul_maker?si=0SOXOpYXJgWtgqbF"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
              className="group relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border border-slate-900/10 bg-white/50 shadow-[0_4px_12px_-2px_rgba(0,0,0,0.1)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-slate-900/30 hover:shadow-xl dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
            >
              <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(0,0,0,0.05),transparent)] dark:bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <Youtube className="relative z-10 h-5 w-5 text-slate-700 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6 dark:text-white" />
            </a>
          </div>

          <div className="footer-container">
            <p className="text-xs font-medium tracking-wide text-muted-foreground">
              All rights reserved.
            </p>

            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-muted-foreground">
              <span>Made</span>
              <div className="flex items-center gap-2">
                <span className="relative inline-flex h-5 w-5 items-center justify-center" aria-hidden="true">
                  <span className="absolute h-5 w-5 rounded-full bg-destructive/20 animate-ping" />
                  <span className="relative text-destructive animate-heartbeat">{'\u2665'}</span>
                </span>
                <span>
                  by{' '}
                  <span className="font-bold text-primary drop-shadow-[0_0_12px_rgba(255,255,255,0.25)]">
                    Izzul
                  </span>
                </span>
              </div>
              <span className="sr-only">with love</span>
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}
