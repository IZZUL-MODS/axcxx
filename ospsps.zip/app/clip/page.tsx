import Link from 'next/link';
import { ArrowLeft, Link2, Sparkles } from 'lucide-react';
import { SiteHeader } from '@/components/site-header';
import { ClipTool } from '@/components/clip-tool';

export const metadata = {
  title: 'Clipper - Potong Klip dari URL | IClip',
  description:
    'Tempel link TikTok, Instagram, YouTube, Facebook, atau Twitter/X dan biarkan AI memotong momen terbaiknya jadi klip.',
};

export default function ClipPage() {
  return (
    <main className="min-h-screen bg-background">
      <SiteHeader />

      {/* Page heading */}
      <section className="relative border-b border-border px-4 pt-16 pb-12 overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/3 h-72 w-72 rounded-full bg-primary/15 blur-3xl" />
          <div className="absolute bottom-0 right-1/3 h-64 w-64 rounded-full bg-cyan-500/10 blur-3xl" />
        </div>

        <div className="mx-auto max-w-3xl text-center">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
          >
            <ArrowLeft className="h-4 w-4" />
            Kembali ke beranda
          </Link>

          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-xs font-semibold tracking-wide text-primary">
            <Sparkles className="h-3.5 w-3.5" />
            AI CLIPPER
          </div>

          <h1 className="mt-4 flex items-center justify-center gap-3 text-3xl font-bold tracking-tight text-balance md:text-4xl">
            <Link2 className="h-7 w-7 text-primary" />
            Potong Klip dari URL
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-pretty text-muted-foreground">
            Tempel link video sosial media, lalu AI akan mendeteksi momen paling menarik dan
            memotongnya menjadi klip siap unggah — bukan sekadar membelah video jadi beberapa bagian.
          </p>
        </div>
      </section>

      {/* Clipper tool */}
      <section className="px-4 py-16">
        <ClipTool />
      </section>
      
      {/* Footer */}
      <footer className="relative mt-4 overflow-hidden border-t border-white/10 bg-background/80 px-4 py-10">
        {/* Soft ambient glow */}
        <div className="pointer-events-none absolute inset-x-0 top-0 mx-auto h-px max-w-4xl bg-gradient-to-r from-transparent via-primary/60 to-transparent" />
        <div className="pointer-events-none absolute left-1/2 top-0 h-32 w-72 -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" />

        <div className="relative mx-auto flex max-w-6xl flex-col items-center gap-4 text-center">
          {/* Brand chip */}
          <div className="group relative overflow-hidden rounded-full border border-white/10 bg-white/[0.03] px-5 py-2 shadow-[0_0_40px_-18px] shadow-primary backdrop-blur-xl">
            <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/15 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />

            <p className="relative text-sm font-semibold tracking-[0.22em] text-foreground uppercase">
              {'\u00A9'} {new Date().getFullYear()}{' '}
              <span className="text-lg font-bold tracking-tight bg-gradient-to-r from-foreground via-primary to-foreground bg-[length:200%_auto] bg-clip-text text-transparent animate-shimmer">
                IClip
              </span>
            </p>
          </div>

          {/* Social Icons Container */}
          <div className="flex items-center justify-center gap-4">
            {/* GitHub */}
            <a
              href="https://github.com/IZZUL-MODS"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="group relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border border-slate-900/10 bg-white/50 shadow-[0_4px_12px_-2px_rgba(0,0,0,0.1)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-slate-900/30 hover:shadow-xl dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
            >
              <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(0,0,0,0.05),transparent)] dark:bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <Github className="relative z-10 h-5 w-5 text-slate-700 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6 dark:text-white" />
            </a>

            {/* YouTube */}
            <a
              href="https://youtube.com/@izzul_maker?si=0SOXOpYXJgWtgqbF"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
              className="group relative grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border border-slate-900/10 bg-white/50 shadow-[0_4px_12px_-2px_rgba(0,0,0,0.1)] backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-slate-900/30 hover:shadow-xl dark:border-white/10 dark:bg-white/[0.04] dark:shadow-none"
            >
              <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(0,0,0,0.05),transparent)] dark:bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.1),transparent)] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
              <Youtube className="relative z-10 h-5 w-5 text-slate-700 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6 dark:text-white" />
            </a>
          </div>

          <div className="footer-container">
            <p className="text-xs font-medium tracking-wide text-muted-foreground">
              All rights reserved.
            </p>

            <div className="flex items-center gap-2 text-xs uppercase tracking-[0.28em] text-muted-foreground">
              <span>Made</span>
              <div className="flex items-center gap-2">
                <span className="relative inline-flex h-5 w-5 items-center justify-center" aria-hidden="true">
                  <span className="absolute h-5 w-5 rounded-full bg-destructive/20 animate-ping" />
                  <span className="relative text-destructive animate-heartbeat">{'\u2665'}</span>
                </span>
                <span>
                  by{' '}
                  <span className="font-bold text-primary drop-shadow-[0_0_12px_rgba(255,255,255,0.25)]">
                    Izzul
                  </span>
                </span>
              </div>
              <span className="sr-only">with love</span>
            </div>
          </div>
        </div>
      </footer>
    </main>
  );
}
