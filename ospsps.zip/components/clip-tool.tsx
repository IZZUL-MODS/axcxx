'use client';

import { useState } from 'react';
import { InputForm } from '@/components/input-form';
import { ProcessingStatus, type ProcessingStep } from '@/components/processing-status';
import { ClipsGallery } from '@/components/clips-gallery';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

export function ClipTool() {
  const [isLoading, setIsLoading] = useState(false);
  const [clips, setClips] = useState<Clip[]>([]);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [showResults, setShowResults] = useState(false);

  const updateStep = (stepName: string, status: ProcessingStep['status'], message?: string) => {
    setProcessingSteps((prev) => {
      const existing = prev.find((s) => s.name === stepName);
      if (existing) {
        return prev.map((s) => (s.name === stepName ? { ...s, status, message } : s));
      }
      return [...prev, { name: stepName, status, message }];
    });
  };

  const handleUrlSubmit = async (url: string) => {
    setIsLoading(true);
    setClips([]);
    setProcessingSteps([]);
    setShowResults(true);

    try {
      // Step 1: Resolve social media URL to direct video URL via ab-downloader
      updateStep('Resolving URL', 'processing', 'Extracting video from social media link...');
      console.log('[clipper] Resolving URL:', url);
      const resolveRes = await fetch('/api/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const resolveData = await resolveRes.json();
      if (!resolveRes.ok) {
        throw new Error(resolveData.error || 'Failed to resolve video URL');
      }
      const { videoUrl, title } = resolveData as { videoUrl: string; title: string };
      console.log('[clipper] Resolved video:', title);
      updateStep('Resolving URL', 'completed', title);

      // Step 2: Download video into the browser through the proxy (no storage)
      updateStep('Downloading Video', 'processing', 'Fetching video into your browser...');
      const proxyRes = await fetch(`/api/proxy?url=${encodeURIComponent(videoUrl)}`);
      if (!proxyRes.ok) {
        const err = await proxyRes.json().catch(() => null);
        throw new Error(err?.error || 'Failed to download video');
      }
      const arrayBuffer = await proxyRes.arrayBuffer();
      const videoBuffer = new Uint8Array(arrayBuffer);
      console.log('[clipper] Downloaded video, size:', videoBuffer.length, 'bytes');
      if (videoBuffer.length < 10000) {
        throw new Error('Downloaded file is too small — the link may not contain a video');
      }
      updateStep('Downloading Video', 'completed', `${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`);

      // Step 3: Load FFmpeg
      updateStep('Loading FFmpeg', 'processing', 'Initializing video processing...');
      const { initFFmpeg, extractFramesAsImages, cutVideoClips, getVideoDurationFromBuffer } =
        await import('@/lib/ffmpeg-client');
      console.log('[clipper] Initializing FFmpeg...');
      await initFFmpeg();
      updateStep('Loading FFmpeg', 'completed');

      // Step 4: Get video duration
      updateStep('Analyzing Video', 'processing', 'Reading video metadata...');
      console.log('[clipper] Getting video duration...');
      const duration = await getVideoDurationFromBuffer(videoBuffer);
      console.log('[clipper] Video duration:', duration, 'seconds');
      updateStep('Analyzing Video', 'completed', `Duration: ${Math.round(duration)}s`);

      // Step 5: AI analysis — the AI returns FULL moments (start → end of scene),
      // so clips are NOT limited to a fixed length and never cut a moment short.
      let detectedMoments: Array<{
        startTime: number;
        endTime: number;
        actionType: string;
        intensity: number;
        description: string;
      }> = [];
      let usedAi = false;

      const geminiApiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (geminiApiKey) {
        try {
          updateStep('Detecting Moments', 'processing', 'AI menganalisis momen penting...');
          const { initGemini, detectMoments } = await import('@/lib/gemini-client');
          initGemini(geminiApiKey);

          // Hard overall timeout: if AI analysis takes too long, abort it and
          // fall back to smart segmentation so processing NEVER hangs here.
          const AI_TIMEOUT_MS = 120000;
          const aiAnalysis = async () => {
            // Dense sampling (~1 frame / 1.5s) so the AI can judge where each
            // scene starts AND ends and pick genuine highlight moments.
            const frameInterval = Math.max(1, Math.min(3, Math.floor(duration / 30) || 1));
            const frames = await extractFramesAsImages(
              videoBuffer,
              duration,
              frameInterval,
              (current, total) => {
                updateStep('Detecting Moments', 'processing', `Mengambil frame ${current}/${total}...`);
              },
              24
            );
            console.log('[clipper] Extracted frames:', frames.length);
            if (frames.length === 0) throw new Error('No frames could be extracted');

            updateStep('Detecting Moments', 'processing', `AI menganalisis ${frames.length} frame...`);
            return detectMoments(frames, duration);
          };

          detectedMoments = await Promise.race([
            aiAnalysis(),
            new Promise<never>((_, reject) =>
              setTimeout(() => reject(new Error('AI analysis timed out')), AI_TIMEOUT_MS)
            ),
          ]);
          usedAi = detectedMoments.length > 0;
          console.log('[clipper] AI detected moments:', detectedMoments);
        } catch (aiError) {
          console.error('[clipper] AI analysis failed, using smart segmentation fallback:', aiError);
          updateStep('Detecting Moments', 'processing', 'AI tidak tersedia — memakai segmentasi cerdas...');
          detectedMoments = [];
        }
      } else {
        updateStep('Detecting Moments', 'processing', 'API key belum diset — memakai segmentasi cerdas...');
      }

      // Fallback: only when the AI found no moments. Splits into a few
      // variable-length highlight segments (NOT a fixed 6-way chop).
      if (detectedMoments.length === 0) {
        const segmentCount = Math.min(4, Math.max(2, Math.round(duration / 25)));
        const base = duration / segmentCount;
        for (let i = 0; i < segmentCount; i++) {
          const start = Math.floor(base * i);
          const end = i === segmentCount - 1 ? Math.floor(duration) : Math.floor(base * (i + 1));
          detectedMoments.push({
            startTime: start,
            endTime: end,
            actionType: 'Highlight',
            intensity: 6,
            description: `Segmen highlight ${i + 1} (${start}s - ${end}s)`,
          });
        }
      }
      detectedMoments.sort((a, b) => a.startTime - b.startTime);
      updateStep(
        'Detecting Moments',
        'completed',
        usedAi
          ? `AI menemukan ${detectedMoments.length} momen penting`
          : `${detectedMoments.length} segmen (fallback)`
      );

      // Step 6: Build clip segments directly from the moment boundaries —
      // each clip runs from the start of the scene until it fully finishes.
      const clipSegments = detectedMoments.map((moment, index) => {
        const start = Math.max(0, moment.startTime);
        const end = Math.min(duration, Math.max(moment.endTime, start + 3));
        return {
          startTime: start,
          endTime: end,
          clipId: `clip_${index + 1}`,
          description: `${moment.actionType}: ${moment.description}`,
        };
      });
      console.log('[clipper] Clip segments:', clipSegments);

      // Step 7: Generate clips with FFmpeg in the browser
      updateStep('Generating Clips', 'processing', `Memotong ${clipSegments.length} klip...`);
      const generatedClips = await cutVideoClips(videoBuffer, clipSegments, (current, total) => {
        updateStep('Generating Clips', 'processing', `Memotong klip ${current}/${total}...`);
      });

      if (generatedClips.length === 0) {
        throw new Error('Failed to generate clips from this video');
      }

      const clipsData: Clip[] = generatedClips.map((clip) => {
        const segIndex = clipSegments.findIndex((s) => s.clipId === clip.clipId);
        const seg = clipSegments[segIndex];
        return {
          clipId: clip.clipId,
          startTime: seg.startTime,
          endTime: seg.endTime,
          description: seg.description,
          intensity: detectedMoments[segIndex]?.intensity ?? 7,
          duration: seg.endTime - seg.startTime,
          blobUrl: URL.createObjectURL(clip.blob),
          fileSize: clip.blob.size,
        };
      });

      setClips(clipsData);
      updateStep('Generating Clips', 'completed', `Generated ${clipsData.length} clips`);
      updateStep('Complete', 'completed', 'Klip siap diunduh!');

      console.log('[clipper] Processing complete. Clips:', clipsData.length);
    } catch (error) {
      console.error('[clipper] Error processing video:', error);
      updateStep('Error', 'error', error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-12">
      {/* Input Form */}
      <InputForm onSubmit={handleUrlSubmit} isLoading={isLoading} />

      {/* Processing Status */}
      {showResults && (
        <ProcessingStatus
          steps={processingSteps}
          isComplete={!isLoading && clips.length > 0}
          clipsCount={clips.length}
        />
      )}

      {/* Clips Gallery */}
      {clips.length > 0 && !isLoading && (
        <div className="py-8">
          <ClipsGallery clips={clips} />
        </div>
      )}
    </div>
  );
}
