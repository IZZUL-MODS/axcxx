'use client';

import { useState } from 'react';
import { InputForm } from '@/components/input-form';
import { ProcessingStatus, type ProcessingStep } from '@/components/processing-status';
import { ClipsGallery } from '@/components/clips-gallery';

interface Clip {
  clipId: string;
  startTime: number;
  endTime: number;
  description: string;
  intensity: number;
  duration: number;
  blobUrl?: string;
  fileSize?: number;
}

export function ClipTool() {
  const [isLoading, setIsLoading] = useState(false);
  const [clips, setClips] = useState<Clip[]>([]);
  const [processingSteps, setProcessingSteps] = useState<ProcessingStep[]>([]);
  const [showResults, setShowResults] = useState(false);

  const updateStep = (stepName: string, status: ProcessingStep['status'], message?: string) => {
    setProcessingSteps((prev) => {
      const existing = prev.find((s) => s.name === stepName);
      if (existing) {
        return prev.map((s) => (s.name === stepName ? { ...s, status, message } : s));
      }
      return [...prev, { name: stepName, status, message }];
    });
  };

  const handleUrlSubmit = async (url: string) => {
    setIsLoading(true);
    setClips([]);
    setProcessingSteps([]);
    setShowResults(true);

    try {
      // Step 1: Resolve social media URL to direct video URL via ab-downloader
      updateStep('Resolving URL', 'processing', 'Extracting video from social media link...');
      console.log('[clipper] Resolving URL:', url);
      const resolveRes = await fetch('/api/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });
      const resolveData = await resolveRes.json();
      if (!resolveRes.ok) {
        throw new Error(resolveData.error || 'Failed to resolve video URL');
      }
      const { videoUrl, title } = resolveData as { videoUrl: string; title: string };
      console.log('[clipper] Resolved video:', title);
      updateStep('Resolving URL', 'completed', title);

      // Step 2: Download video into the browser through the proxy (no storage)
      updateStep('Downloading Video', 'processing', 'Fetching video into your browser...');
      const proxyRes = await fetch(`/api/proxy?url=${encodeURIComponent(videoUrl)}`);
      if (!proxyRes.ok) {
        const err = await proxyRes.json().catch(() => null);
        throw new Error(err?.error || 'Failed to download video');
      }
      const arrayBuffer = await proxyRes.arrayBuffer();
      const videoBuffer = new Uint8Array(arrayBuffer);
      console.log('[clipper] Downloaded video, size:', videoBuffer.length, 'bytes');
      if (videoBuffer.length < 10000) {
        throw new Error('Downloaded file is too small — the link may not contain a video');
      }
      updateStep('Downloading Video', 'completed', `${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`);

      // Step 3: Load FFmpeg
      updateStep('Loading FFmpeg', 'processing', 'Initializing video processing...');
      const { initFFmpeg, extractFramesAsImages, cutVideoClips, getVideoDurationFromBuffer } =
        await import('@/lib/ffmpeg-client');
      console.log('[clipper] Initializing FFmpeg...');
      await initFFmpeg();
      updateStep('Loading FFmpeg', 'completed');

      // Step 4: Get video duration
      updateStep('Analyzing Video', 'processing', 'Reading video metadata...');
      console.log('[clipper] Getting video duration...');
      const duration = await getVideoDurationFromBuffer(videoBuffer);
      console.log('[clipper] Video duration:', duration, 'seconds');
      updateStep('Analyzing Video', 'completed', `Duration: ${Math.round(duration)}s`);

      // Step 5: Extract frames using native <video>+<canvas> (fast, no ffmpeg overhead).
      // intervalSeconds is auto-calculated inside extractFramesAsImages from maxFrames.
      updateStep('Extracting Frames', 'processing', 'Mengambil frame untuk analisis...');
      // 1 frame per ~2s, max 32 frames — enough for accurate moment detection
      const frameInterval = Math.max(1, Math.round(duration / 32));
      const frames = await extractFramesAsImages(
        videoBuffer,
        duration,
        frameInterval,
        (current, total) => {
          updateStep('Extracting Frames', 'processing', `Mengambil frame ${current}/${total}...`);
        },
        32
      );
      console.log('[clipper] Extracted frames:', frames.length);
      if (frames.length === 0) {
        throw new Error('Tidak ada frame yang bisa diekstrak dari video ini');
      }
      updateStep('Extracting Frames', 'completed', `${frames.length} frame`);

      // Step 6: Moment detection. Priority:
      //   1. Gemini AI vision analysis (finds genuinely crucial moments)
      //   2. Motion-based activity detection (finds real action peaks)
      // NEVER a blind equal-length split of the video.
      let detectedMoments: Array<{
        startTime: number;
        endTime: number;
        actionType: string;
        intensity: number;
        description: string;
      }> = [];
      let detectionMethod: 'ai' | 'motion' = 'motion';
      let aiFailReason = '';

      const { looksLikeUniformSplit, detectMotionMoments } = await import('@/lib/motion-detect');

      const geminiApiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
      if (geminiApiKey) {
        try {
          updateStep('Detecting Moments', 'processing', `AI menganalisis ${frames.length} frame...`);
          const { initGemini, detectMoments } = await import('@/lib/gemini-client');
          initGemini(geminiApiKey);

          // Hard overall timeout so AI analysis can never hang the pipeline
          const AI_TIMEOUT_MS = 120000;
          const aiMoments = await Promise.race([
            detectMoments(frames, duration),
            new Promise<never>((_, reject) =>
              setTimeout(() => reject(new Error('AI analysis timed out')), AI_TIMEOUT_MS)
            ),
          ]);
          console.log('[clipper] AI detected moments:', aiMoments);

          // Reject "lazy" AI output that is just an equal split of the video
          if (aiMoments.length > 0 && looksLikeUniformSplit(aiMoments, duration)) {
            console.log('[clipper] AI output rejected: looks like a uniform split, not real highlights');
            aiFailReason = 'Output AI berupa potongan seragam — ditolak';
          } else if (aiMoments.length > 0) {
            detectedMoments = aiMoments;
            detectionMethod = 'ai';
          } else {
            aiFailReason = 'AI tidak menemukan momen';
          }
        } catch (aiError) {
          aiFailReason = aiError instanceof Error ? aiError.message : 'AI error';
          console.error('[clipper] AI analysis failed:', aiError);
        }
      } else {
        aiFailReason = 'NEXT_PUBLIC_GEMINI_API_KEY belum diset';
      }

      // Motion-based detection: finds REAL activity peaks from frame
      // differences and builds variable-length moments around them.
      if (detectedMoments.length === 0) {
        updateStep(
          'Detecting Moments',
          'processing',
          `AI tidak tersedia (${aiFailReason}) — menganalisis gerakan antar frame...`
        );
        detectedMoments = await detectMotionMoments(frames, duration, 5);
        console.log('[clipper] Motion-based moments:', detectedMoments);
      }

      if (detectedMoments.length === 0) {
        throw new Error(
          'Tidak ada momen menarik yang terdeteksi di video ini. Coba video lain yang memiliki aksi atau perubahan adegan.'
        );
      }

      detectedMoments.sort((a, b) => a.startTime - b.startTime);
      updateStep(
        'Detecting Moments',
        'completed',
        detectionMethod === 'ai'
          ? `AI menemukan ${detectedMoments.length} momen penting`
          : `${detectedMoments.length} momen aksi terdeteksi dari analisis gerakan`
      );

      // Step 6: Build clip segments directly from the moment boundaries —
      // each clip runs from the start of the scene until it fully finishes.
      const clipSegments = detectedMoments.map((moment, index) => {
        const start = Math.max(0, moment.startTime);
        const end = Math.min(duration, Math.max(moment.endTime, start + 3));
        return {
          startTime: start,
          endTime: end,
          clipId: `clip_${index + 1}`,
          description: `${moment.actionType}: ${moment.description}`,
        };
      });
      console.log('[clipper] Clip segments:', clipSegments);

      // Step 7: Generate clips with FFmpeg in the browser
      updateStep('Generating Clips', 'processing', `Memotong ${clipSegments.length} klip...`);
      const generatedClips = await cutVideoClips(videoBuffer, clipSegments, (current, total) => {
        updateStep('Generating Clips', 'processing', `Memotong klip ${current}/${total}...`);
      });

      if (generatedClips.length === 0) {
        throw new Error('Failed to generate clips from this video');
      }

      const clipsData: Clip[] = generatedClips.map((clip) => {
        const segIndex = clipSegments.findIndex((s) => s.clipId === clip.clipId);
        const seg = clipSegments[segIndex];
        return {
          clipId: clip.clipId,
          startTime: seg.startTime,
          endTime: seg.endTime,
          description: seg.description,
          intensity: detectedMoments[segIndex]?.intensity ?? 7,
          duration: seg.endTime - seg.startTime,
          blobUrl: URL.createObjectURL(clip.blob),
          fileSize: clip.blob.size,
        };
      });

      setClips(clipsData);
      updateStep('Generating Clips', 'completed', `Generated ${clipsData.length} clips`);
      updateStep('Complete', 'completed', 'Klip siap diunduh!');

      console.log('[clipper] Processing complete. Clips:', clipsData.length);
    } catch (error) {
      console.error('[clipper] Error processing video:', error);
      updateStep('Error', 'error', error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-12">
      {/* Input Form */}
      <InputForm onSubmit={handleUrlSubmit} isLoading={isLoading} />

      {/* Processing Status */}
      {showResults && (
        <ProcessingStatus
          steps={processingSteps}
          isComplete={!isLoading && clips.length > 0}
          clipsCount={clips.length}
        />
      )}

      {/* Clips Gallery */}
      {clips.length > 0 && !isLoading && (
        <div className="py-8">
          <ClipsGallery clips={clips} />
        </div>
      )}
    </div>
  );
}
