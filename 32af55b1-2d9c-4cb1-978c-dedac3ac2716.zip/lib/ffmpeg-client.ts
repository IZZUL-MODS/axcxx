import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL } from '@ffmpeg/util';

let ffmpegInstance: FFmpeg | null = null;
let loadPromise: Promise<FFmpeg> | null = null;

export async function initFFmpeg(): Promise<FFmpeg> {
  if (ffmpegInstance?.loaded) {
    return ffmpegInstance;
  }

  // Reuse in-flight load to prevent double initialization
  if (loadPromise) {
    return loadPromise;
  }

  loadPromise = (async () => {
    const ffmpeg = new FFmpeg();
    const baseURL = 'https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd';

    ffmpeg.on('log', ({ message }) => {
      console.log('[ffmpeg]', message);
    });

    console.log('[clipper] Loading FFmpeg core...');
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
    console.log('[clipper] FFmpeg loaded successfully');

    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })();

  try {
    return await loadPromise;
  } catch (error) {
    loadPromise = null;
    console.error('[clipper] Failed to load FFmpeg:', error);
    throw error;
  }
}

// Get video duration using the browser's native video element (fast, no FFmpeg needed)
export async function getVideoDurationFromBuffer(
  videoBuffer: Uint8Array
): Promise<number> {
  return new Promise((resolve, reject) => {
    const blob = new Blob([videoBuffer], { type: 'video/mp4' });
    const video = document.createElement('video');
    const url = URL.createObjectURL(blob);

    const timeout = setTimeout(() => {
      URL.revokeObjectURL(url);
      reject(new Error('Timeout getting video duration'));
    }, 15000);

    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      clearTimeout(timeout);
      const duration = video.duration;
      URL.revokeObjectURL(url);
      resolve(duration);
    };

    video.onerror = () => {
      clearTimeout(timeout);
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load video metadata'));
    };

    video.src = url;
  });
}

// Extract frames using the browser's native <video>+<canvas> pipeline.
// This is MUCH faster than calling ffmpeg.exec() once per frame because:
//   - No wasm overhead per seek
//   - No file I/O on the wasm FS
//   - Hardware-accelerated video decoding via the browser
// FFmpeg is intentionally NOT used here — it is reserved for the cut step.
export async function extractFramesAsImages(
  videoBuffer: Uint8Array,
  duration: number,
  intervalSeconds: number = 2,
  onProgress?: (current: number, total: number) => void,
  maxFrames: number = 32
): Promise<Array<{ timestamp: number; imageBase64: string }>> {
  // Build an evenly-spaced timestamp list capped at maxFrames
  let timestamps: number[] = [];
  const safeInterval = Math.max(intervalSeconds, 1);
  for (let t = 0; t < duration; t += safeInterval) {
    timestamps.push(parseFloat(t.toFixed(2)));
  }
  if (timestamps.length > maxFrames) {
    const step = duration / maxFrames;
    timestamps = Array.from({ length: maxFrames }, (_, i) =>
      parseFloat((i * step).toFixed(2))
    );
  }
  // Always include the first and last second
  if (timestamps.length > 0 && timestamps[0] !== 0) timestamps.unshift(0);
  const lastTs = Math.max(0, duration - 0.5);
  if (timestamps[timestamps.length - 1] < lastTs) timestamps.push(lastTs);

  const frames: Array<{ timestamp: number; imageBase64: string }> = [];

  // Create a blob URL for the video buffer so the <video> element can seek
  const blob = new Blob([videoBuffer], { type: 'video/mp4' });
  const videoUrl = URL.createObjectURL(blob);

  const video = document.createElement('video');
  video.muted = true;
  video.preload = 'auto';
  video.crossOrigin = 'anonymous';

  // Wait for the video to be ready to seek
  await new Promise<void>((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error('Video load timeout for frame extraction'));
    }, 30000);
    video.oncanplay = () => { clearTimeout(timeout); resolve(); };
    video.onerror = () => { clearTimeout(timeout); reject(new Error('Video load error')); };
    video.src = videoUrl;
    video.load();
  });

  const canvas = document.createElement('canvas');
  // Keep frames at a moderate resolution for fast AI processing
  canvas.width = 640;
  canvas.height = 360;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  if (!ctx) {
    URL.revokeObjectURL(videoUrl);
    throw new Error('Canvas 2D context unavailable');
  }

  for (let idx = 0; idx < timestamps.length; idx++) {
    const timestamp = timestamps[idx];
    onProgress?.(idx + 1, timestamps.length);

    try {
      // Seek to the timestamp and wait for the seeked event
      await new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error('Seek timeout')), 8000);
        const onSeeked = () => {
          clearTimeout(timeout);
          video.removeEventListener('seeked', onSeeked);
          resolve();
        };
        video.addEventListener('seeked', onSeeked);
        video.currentTime = timestamp;
      });

      // Draw the current video frame onto the canvas
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageBase64 = canvas.toDataURL('image/jpeg', 0.7).split(',')[1] || '';
      if (imageBase64.length > 100) {
        frames.push({ timestamp, imageBase64 });
      }
    } catch (err) {
      console.error(`[clipper] Frame seek failed at ${timestamp}s:`, err);
      // continue — skip this frame rather than aborting everything
    }
  }

  // Clean up
  video.pause();
  video.src = '';
  URL.revokeObjectURL(videoUrl);

  console.log('[clipper] Extracted', frames.length, 'frames via native canvas');
  return frames;
}

// Cut multiple clips from the video — optimised for ANY duration including 1h+.
//
// Strategy for long videos:
//   1. `-ss` BEFORE `-i` → FFmpeg seeks instantly to the nearest keyframe
//      (this is O(1) regardless of how far into the video we seek — critical
//      for 1h videos where decoding from the start would take minutes).
//   2. Re-encode only the tiny segment with ultrafast/crf28 → precise frame
//      boundaries without decoding the full file.
//   3. Fallback to stream copy when re-encode fails (still fast via keyframe
//      seek, just slightly off on the first/last frame).
//
// We also avoid cloning the entire buffer on writeFile — pass the buffer
// directly (ffmpeg.wasm transfers ownership rather than copying).
export async function cutVideoClips(
  videoBuffer: Uint8Array,
  clips: Array<{ startTime: number; endTime: number; clipId: string; description?: string }>,
  onProgress?: (current: number, total: number) => void
): Promise<Array<{ clipId: string; blob: Blob; fileName: string; description?: string }>> {
  const ffmpeg = await initFFmpeg();

  console.log('[clipper] Starting to cut', clips.length, 'clips from', (videoBuffer.length / 1024 / 1024).toFixed(1), 'MB video');

  // Write the buffer once. We pass the buffer directly — no slice/copy.
  // ffmpeg.wasm transfers ownership to the worker so we must not reuse it after this.
  await ffmpeg.writeFile('input.mp4', videoBuffer);

  const results: Array<{ clipId: string; blob: Blob; fileName: string; description?: string }> = [];

  // Per-clip timeouts — generous for long videos
  // Re-encode of a ~60s clip with ultrafast takes ~15-30s in wasm
  const REENCODE_TIMEOUT_MS = 180000; // 3 min per clip
  const COPY_TIMEOUT_MS    =  30000; // stream copy is always fast

  for (let i = 0; i < clips.length; i++) {
    const clip = clips[i];
    onProgress?.(i + 1, clips.length);

    const outputFileName = `${clip.clipId}.mp4`;
    const clipDuration = clip.endTime - clip.startTime;
    console.log(`[clipper] Cutting ${clip.clipId} (${clip.startTime}s–${clip.endTime}s, ${clipDuration.toFixed(1)}s)`);

    let clipBuffer: Uint8Array | null = null;

    try {
      // Primary: keyframe seek (-ss before -i) + re-encode only the segment.
      // This is O(segment_length) NOT O(video_length) — fast even for hour-long videos.
      const code = await ffmpeg.exec(
        [
          '-ss', clip.startTime.toFixed(3),
          '-i', 'input.mp4',
          '-t',  clipDuration.toFixed(3),
          '-c:v', 'libx264',
          '-preset', 'ultrafast',
          '-crf', '28',
          '-c:a', 'aac',
          '-b:a', '96k',
          '-avoid_negative_ts', 'make_zero',
          '-movflags', 'faststart',
          outputFileName,
        ],
        REENCODE_TIMEOUT_MS
      );
      if (code === 0) {
        clipBuffer = (await ffmpeg.readFile(outputFileName)) as Uint8Array;
        if (clipBuffer.length < 5000) clipBuffer = null; // discard empty output
      }
    } catch (encodeError) {
      console.warn(`[clipper] Re-encode failed for ${clip.clipId}:`, encodeError);
    }

    // Fallback: stream copy — near-instant, slight keyframe-boundary offset on start
    if (!clipBuffer) {
      console.log(`[clipper] Falling back to stream copy for ${clip.clipId}`);
      try { await ffmpeg.deleteFile(outputFileName); } catch { /* ignore */ }
      try {
        const code = await ffmpeg.exec(
          [
            '-ss', clip.startTime.toFixed(3),
            '-i', 'input.mp4',
            '-t',  clipDuration.toFixed(3),
            '-c', 'copy',
            '-avoid_negative_ts', 'make_zero',
            '-movflags', 'faststart',
            outputFileName,
          ],
          COPY_TIMEOUT_MS
        );
        if (code === 0) {
          clipBuffer = (await ffmpeg.readFile(outputFileName)) as Uint8Array;
          if (clipBuffer.length < 1000) clipBuffer = null;
        }
      } catch (copyError) {
        console.error(`[clipper] Stream copy also failed for ${clip.clipId}:`, copyError);
      }
    }

    if (!clipBuffer) {
      console.error(`[clipper] Skipping ${clip.clipId} — both encode and copy failed`);
      try { await ffmpeg.deleteFile(outputFileName); } catch { /* ignore */ }
      continue;
    }

    const blob = new Blob([clipBuffer], { type: 'video/mp4' });
    console.log(`[clipper] ${clip.clipId} done — ${(blob.size / 1024).toFixed(0)} KB`);
    results.push({ clipId: clip.clipId, blob, fileName: outputFileName, description: clip.description });
    try { await ffmpeg.deleteFile(outputFileName); } catch { /* ignore */ }
  }

  try { await ffmpeg.deleteFile('input.mp4'); } catch { /* ignore */ }
  console.log('[clipper] All clips done. Total:', results.length);
  return results;
}
