import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';
// Long timeout for large video downloads (1h+ videos can be several GB)
export const maxDuration = 300;

// Streams the remote video through the server to the browser (no storage used).
// Supports byte-range requests so the browser can resume and seek efficiently.
export async function GET(req: NextRequest) {
  const videoUrl = req.nextUrl.searchParams.get('url');

  if (!videoUrl) {
    return NextResponse.json({ error: 'url parameter is required' }, { status: 400 });
  }

  let parsed: URL;
  try {
    parsed = new URL(videoUrl);
  } catch {
    return NextResponse.json({ error: 'Invalid URL' }, { status: 400 });
  }
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    return NextResponse.json({ error: 'Only http/https URLs are supported' }, { status: 400 });
  }

  // Forward Range header if present (allows browser to seek without re-downloading)
  const rangeHeader = req.headers.get('range');

  try {
    console.log('[clipper] Proxying video:', videoUrl.slice(0, 100), rangeHeader ? `range: ${rangeHeader}` : '');
    const upstreamHeaders: Record<string, string> = {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
      Accept: '*/*',
      Referer: `${parsed.protocol}//${parsed.host}/`,
    };
    if (rangeHeader) upstreamHeaders['Range'] = rangeHeader;

    const upstream = await fetch(videoUrl, {
      headers: upstreamHeaders,
      redirect: 'follow',
    });

    if (!upstream.ok || !upstream.body) {
      return NextResponse.json(
        { error: `Upstream returned ${upstream.status}` },
        { status: 502 }
      );
    }

    const contentType = upstream.headers.get('content-type') || 'video/mp4';
    const contentLength = upstream.headers.get('content-length');
    const contentRange = upstream.headers.get('content-range');
    const acceptRanges = upstream.headers.get('accept-ranges') || 'bytes';

    const responseHeaders = new Headers({
      'Content-Type': contentType,
      'Cache-Control': 'no-store',
      // Always advertise range support so browser knows it can seek
      'Accept-Ranges': acceptRanges,
    });
    if (contentLength) responseHeaders.set('Content-Length', contentLength);
    if (contentRange) responseHeaders.set('Content-Range', contentRange);

    // 206 Partial Content when upstream responded to a range request
    const status = upstream.status === 206 ? 206 : 200;

    return new NextResponse(upstream.body, { status, headers: responseHeaders });
  } catch (error) {
    console.error('[clipper] Proxy error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to fetch video' },
      { status: 500 }
    );
  }
}
